"""Firmware image loaders for avrsim."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from .cpu import CPU


@dataclass(frozen=True)
class ProgramSegment:
    """One contiguous flash segment in byte-addressed program space."""

    start_byte: int
    data: bytes


@dataclass(frozen=True)
class ProgramImage:
    """A loaded flash image ready to be placed into an AVR CPU instance."""

    segments: tuple[ProgramSegment, ...] = field(default_factory=tuple)

    def load_into_cpu(self, cpu: CPU, *, clear_program: bool = True) -> None:
        if clear_program:
            cpu.reset(clear_program=True)
        for segment in self.segments:
            cpu.load_program_bytes(segment.data, start_byte=segment.start_byte)


def load_intel_hex(path: str | Path) -> ProgramImage:
    """Parse a small Intel HEX flash image."""

    extended_linear_base = 0
    extended_segment_base = 0
    raw_bytes: dict[int, int] = {}

    for line_number, raw_line in enumerate(Path(path).read_text(encoding="utf-8").splitlines(), start=1):
        line = raw_line.strip()
        if not line:
            continue
        if not line.startswith(":"):
            raise ValueError(f"line {line_number} is not a valid Intel HEX record")

        record = bytes.fromhex(line[1:])
        if len(record) < 5:
            raise ValueError(f"line {line_number} is too short for Intel HEX")

        byte_count = record[0]
        if len(record) != byte_count + 5:
            raise ValueError(f"line {line_number} length does not match record byte count")

        address = (record[1] << 8) | record[2]
        record_type = record[3]
        payload = record[4:-1]
        checksum = record[-1]
        computed = ((-sum(record[:-1])) & 0xFF)
        if checksum != computed:
            raise ValueError(f"line {line_number} has an invalid Intel HEX checksum")

        if record_type == 0x00:
            absolute_base = extended_linear_base + extended_segment_base
            absolute_address = absolute_base + address
            for offset, value in enumerate(payload):
                raw_bytes[absolute_address + offset] = value
        elif record_type == 0x01:
            break
        elif record_type == 0x02:
            if len(payload) != 2:
                raise ValueError(f"line {line_number} has an invalid extended-segment record")
            extended_segment_base = (((payload[0] << 8) | payload[1]) << 4)
            extended_linear_base = 0
        elif record_type == 0x04:
            if len(payload) != 2:
                raise ValueError(f"line {line_number} has an invalid extended-linear record")
            extended_linear_base = (((payload[0] << 8) | payload[1]) << 16)
            extended_segment_base = 0
        elif record_type in (0x03, 0x05):
            continue
        else:
            raise ValueError(f"line {line_number} uses unsupported Intel HEX record type 0x{record_type:02X}")

    if not raw_bytes:
        return ProgramImage()

    segments: list[ProgramSegment] = []
    ordered_addresses = sorted(raw_bytes)
    start_address = ordered_addresses[0]
    next_address = start_address
    buffer = bytearray()

    for address in ordered_addresses:
        if address != next_address:
            segments.append(ProgramSegment(start_byte=start_address, data=bytes(buffer)))
            start_address = address
            buffer = bytearray()
        buffer.append(raw_bytes[address] & 0xFF)
        next_address = address + 1

    segments.append(ProgramSegment(start_byte=start_address, data=bytes(buffer)))
    return ProgramImage(segments=tuple(segments))


__all__ = [
    "ProgramImage",
    "ProgramSegment",
    "load_intel_hex",
]
