"""Project-specific CAN air-node protocol helpers.

This module models the DewPoint application payloads on top of CAN.
It is intentionally separate from the datasheet-grounded MCP2515 controller model.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import math


CAN_MIN_NODE_ID = 1
CAN_MAX_NODE_ID = 3
CAN_AIR_SAMPLE_BASE_ID = 0x180
CAN_IDENTITY_BASE_ID = 0x190
CAN_AIR_SAMPLE_LENGTH = 6
CAN_IDENTITY_LENGTH = 6
CAN_STATUS_SENSOR_OK = 0x01


@dataclass(frozen=True)
class CanFrame:
    frame_id: int
    length: int
    data: tuple[int, ...]


@dataclass(frozen=True)
class CanAirSample:
    node_id: int
    temp_c: float
    rh_percent: float
    sensor_ok: bool
    sequence: int


@dataclass(frozen=True)
class CanAirIdentity:
    node_id: int
    sensor_id: int


@dataclass
class CanBusModel:
    frames: list[CanFrame] = field(default_factory=list)

    def send(self, frame: CanFrame) -> None:
        if frame.length < 0 or frame.length > 8:
            raise ValueError("CAN frame length must be between 0 and 8")
        if len(frame.data) != 8:
            raise ValueError("CAN frame data tuple must contain 8 bytes")
        self.frames.append(frame)

    def receive(self) -> CanFrame | None:
        if not self.frames:
            return None
        return self.frames.pop(0)

    def pending_count(self) -> int:
        return len(self.frames)


@dataclass
class CanAirNodeModel:
    node_id: int
    sensor_id: int
    sequence: int = 0
    sensor_ok: bool = True
    temp_c: float = 20.0
    rh_percent: float = 50.0

    def publish_current_sample(self, bus: CanBusModel) -> None:
        bus.send(
            encode_sample_frame(
                self.node_id,
                self.temp_c,
                self.rh_percent,
                self.sensor_ok,
                self.sequence,
            )
        )
        bus.send(encode_identity_frame(self.node_id, self.sensor_id))


def is_valid_node_id(node_id: int) -> bool:
    return CAN_MIN_NODE_ID <= node_id <= CAN_MAX_NODE_ID


def _is_finite(value: float) -> bool:
    return math.isfinite(value)


def _validate_temp_c(value: float) -> bool:
    return _is_finite(value) and -40.0 <= value <= 125.0


def _validate_rh_percent(value: float) -> bool:
    return _is_finite(value) and 0.0 <= value <= 100.0


def _pack_signed_centi(value: float) -> int:
    packed = int(round(value * 100.0))
    if packed < -32768 or packed > 32767:
        raise ValueError("signed centi value out of range")
    return packed


def _pack_unsigned_centi(value: float) -> int:
    packed = int(round(value * 100.0))
    if packed < 0 or packed > 65535:
        raise ValueError("unsigned centi value out of range")
    return packed


def _u8(value: int) -> int:
    return value & 0xFF


def encode_sample_frame(
    node_id: int,
    temp_c: float,
    rh_percent: float,
    sensor_ok: bool,
    sequence: int,
) -> CanFrame:
    if not is_valid_node_id(node_id):
        raise ValueError("invalid CAN air-node id")
    if not _validate_temp_c(temp_c):
        raise ValueError("temperature out of range for CAN air sample")
    if not _validate_rh_percent(rh_percent):
        raise ValueError("humidity out of range for CAN air sample")
    if sequence < 0 or sequence > 0xFF:
        raise ValueError("sequence must fit in one byte")

    packed_temp = _pack_signed_centi(temp_c) & 0xFFFF
    packed_rh = _pack_unsigned_centi(rh_percent)
    data = (
        _u8(packed_temp),
        _u8(packed_temp >> 8),
        _u8(packed_rh),
        _u8(packed_rh >> 8),
        CAN_STATUS_SENSOR_OK if sensor_ok else 0,
        _u8(sequence),
        0,
        0,
    )
    return CanFrame(
        frame_id=CAN_AIR_SAMPLE_BASE_ID + (node_id - 1),
        length=CAN_AIR_SAMPLE_LENGTH,
        data=data,
    )


def decode_sample_frame(frame: CanFrame) -> CanAirSample:
    if frame.frame_id < CAN_AIR_SAMPLE_BASE_ID or frame.frame_id >= (
        CAN_AIR_SAMPLE_BASE_ID + CAN_MAX_NODE_ID
    ):
        raise ValueError("frame id is not an air sample frame")
    if frame.length != CAN_AIR_SAMPLE_LENGTH:
        raise ValueError("invalid air sample frame length")

    node_id = (frame.frame_id - CAN_AIR_SAMPLE_BASE_ID) + 1
    if not is_valid_node_id(node_id):
        raise ValueError("decoded invalid air sample node id")

    packed_temp = frame.data[0] | (frame.data[1] << 8)
    if packed_temp >= 0x8000:
        packed_temp -= 0x10000
    packed_rh = frame.data[2] | (frame.data[3] << 8)

    temp_c = packed_temp / 100.0
    rh_percent = packed_rh / 100.0
    if not _validate_temp_c(temp_c):
        raise ValueError("decoded air sample temperature out of range")
    if not _validate_rh_percent(rh_percent):
        raise ValueError("decoded air sample humidity out of range")

    return CanAirSample(
        node_id=node_id,
        temp_c=temp_c,
        rh_percent=rh_percent,
        sensor_ok=(frame.data[4] & CAN_STATUS_SENSOR_OK) != 0,
        sequence=frame.data[5],
    )


def encode_identity_frame(node_id: int, sensor_id: int) -> CanFrame:
    if not is_valid_node_id(node_id):
        raise ValueError("invalid CAN air-node id")
    if sensor_id <= 0 or sensor_id > 0xFFFFFFFFFFFF:
        raise ValueError("sensor id must be a nonzero 48-bit value")
    data = tuple(_u8(sensor_id >> (8 * index)) for index in range(6)) + (0, 0)
    return CanFrame(
        frame_id=CAN_IDENTITY_BASE_ID + (node_id - 1),
        length=CAN_IDENTITY_LENGTH,
        data=data,
    )


def decode_identity_frame(frame: CanFrame) -> CanAirIdentity:
    if frame.frame_id < CAN_IDENTITY_BASE_ID or frame.frame_id >= (
        CAN_IDENTITY_BASE_ID + CAN_MAX_NODE_ID
    ):
        raise ValueError("frame id is not a CAN identity frame")
    if frame.length != CAN_IDENTITY_LENGTH:
        raise ValueError("invalid CAN identity frame length")

    node_id = (frame.frame_id - CAN_IDENTITY_BASE_ID) + 1
    if not is_valid_node_id(node_id):
        raise ValueError("decoded invalid CAN identity node id")

    sensor_id = 0
    for index in range(6):
        sensor_id |= frame.data[index] << (8 * index)

    if sensor_id <= 0 or sensor_id > 0xFFFFFFFFFFFF:
        raise ValueError("decoded CAN identity sensor id out of range")

    return CanAirIdentity(node_id=node_id, sensor_id=sensor_id)
