"""Datasheet-grounded MCP2515 controller model."""

from __future__ import annotations

from dataclasses import dataclass, field
import math


COMMAND_RESET = 0xC0
COMMAND_READ = 0x03
COMMAND_WRITE = 0x02
COMMAND_BIT_MODIFY = 0x05
COMMAND_READ_STATUS = 0xA0
COMMAND_RTS_TX0 = 0x81
COMMAND_RTS_TX1 = 0x82
COMMAND_RTS_TX2 = 0x84
COMMAND_READ_RX_BUFFER_RXB0SIDH = 0x90
COMMAND_READ_RX_BUFFER_RXB0D0 = 0x92
COMMAND_READ_RX_BUFFER_RXB1SIDH = 0x94
COMMAND_READ_RX_BUFFER_RXB1D0 = 0x96
COMMAND_LOAD_TX_BUFFER_TXB0SIDH = 0x40
COMMAND_LOAD_TX_BUFFER_TXB0D0 = 0x42
COMMAND_LOAD_TX_BUFFER_TXB1SIDH = 0x44
COMMAND_LOAD_TX_BUFFER_TXB1D0 = 0x46
COMMAND_LOAD_TX_BUFFER_TXB2SIDH = 0x48
COMMAND_LOAD_TX_BUFFER_TXB2D0 = 0x4A

REGISTER_CANSTAT = 0x0E
REGISTER_CANCTRL = 0x0F
REGISTER_CNF3 = 0x28
REGISTER_CNF2 = 0x29
REGISTER_CNF1 = 0x2A
REGISTER_CANINTE = 0x2B
REGISTER_CANINTF = 0x2C
REGISTER_TXB0CTRL = 0x30
REGISTER_TXB0SIDH = 0x31
REGISTER_TXB0DLC = 0x35
REGISTER_TXB1CTRL = 0x40
REGISTER_TXB1SIDH = 0x41
REGISTER_TXB1DLC = 0x45
REGISTER_TXB2CTRL = 0x50
REGISTER_TXB2SIDH = 0x51
REGISTER_TXB2DLC = 0x55
REGISTER_RXB0CTRL = 0x60
REGISTER_RXB0SIDH = 0x61
REGISTER_RXB0DLC = 0x65
REGISTER_RXB1CTRL = 0x70
REGISTER_RXB1SIDH = 0x71
REGISTER_RXB1DLC = 0x75

MODE_MASK = 0xE0
MODE_NORMAL = 0x00
MODE_CONFIGURATION = 0x80

CANINTF_RX0IF = 0x01
CANINTF_RX1IF = 0x02
CANINTF_TX0IF = 0x04
CANINTF_TX1IF = 0x08
CANINTF_TX2IF = 0x10
TXREQ_MASK = 0x08

REGISTER_SPACE_SIZE = 0x80
POR_CANSTAT = 0x80
POR_CANCTRL = 0x87

_BIT_MODIFIABLE_REGISTERS = frozenset(
    {
        REGISTER_CANCTRL,
        REGISTER_CNF3,
        REGISTER_CNF2,
        REGISTER_CNF1,
        REGISTER_CANINTE,
        REGISTER_CANINTF,
        REGISTER_TXB0CTRL,
        REGISTER_TXB1CTRL,
        REGISTER_TXB2CTRL,
        REGISTER_RXB0CTRL,
        REGISTER_RXB1CTRL,
    }
)

_READ_RX_BUFFER_START = {
    COMMAND_READ_RX_BUFFER_RXB0SIDH: (REGISTER_RXB0SIDH, 0),
    COMMAND_READ_RX_BUFFER_RXB0D0: (REGISTER_RXB0SIDH + 5, 0),
    COMMAND_READ_RX_BUFFER_RXB1SIDH: (REGISTER_RXB1SIDH, 1),
    COMMAND_READ_RX_BUFFER_RXB1D0: (REGISTER_RXB1SIDH + 5, 1),
}

_LOAD_TX_BUFFER_START = {
    COMMAND_LOAD_TX_BUFFER_TXB0SIDH: REGISTER_TXB0SIDH,
    COMMAND_LOAD_TX_BUFFER_TXB0D0: REGISTER_TXB0SIDH + 5,
    COMMAND_LOAD_TX_BUFFER_TXB1SIDH: REGISTER_TXB1SIDH,
    COMMAND_LOAD_TX_BUFFER_TXB1D0: REGISTER_TXB1SIDH + 5,
    COMMAND_LOAD_TX_BUFFER_TXB2SIDH: REGISTER_TXB2SIDH,
    COMMAND_LOAD_TX_BUFFER_TXB2D0: REGISTER_TXB2SIDH + 5,
}


def encode_standard_id(frame_id: int) -> tuple[int, int]:
    if frame_id < 0 or frame_id > 0x7FF:
        raise ValueError("MCP2515 model only supports standard 11-bit identifiers")
    return ((frame_id >> 3) & 0xFF, (frame_id & 0x07) << 5)


def decode_standard_id(sidh: int, sidl: int) -> int:
    return ((sidh & 0xFF) << 3) | ((sidl & 0xE0) >> 5)


@dataclass(frozen=True)
class Mcp2515Frame:
    frame_id: int
    dlc: int
    data: tuple[int, ...]

    def __post_init__(self) -> None:
        if self.frame_id < 0 or self.frame_id > 0x7FF:
            raise ValueError("MCP2515 model only supports standard 11-bit identifiers")
        if self.dlc < 0 or self.dlc > 8:
            raise ValueError("CAN DLC must be between 0 and 8")
        if len(self.data) != 8:
            raise ValueError("Mcp2515Frame data must contain exactly 8 bytes")
        for byte in self.data:
            if byte < 0 or byte > 0xFF:
                raise ValueError("CAN data bytes must fit in one octet")


@dataclass
class MCP2515Model:
    tx_complete_latency_ms: float = 1.0
    transmitted_frames: list[Mcp2515Frame] = field(default_factory=list)

    def __post_init__(self) -> None:
        if not math.isfinite(self.tx_complete_latency_ms) or self.tx_complete_latency_ms < 0.0:
            raise ValueError("tx_complete_latency_ms must be finite and non-negative")
        self.reset()

    def reset(self) -> None:
        self._registers = [0] * REGISTER_SPACE_SIZE
        self._registers[REGISTER_CANSTAT] = POR_CANSTAT
        self._registers[REGISTER_CANCTRL] = POR_CANCTRL
        self._pending_tx_due_at_ms = {}
        self._now_ms = 0.0
        self.transmitted_frames.clear()

    def advance_time_ms(self, elapsed_ms: float) -> None:
        if not math.isfinite(elapsed_ms) or elapsed_ms < 0.0:
            raise ValueError("elapsed time must be finite and non-negative")
        self._now_ms += elapsed_ms
        self._service_pending()

    def read_register(self, address: int) -> int:
        self._service_pending()
        return self._registers[self._normalize_address(address)]

    def read_registers(self, start_address: int, length: int) -> bytes:
        if length < 0:
            raise ValueError("register length must be non-negative")
        return bytes(self.read_register(start_address + offset) for offset in range(length))

    def write_register(self, address: int, value: int) -> None:
        self._service_pending()
        normalized = self._normalize_address(address)
        self._registers[normalized] = value & 0xFF
        if normalized == REGISTER_CANCTRL:
            self._sync_mode_bits()

    def write_registers(self, start_address: int, values: bytes | tuple[int, ...] | list[int]) -> None:
        for offset, value in enumerate(values):
            self.write_register(start_address + offset, value)

    def bit_modify(self, address: int, mask: int, data: int) -> None:
        self._service_pending()
        normalized = self._normalize_address(address)
        effective_mask = mask & 0xFF
        if normalized not in _BIT_MODIFIABLE_REGISTERS:
            effective_mask = 0xFF
        current = self._registers[normalized]
        updated = (current & (~effective_mask & 0xFF)) | (data & effective_mask)
        self.write_register(normalized, updated)

    def read_status(self) -> int:
        self._service_pending()
        canintf = self._registers[REGISTER_CANINTF]
        return (
            ((canintf & CANINTF_RX0IF) << 7)
            | ((canintf & CANINTF_RX1IF) << 5)
            | ((canintf & CANINTF_TX0IF) << 3)
            | ((canintf & CANINTF_TX1IF) << 1)
            | ((canintf & CANINTF_TX2IF) >> 1)
            | ((self._registers[REGISTER_TXB2CTRL] & TXREQ_MASK) >> 1)
            | ((self._registers[REGISTER_TXB1CTRL] & TXREQ_MASK) >> 2)
            | ((self._registers[REGISTER_TXB0CTRL] & TXREQ_MASK) >> 3)
        ) & 0xFF

    def message_pending(self) -> bool:
        self._service_pending()
        return (self._registers[REGISTER_CANINTF] & (CANINTF_RX0IF | CANINTF_RX1IF)) != 0

    def request_to_send(self, tx_mask: int) -> None:
        self._service_pending()
        for buffer_index in range(3):
            if (tx_mask & (1 << buffer_index)) == 0:
                continue
            ctrl_address = REGISTER_TXB0CTRL + (buffer_index * 0x10)
            self._registers[ctrl_address] |= TXREQ_MASK
            self._pending_tx_due_at_ms[buffer_index] = self._now_ms + self.tx_complete_latency_ms

    def inject_received_frame(self, frame: Mcp2515Frame, buffer_index: int = 0) -> None:
        self._service_pending()
        if buffer_index not in (0, 1):
            raise ValueError("RX buffer index must be 0 or 1")
        start = REGISTER_RXB0SIDH if buffer_index == 0 else REGISTER_RXB1SIDH
        sidh, sidl = encode_standard_id(frame.frame_id)
        self.write_register(start + 0, sidh)
        self.write_register(start + 1, sidl)
        self.write_register(start + 2, 0)
        self.write_register(start + 3, 0)
        self.write_register(start + 4, frame.dlc & 0x0F)
        for offset, value in enumerate(frame.data):
            self.write_register(start + 5 + offset, value)
        if buffer_index == 0:
            self._registers[REGISTER_CANINTF] |= CANINTF_RX0IF
        else:
            self._registers[REGISTER_CANINTF] |= CANINTF_RX1IF

    def spi_transaction(self, data_out: bytes) -> bytes:
        self._service_pending()
        if not data_out:
            return b""

        command = data_out[0]
        if command == COMMAND_RESET:
            self.reset()
            return bytes(len(data_out))
        if command == COMMAND_READ:
            if len(data_out) < 2:
                raise ValueError("READ requires an address byte")
            return self._spi_read(data_out)
        if command == COMMAND_WRITE:
            if len(data_out) < 2:
                raise ValueError("WRITE requires an address byte")
            self.write_registers(data_out[1], data_out[2:])
            return bytes(len(data_out))
        if command == COMMAND_BIT_MODIFY:
            if len(data_out) < 4:
                raise ValueError("BIT MODIFY requires address, mask, and data bytes")
            self.bit_modify(data_out[1], data_out[2], data_out[3])
            return bytes(len(data_out))
        if command == COMMAND_READ_STATUS:
            status = self.read_status()
            return bytes([0] + [status] * (len(data_out) - 1))
        if command in _READ_RX_BUFFER_START:
            return self._spi_read_rx_buffer(command, len(data_out))
        if command in _LOAD_TX_BUFFER_START:
            self.write_registers(_LOAD_TX_BUFFER_START[command], data_out[1:])
            return bytes(len(data_out))
        if (command & 0xF8) == 0x80:
            self.request_to_send(command & 0x07)
            return bytes(len(data_out))
        raise ValueError(f"unsupported MCP2515 instruction 0x{command:02X}")

    def _complete_transmission(self, buffer_index: int) -> None:
        ctrl_address = REGISTER_TXB0CTRL + (buffer_index * 0x10)
        tx_intf_mask = CANINTF_TX0IF << buffer_index
        self._registers[ctrl_address] &= ~TXREQ_MASK
        self._registers[REGISTER_CANINTF] |= tx_intf_mask
        self.transmitted_frames.append(self._frame_from_tx_buffer(buffer_index))
        del self._pending_tx_due_at_ms[buffer_index]

    def _frame_from_tx_buffer(self, buffer_index: int) -> Mcp2515Frame:
        start = REGISTER_TXB0SIDH + (buffer_index * 0x10)
        frame_id = decode_standard_id(self._registers[start + 0], self._registers[start + 1])
        dlc = self._registers[start + 4] & 0x0F
        data = tuple(self._registers[start + 5 + offset] & 0xFF for offset in range(8))
        return Mcp2515Frame(frame_id=frame_id, dlc=dlc, data=data)

    def _normalize_address(self, address: int) -> int:
        if address < 0 or address >= REGISTER_SPACE_SIZE:
            raise ValueError(f"register address out of range: 0x{address:02X}")
        return address

    def _service_pending(self) -> None:
        ready_buffers = [
            buffer_index
            for buffer_index, due_at in self._pending_tx_due_at_ms.items()
            if self._now_ms >= due_at
        ]
        for buffer_index in sorted(ready_buffers):
            self._complete_transmission(buffer_index)

    def _spi_read(self, data_out: bytes) -> bytes:
        address = self._normalize_address(data_out[1])
        response = [0, 0]
        for offset in range(len(data_out) - 2):
            response.append(self._registers[(address + offset) % REGISTER_SPACE_SIZE] & 0xFF)
        return bytes(response)

    def _spi_read_rx_buffer(self, command: int, transaction_length: int) -> bytes:
        start_address, buffer_index = _READ_RX_BUFFER_START[command]
        response = [0]
        for offset in range(transaction_length - 1):
            response.append(self._registers[start_address + offset] & 0xFF)
        if buffer_index == 0:
            self._registers[REGISTER_CANINTF] &= ~CANINTF_RX0IF
        else:
            self._registers[REGISTER_CANINTF] &= ~CANINTF_RX1IF
        return bytes(response)

    def _sync_mode_bits(self) -> None:
        self._registers[REGISTER_CANSTAT] = (
            (self._registers[REGISTER_CANSTAT] & ~MODE_MASK)
            | (self._registers[REGISTER_CANCTRL] & MODE_MASK)
        )
