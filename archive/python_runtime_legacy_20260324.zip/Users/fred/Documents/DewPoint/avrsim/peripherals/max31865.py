"""Datasheet-grounded MAX31865 RTD peripheral model."""

from __future__ import annotations

from dataclasses import dataclass
import math


FILTER_60HZ = 0
FILTER_50HZ = 1

REGISTER_CONFIG = 0x00
REGISTER_RTD_MSB = 0x01
REGISTER_RTD_LSB = 0x02
REGISTER_FAULT_STATUS = 0x07

CONFIG_BIAS = 0x80
CONFIG_AUTO_CONVERT = 0x40
CONFIG_ONE_SHOT = 0x20
CONFIG_THREE_WIRE = 0x10
CONFIG_FAULT_CYCLE_MASK = 0x0C
CONFIG_FAULT_CLEAR = 0x02
CONFIG_FILTER_50HZ = 0x01

FAULT_HIGH_THRESHOLD = 0x80
FAULT_LOW_THRESHOLD = 0x40
FAULT_REFIN_HIGH = 0x20
FAULT_REFIN_LOW = 0x10
FAULT_RTDIN_LOW = 0x08
FAULT_OVER_UNDER_VOLTAGE = 0x04

SINGLE_CONVERSION_60HZ_MS = 55.0
SINGLE_CONVERSION_50HZ_MS = 66.0
CONTINUOUS_CONVERSION_60HZ_MS = 17.6
CONTINUOUS_CONVERSION_50HZ_MS = 21.0
BIAS_STARTUP_MAX_MS = 10.0


@dataclass(frozen=True)
class RtdModel:
    reference_resistor_ohms: float
    nominal_resistance_ohms: float
    coefficient_a: float
    coefficient_b: float
    coefficient_c: float
    min_temp_c: float
    max_temp_c: float


def pt1000_model() -> RtdModel:
    return RtdModel(
        reference_resistor_ohms=4300.0,
        nominal_resistance_ohms=1000.0,
        coefficient_a=3.9083e-3,
        coefficient_b=-5.775e-7,
        coefficient_c=-4.183e-12,
        min_temp_c=-50.0,
        max_temp_c=200.0,
    )


def build_config_byte(
    enable_bias: bool,
    one_shot: bool,
    three_wire: bool,
    clear_fault: bool,
    filter_mode: int,
) -> int:
    value = 0
    if enable_bias:
        value |= CONFIG_BIAS
    if one_shot:
        value |= CONFIG_ONE_SHOT
    if three_wire:
        value |= CONFIG_THREE_WIRE
    if clear_fault:
        value |= CONFIG_FAULT_CLEAR
    if filter_mode == FILTER_50HZ:
        value |= CONFIG_FILTER_50HZ
    return value & 0xFF


def _evaluate_resistance(temp_c: float, model: RtdModel) -> float:
    temp_squared = temp_c * temp_c
    if temp_c >= 0.0:
        return model.nominal_resistance_ohms * (
            1.0 + (model.coefficient_a * temp_c) + (model.coefficient_b * temp_squared)
        )
    return model.nominal_resistance_ohms * (
        1.0
        + (model.coefficient_a * temp_c)
        + (model.coefficient_b * temp_squared)
        + (model.coefficient_c * (temp_c - 100.0) * temp_c * temp_squared)
    )


def _evaluate_derivative(temp_c: float, model: RtdModel) -> float:
    if temp_c >= 0.0:
        return model.nominal_resistance_ohms * (
            model.coefficient_a + (2.0 * model.coefficient_b * temp_c)
        )
    return model.nominal_resistance_ohms * (
        model.coefficient_a
        + (2.0 * model.coefficient_b * temp_c)
        + (model.coefficient_c * ((4.0 * temp_c * temp_c * temp_c) - (300.0 * temp_c * temp_c)))
    )


def raw_code_to_resistance_ohms(raw_code: int, model: RtdModel) -> float:
    if not math.isfinite(model.reference_resistor_ohms) or model.reference_resistor_ohms <= 0.0:
        raise ValueError("invalid RTD model reference resistor")
    if raw_code < 0 or raw_code > 0x7FFF:
        raise ValueError("raw MAX31865 code out of range")
    resistance = (float(raw_code) * model.reference_resistor_ohms) / 32768.0
    if not math.isfinite(resistance):
        raise ValueError("non-finite resistance from raw code")
    return resistance


def temperature_c_to_resistance_ohms(temp_c: float, model: RtdModel) -> float:
    if (
        not math.isfinite(temp_c)
        or not math.isfinite(model.nominal_resistance_ohms)
        or model.nominal_resistance_ohms <= 0.0
        or temp_c < model.min_temp_c
        or temp_c > model.max_temp_c
    ):
        raise ValueError("temperature is out of RTD model range")
    resistance = _evaluate_resistance(temp_c, model)
    if not math.isfinite(resistance) or resistance <= 0.0:
        raise ValueError("invalid resistance computed from temperature")
    return resistance


def resistance_ohms_to_temperature_c(resistance_ohms: float, model: RtdModel) -> float:
    if not math.isfinite(resistance_ohms) or resistance_ohms <= 0.0:
        raise ValueError("resistance must be finite and positive")

    min_resistance = temperature_c_to_resistance_ohms(model.min_temp_c, model)
    max_resistance = temperature_c_to_resistance_ohms(model.max_temp_c, model)
    if resistance_ohms < min_resistance or resistance_ohms > max_resistance:
        raise ValueError("resistance is outside the supported RTD model range")

    estimate = ((resistance_ohms / model.nominal_resistance_ohms) - 1.0) / model.coefficient_a
    if not math.isfinite(estimate):
        raise ValueError("failed to seed RTD temperature estimate")

    estimate = max(model.min_temp_c, min(model.max_temp_c, estimate))
    for _ in range(8):
        residual = _evaluate_resistance(estimate, model) - resistance_ohms
        derivative = _evaluate_derivative(estimate, model)
        if not math.isfinite(residual) or not math.isfinite(derivative) or abs(derivative) < 1.0e-6:
            raise ValueError("failed RTD Newton iteration")
        estimate -= residual / derivative
        estimate = max(model.min_temp_c, min(model.max_temp_c, estimate))

    if not math.isfinite(estimate):
        raise ValueError("non-finite temperature from RTD resistance")
    return estimate


def resistance_ohms_to_raw_code(resistance_ohms: float, model: RtdModel) -> int:
    if not math.isfinite(resistance_ohms) or resistance_ohms <= 0.0:
        raise ValueError("resistance must be finite and positive")
    raw_code = int(round((resistance_ohms * 32768.0) / model.reference_resistor_ohms))
    return max(0, min(0x7FFF, raw_code))


def _single_conversion_time_ms(config_register: int) -> float:
    if (config_register & CONFIG_FILTER_50HZ) != 0:
        return SINGLE_CONVERSION_50HZ_MS
    return SINGLE_CONVERSION_60HZ_MS


def _continuous_conversion_time_ms(config_register: int) -> float:
    if (config_register & CONFIG_FILTER_50HZ) != 0:
        return CONTINUOUS_CONVERSION_50HZ_MS
    return CONTINUOUS_CONVERSION_60HZ_MS


@dataclass
class MAX31865Model:
    probe_temp_c: float = 25.0
    three_wire: bool = False
    filter_mode: int = FILTER_60HZ
    model: RtdModel | None = None
    fault_status: int = 0

    def __post_init__(self) -> None:
        if self.model is None:
            self.model = pt1000_model()
        self.fault_status &= 0xFF
        self._config_register = 0
        self._raw_register = 0
        self._now_ms = 0.0
        self._conversion_due_at_ms = None
        self._conversion_phase = None
        self._apply_fault_bit()

    def advance_time_ms(self, elapsed_ms: float) -> None:
        if not math.isfinite(elapsed_ms) or elapsed_ms < 0.0:
            raise ValueError("elapsed time must be finite and non-negative")
        self._now_ms += elapsed_ms
        self._service_pending()

    def set_probe_temperature(self, probe_temp_c: float) -> None:
        if not math.isfinite(probe_temp_c):
            raise ValueError("probe temperature must be finite")
        self._service_pending()
        self.probe_temp_c = probe_temp_c

    def set_fault_status(self, fault_status: int) -> None:
        self._service_pending()
        self.fault_status = fault_status & 0xFF
        self._apply_fault_bit()

    def write_register(self, register: int, value: int) -> None:
        value &= 0xFF
        self._service_pending()
        if register != REGISTER_CONFIG:
            raise ValueError("MAX31865 model only supports config writes")

        if (value & CONFIG_FAULT_CLEAR) != 0:
            self.fault_status = 0

        self._config_register = value & ~CONFIG_FAULT_CLEAR
        self._apply_fault_bit()

        if (self._config_register & CONFIG_AUTO_CONVERT) != 0:
            self._conversion_phase = "auto_first"
            self._conversion_due_at_ms = self._now_ms + _single_conversion_time_ms(
                self._config_register
            )
        elif (self._config_register & CONFIG_ONE_SHOT) != 0:
            self._conversion_phase = "single"
            self._conversion_due_at_ms = self._now_ms + _single_conversion_time_ms(
                self._config_register
            )
        else:
            self._conversion_phase = None
            self._conversion_due_at_ms = None

    def read_register(self, register: int) -> int:
        self._service_pending()
        if register == REGISTER_CONFIG:
            return self._config_register & 0xFF
        if register == REGISTER_RTD_MSB:
            return (self._raw_register >> 8) & 0xFF
        if register == REGISTER_RTD_LSB:
            return self._raw_register & 0xFF
        if register == REGISTER_FAULT_STATUS:
            return self.fault_status & 0xFF
        raise ValueError(f"unsupported MAX31865 register: 0x{register:02X}")

    def read_registers(self, start_register: int, length: int) -> bytes:
        if length < 0:
            raise ValueError("register length must be non-negative")
        return bytes(self.read_register(start_register + offset) for offset in range(length))

    def _service_pending(self) -> None:
        while self._conversion_due_at_ms is not None and self._now_ms >= self._conversion_due_at_ms:
            self._refresh_conversion()
            if self._conversion_phase == "single":
                self._config_register &= ~CONFIG_ONE_SHOT
                self._conversion_phase = None
                self._conversion_due_at_ms = None
            elif self._conversion_phase == "auto_first":
                self._conversion_phase = "auto_continuous"
                self._conversion_due_at_ms += _continuous_conversion_time_ms(self._config_register)
            elif self._conversion_phase == "auto_continuous":
                self._conversion_due_at_ms += _continuous_conversion_time_ms(self._config_register)
            else:
                self._conversion_due_at_ms = None

    def _apply_fault_bit(self) -> None:
        if self.fault_status != 0:
            self._raw_register |= 0x0001
        else:
            self._raw_register &= 0xFFFE

    def _refresh_conversion(self) -> None:
        resistance_ohms = temperature_c_to_resistance_ohms(self.probe_temp_c, self.model)
        raw_code = resistance_ohms_to_raw_code(resistance_ohms, self.model)
        self._raw_register = (raw_code << 1) & 0xFFFF
        self._apply_fault_bit()
