"""Datasheet-grounded SHT31 peripheral model."""

from __future__ import annotations

from dataclasses import dataclass
import math


SHT31_I2C_ADDRESS = 0x44
SHT31_ALT_I2C_ADDRESS = 0x45

SHT31_CMD_MEASURE_HIGH_REPEATABILITY = 0x2400
SHT31_CMD_MEASURE_MEDIUM_REPEATABILITY = 0x240B
SHT31_CMD_MEASURE_LOW_REPEATABILITY = 0x2416
SHT31_CMD_MEASURE_HIGH_REPEATABILITY_CLOCK_STRETCH = 0x2C06
SHT31_CMD_MEASURE_MEDIUM_REPEATABILITY_CLOCK_STRETCH = 0x2C0D
SHT31_CMD_MEASURE_LOW_REPEATABILITY_CLOCK_STRETCH = 0x2C10
SHT31_CMD_READ_SERIAL_NUMBER = 0x3682

SHT31_MIN_COMMAND_GAP_MS = 1.0
SHT31_SERIAL_READ_DELAY_MS = 1.0

_MEASUREMENT_DELAY_MS = {
    SHT31_CMD_MEASURE_HIGH_REPEATABILITY: 15.0,
    SHT31_CMD_MEASURE_MEDIUM_REPEATABILITY: 6.0,
    SHT31_CMD_MEASURE_LOW_REPEATABILITY: 4.0,
    SHT31_CMD_MEASURE_HIGH_REPEATABILITY_CLOCK_STRETCH: 15.0,
    SHT31_CMD_MEASURE_MEDIUM_REPEATABILITY_CLOCK_STRETCH: 6.0,
    SHT31_CMD_MEASURE_LOW_REPEATABILITY_CLOCK_STRETCH: 4.0,
}


def compute_sht_crc(data: bytes) -> int:
    crc = 0xFF
    for byte in data:
        crc ^= byte
        for _ in range(8):
            if (crc & 0x80) != 0:
                crc = ((crc << 1) ^ 0x31) & 0xFF
            else:
                crc = (crc << 1) & 0xFF
    return crc


def _clamp(value: float, minimum: float, maximum: float) -> float:
    return max(minimum, min(maximum, value))


def _encode_word(word: int, crc_valid: bool) -> bytes:
    high = (word >> 8) & 0xFF
    low = word & 0xFF
    crc = compute_sht_crc(bytes((high, low)))
    if not crc_valid:
        crc ^= 0xFF
    return bytes((high, low, crc))


def _encode_temperature_raw(temperature_c: float) -> int:
    clamped = _clamp(temperature_c, -45.0, 130.0)
    return max(0, min(0xFFFF, int(round((clamped + 45.0) * 65535.0 / 175.0))))


def _encode_rh_raw(rh_percent: float) -> int:
    clamped = _clamp(rh_percent, 0.0, 100.0)
    return max(0, min(0xFFFF, int(round(clamped * 65535.0 / 100.0))))


@dataclass
class SHT31Model:
    """Single-shot SHT31 command/response model with datasheet timing."""

    temperature_c: float = 20.0
    rh_percent: float = 50.0
    serial_number: int = 0x12345678
    address: int = SHT31_I2C_ADDRESS
    bus_error: bool = False
    crc_valid: bool = True

    def __post_init__(self) -> None:
        self._now_ms = 0.0
        self._pending_response = None
        self._response_ready_at_ms = None
        self._last_command_at_ms = None

    def advance_time_ms(self, elapsed_ms: float) -> None:
        if not math.isfinite(elapsed_ms) or elapsed_ms < 0.0:
            raise ValueError("elapsed time must be finite and non-negative")
        self._now_ms += elapsed_ms

    def set_environment(self, temperature_c: float, rh_percent: float) -> None:
        if not math.isfinite(temperature_c) or not math.isfinite(rh_percent):
            raise ValueError("SHT31 environment values must be finite")
        self.temperature_c = temperature_c
        self.rh_percent = rh_percent

    def set_faults(self, *, bus_error: bool | None = None, crc_valid: bool | None = None) -> None:
        if bus_error is not None:
            self.bus_error = bus_error
        if crc_valid is not None:
            self.crc_valid = crc_valid

    @property
    def pending_response_length(self) -> int | None:
        if self._pending_response is None:
            return None
        return len(self._pending_response)

    def can_accept_command(self, command: int) -> bool:
        if self.bus_error:
            return False
        if (
            self._last_command_at_ms is not None
            and (self._now_ms - self._last_command_at_ms) < SHT31_MIN_COMMAND_GAP_MS
        ):
            return False
        return command == SHT31_CMD_READ_SERIAL_NUMBER or command in _MEASUREMENT_DELAY_MS

    def write_command(self, command: int) -> bool:
        if not self.can_accept_command(command):
            self._pending_response = None
            self._response_ready_at_ms = None
            return False

        if command == SHT31_CMD_READ_SERIAL_NUMBER:
            self._pending_response = self._serial_payload()
            self._response_ready_at_ms = self._now_ms + SHT31_SERIAL_READ_DELAY_MS
        else:
            self._pending_response = self._measurement_payload()
            self._response_ready_at_ms = self._now_ms + _MEASUREMENT_DELAY_MS[command]

        self._last_command_at_ms = self._now_ms
        return True

    def read(self, length: int) -> bytes | None:
        if self.bus_error or self._pending_response is None:
            return None
        if self._response_ready_at_ms is None or self._now_ms < self._response_ready_at_ms:
            return None
        if length != len(self._pending_response):
            return None
        payload = self._pending_response
        self._pending_response = None
        self._response_ready_at_ms = None
        return payload

    def transact(self, command: int, length: int, wait_ms: float | None = None) -> bytes | None:
        if not self.write_command(command):
            return None
        if wait_ms is None and self._response_ready_at_ms is not None:
            wait_ms = max(0.0, self._response_ready_at_ms - self._now_ms)
        if wait_ms is not None:
            self.advance_time_ms(wait_ms)
        return self.read(length)

    def _serial_payload(self) -> bytes:
        serial_number = self.serial_number & 0xFFFFFFFF
        upper = (serial_number >> 16) & 0xFFFF
        lower = serial_number & 0xFFFF
        return _encode_word(upper, self.crc_valid) + _encode_word(lower, self.crc_valid)

    def _measurement_payload(self) -> bytes:
        raw_temp = _encode_temperature_raw(self.temperature_c)
        raw_rh = _encode_rh_raw(self.rh_percent)
        return _encode_word(raw_temp, self.crc_valid) + _encode_word(raw_rh, self.crc_valid)
