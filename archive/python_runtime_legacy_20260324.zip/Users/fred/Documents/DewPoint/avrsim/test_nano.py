"""Board-side Nano air-node simulation tests."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from avrsim.nano import NanoAirNodeSim
from avrsim.peripherals import (
    COMMAND_READ_RX_BUFFER_RXB0SIDH,
    COMMAND_READ_STATUS,
    COMMAND_RTS_TX0,
    COMMAND_WRITE,
    REGISTER_TXB0SIDH,
    CanFrame,
    decode_sample_frame,
    encode_sample_frame,
)


def _spi_transaction(platform: NanoAirNodeSim, payload: bytes) -> bytes:
    platform.spi.begin_transaction()
    platform.gpio.digital_write(platform.pin_can_cs, 0)
    try:
        response = bytes(platform.spi.transfer(byte) for byte in payload)
    finally:
        platform.gpio.digital_write(platform.pin_can_cs, 1)
        platform.spi.end_transaction()
    return response


def _decode_sht31_measurement(payload: bytes) -> tuple[float, float]:
    raw_temp = (payload[0] << 8) | payload[1]
    raw_rh = (payload[3] << 8) | payload[4]
    temp_c = -45.0 + (175.0 * float(raw_temp) / 65535.0)
    rh_percent = 100.0 * float(raw_rh) / 65535.0
    return temp_c, rh_percent


def test_nano_air_node_board_profile_still_matches_live_pcb() -> None:
    platform = NanoAirNodeSim()
    report = platform.verify_board()
    assert report.ok


def test_wire_round_trips_to_sht31_model() -> None:
    platform = NanoAirNodeSim()
    platform.set_sensor_environment(23.45, 56.78)

    platform.wire.begin()
    platform.wire.begin_transmission(0x44)
    assert platform.wire.write(0x24) == 1
    assert platform.wire.write(0x00) == 1
    assert platform.wire.end_transmission() == 0

    assert platform.wire.request_from(0x44, 6) == 0
    platform.advance_time_ms(15.1)
    assert platform.wire.request_from(0x44, 6) == 6

    payload = bytes(platform.wire.read() for _ in range(6))
    temp_c, rh_percent = _decode_sht31_measurement(payload)
    assert abs(temp_c - 23.45) <= 0.03
    assert abs(rh_percent - 56.78) <= 0.03


def test_spi_bridge_transmits_mcp2515_frame_to_can_bus() -> None:
    platform = NanoAirNodeSim()
    sidh = 0x24
    sidl = 0x60
    write_payload = bytes(
        (
            COMMAND_WRITE,
            REGISTER_TXB0SIDH,
            sidh,
            sidl,
            0x00,
            0x00,
            0x03,
            0x11,
            0x22,
            0x33,
            0x00,
            0x00,
            0x00,
            0x00,
            0x00,
        )
    )

    assert _spi_transaction(platform, write_payload) == bytes(len(write_payload))
    assert _spi_transaction(platform, bytes((COMMAND_RTS_TX0,))) == b"\x00"

    status = _spi_transaction(platform, bytes((COMMAND_READ_STATUS, 0x00, 0x00)))
    assert status[1] != 0

    platform.advance_time_ms(1.0)
    frame = platform.receive_can_frame()
    assert frame is not None
    assert frame.frame_id == 0x123
    assert frame.length == 3
    assert frame.data[0:3] == (0x11, 0x22, 0x33)


def test_inbound_can_frame_reaches_mcp2515_rx_buffer_and_interrupt_pin() -> None:
    platform = NanoAirNodeSim()
    platform.inject_can_frame(encode_sample_frame(1, 21.5, 44.0, True, 7))
    platform.advance_time_ms(0.0)

    assert platform.gpio.digital_read(platform.pin_can_int) == 0

    response = _spi_transaction(platform, bytes((COMMAND_READ_RX_BUFFER_RXB0SIDH,)) + bytes(13))
    raw = response[1:]
    frame = CanFrame(
        frame_id=((raw[0] << 3) | (raw[1] >> 5)),
        length=raw[4] & 0x0F,
        data=tuple(raw[5 + index] for index in range(8)),
    )
    sample = decode_sample_frame(frame)
    assert sample.node_id == 1
    assert abs(sample.temp_c - 21.5) <= 0.01
    assert abs(sample.rh_percent - 44.0) <= 0.01
    assert sample.sequence == 7

    assert platform.gpio.digital_read(platform.pin_can_int) == 1


def main() -> int:
    test_nano_air_node_board_profile_still_matches_live_pcb()
    test_wire_round_trips_to_sht31_model()
    test_spi_bridge_transmits_mcp2515_frame_to_can_bus()
    test_inbound_can_frame_reaches_mcp2515_rx_buffer_and_interrupt_pin()
    print("avrsim Nano air-node tests passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
