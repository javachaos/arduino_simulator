"""ATmega2560 Mega runtime tests."""

from __future__ import annotations

import io
import sys
import tempfile
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from avrsim.arduino_turbo import ArduinoTimer0DelayTurbo
from avrsim.cli import main as cli_main
from avrsim.cpu import CPU, CPUConfig
from avrsim.mcu import (
    ADCH,
    ADCL,
    ADCSRA,
    ADCSRB,
    ADMUX,
    ADSC,
    ADEN,
    Atmega2560,
    DDRA,
    DDRC,
    EEARH,
    EEARL,
    EECR,
    EEDR,
    OCR5CL,
    PORTA,
    PORTC,
    RXC0,
    RXEN0,
    SPCR,
    SPDR,
    SPE,
    TCCR0B,
    TCNT0,
    TIMSK0,
    TOIE0,
    TXEN0,
    UBRR0L,
    UCSR0A,
    UCSR0B,
    UDR0,
    UDRE0,
)
from avrsim.mcu.atmega2560 import (
    ADC_VECTOR,
    ADIF,
    EEMPE,
    EEPE,
    EERE,
    MSTR,
    MUX5,
    TIMER0_OVF_VECTOR,
)
from avrsim.mega import MegaSidecarSim
from avrsim.mega_runtime import MegaSidecarFirmwareSim
from avrsim.peripherals import (
    COMMAND_RTS_TX0,
    COMMAND_WRITE,
    FILTER_60HZ,
    REGISTER_TXB0SIDH,
    build_config_byte,
    pt1000_model,
    raw_code_to_resistance_ohms,
    resistance_ohms_to_temperature_c,
)


def _ldi(d: int, k: int) -> int:
    if d < 16 or d > 31:
        raise ValueError("LDI targets registers 16..31")
    return 0xE000 | ((k & 0xF0) << 4) | ((d - 16) << 4) | (k & 0x0F)


def _out(a: int, r: int) -> int:
    return 0xB800 | ((a & 0x30) << 5) | ((r & 0x1F) << 4) | (a & 0x0F)


def _sts(r: int, address: int) -> tuple[int, int]:
    return 0x9200 | ((r & 0x1F) << 4), address & 0xFFFF


def _bset(bit_index: int) -> int:
    return 0x9408 | ((bit_index & 0x07) << 4)


def _inc(d: int) -> int:
    return 0x9403 | ((d & 0x1F) << 4)


def _reti() -> int:
    return 0x9518


def _break() -> int:
    return 0x9598


def _call(target: int) -> tuple[int, int]:
    return 0x940E | ((target >> 16) & 0x0001) | ((target >> 13) & 0x01F0), target & 0xFFFF


def _hex_record(address: int, record_type: int, payload: bytes) -> str:
    body = bytes(((len(payload) & 0xFF), (address >> 8) & 0xFF, address & 0xFF, record_type & 0xFF)) + payload
    checksum = (-sum(body)) & 0xFF
    return ":" + (body + bytes((checksum,))).hex().upper()


def _write_program_hex(path: Path, words: list[int]) -> None:
    program_bytes = bytearray()
    for word in words:
        program_bytes.append(word & 0xFF)
        program_bytes.append((word >> 8) & 0xFF)
    records: list[str] = []
    for offset in range(0, len(program_bytes), 16):
        chunk = bytes(program_bytes[offset : offset + 16])
        records.append(_hex_record(offset, 0x00, chunk))
    records.append(_hex_record(0x0000, 0x01, b""))
    path.write_text("\n".join(records) + "\n", encoding="utf-8")


def test_port_registers_drive_sensor_status_leds() -> None:
    board = MegaSidecarSim()
    mcu = Atmega2560(board=board)
    cpu = CPU(CPUConfig.atmega2560(), hooks=mcu)

    cpu.write_data(DDRC, 0xF0)
    cpu.write_data(PORTC, 0xA0)
    assert board.sensor_status_leds == (True, False, True, False)


def test_spi_mmio_reaches_the_mcp2515_board_model() -> None:
    board = MegaSidecarSim()
    mcu = Atmega2560(board=board)
    cpu = CPU(CPUConfig.atmega2560(), hooks=mcu)

    cpu.write_data(DDRA, 1 << 5)
    cpu.write_data(PORTA, 1 << 5)
    cpu.write_data(SPCR, SPE | MSTR)

    write_payload = bytes(
        (
            COMMAND_WRITE,
            REGISTER_TXB0SIDH,
            0x24,
            0x60,
            0x00,
            0x00,
            0x03,
            0x11,
            0x22,
            0x33,
            0x00,
            0x00,
            0x00,
            0x00,
            0x00,
        )
    )

    cpu.write_data(PORTA, 0x00)
    for byte in write_payload:
        cpu.write_data(SPDR, byte)
        cpu.read_data(SPDR)
    cpu.write_data(PORTA, 1 << 5)

    cpu.write_data(PORTA, 0x00)
    cpu.write_data(SPDR, COMMAND_RTS_TX0)
    cpu.read_data(SPDR)
    cpu.write_data(PORTA, 1 << 5)

    board.advance_time_ms(1.0)
    frame = board.receive_can_frame()
    assert frame is not None
    assert frame.frame_id == 0x123
    assert frame.length == 3
    assert frame.data[0:3] == (0x11, 0x22, 0x33)


def test_spi_mmio_reads_a_real_max31865_measurement() -> None:
    board = MegaSidecarSim()
    board.set_pipe_temperature(11.25)
    mcu = Atmega2560(board=board)
    cpu = CPU(CPUConfig.atmega2560(), hooks=mcu)

    cpu.write_data(DDRA, 1 << 4)
    cpu.write_data(PORTA, 1 << 4)
    cpu.write_data(SPCR, SPE | MSTR)

    config = build_config_byte(True, True, False, False, FILTER_60HZ)

    cpu.write_data(PORTA, 0x00)
    cpu.write_data(SPDR, 0x80)
    cpu.read_data(SPDR)
    cpu.write_data(SPDR, config)
    cpu.read_data(SPDR)
    cpu.write_data(PORTA, 1 << 4)

    board.advance_time_ms(60.0)

    cpu.write_data(PORTA, 0x00)
    cpu.write_data(SPDR, 0x01)
    cpu.read_data(SPDR)
    cpu.write_data(SPDR, 0x00)
    msb = cpu.read_data(SPDR)
    cpu.write_data(SPDR, 0x00)
    lsb = cpu.read_data(SPDR)
    cpu.write_data(PORTA, 1 << 4)

    raw_register = (msb << 8) | lsb
    raw_code = raw_register >> 1
    resistance = raw_code_to_resistance_ohms(raw_code, pt1000_model())
    temp_c = resistance_ohms_to_temperature_c(resistance, pt1000_model())
    assert abs(temp_c - 11.25) <= 0.1


def test_adc_reads_a10_feedback_voltage() -> None:
    board = MegaSidecarSim()
    board.set_actuator_feedback_voltage(7.5)
    mcu = Atmega2560(board=board)
    cpu = CPU(CPUConfig.atmega2560(), hooks=mcu)

    cpu.write_data(ADMUX, 0x02)
    cpu.write_data(ADCSRB, MUX5)
    cpu.write_data(ADCSRA, ADEN | ADSC | 0x07)
    mcu.advance_cycles(cpu, 1700)

    adc_value = cpu.read_data(ADCL) | (cpu.read_data(ADCH) << 8)
    assert 766 <= adc_value <= 768
    assert (cpu.read_data(ADCSRA) & ADSC) == 0
    assert (cpu.read_data(ADCSRA) & ADIF) != 0


def test_eeprom_read_write_round_trip() -> None:
    board = MegaSidecarSim()
    mcu = Atmega2560(board=board)
    cpu = CPU(CPUConfig.atmega2560(), hooks=mcu)

    cpu.write_data(EEARL, 0x34)
    cpu.write_data(EEARH, 0x02)
    cpu.write_data(EEDR, 0x5A)
    cpu.write_data(EECR, EEMPE)
    cpu.write_data(EECR, EEPE)

    cpu.write_data(EEDR, 0x00)
    cpu.write_data(EECR, EERE)
    assert cpu.read_data(EEDR) == 0x5A


def test_timer0_overflow_interrupt_vectors_into_the_isr() -> None:
    board = MegaSidecarSim()
    mcu = Atmega2560(board=board)
    cpu = CPU(CPUConfig.atmega2560(), hooks=mcu)

    program = [
        _ldi(16, TOIE0),
        *_sts(16, TIMSK0),
        _ldi(16, 0xFF),
        _out(TCNT0 - 0x20, 16),
        _ldi(16, 0x01),
        _out(TCCR0B - 0x20, 16),
        _bset(7),
        0x0000,
        0x0000,
        _break(),
    ]
    while len(program) < (TIMER0_OVF_VECTOR * 2):
        program.append(0x0000)
    program.extend([_inc(17), _reti()])
    cpu.load_program_words(program)

    cpu.run(max_instructions=32)

    assert cpu.read_register(17) == 1
    assert cpu.break_hit


def test_usart0_tx_capture_collects_transmitted_bytes() -> None:
    board = MegaSidecarSim()
    mcu = Atmega2560(board=board)
    cpu = CPU(CPUConfig.atmega2560(), hooks=mcu)

    cpu.write_data(UBRR0L, 0x00)
    cpu.write_data(UCSR0B, TXEN0)
    assert (cpu.read_data(UCSR0A) & UDRE0) != 0

    cpu.write_data(UDR0, ord("M"))
    assert mcu.serial_output_bytes == b""
    mcu.advance_cycles(cpu, 200)

    assert mcu.serial_output_bytes == b"M"


def test_usart0_rx_injection_lands_in_the_data_register() -> None:
    board = MegaSidecarSim()
    mcu = Atmega2560(board=board)
    cpu = CPU(CPUConfig.atmega2560(), hooks=mcu)

    cpu.write_data(UCSR0B, RXEN0)
    mcu.inject_usart0_rx(cpu, b"Z")

    assert (cpu.read_data(UCSR0A) & RXC0) != 0
    assert cpu.read_data(UDR0) == ord("Z")


def test_runtime_exposes_serial_capture_helpers() -> None:
    sim = MegaSidecarFirmwareSim()
    sim.cpu.write_data(UBRR0L, 0x00)
    sim.cpu.write_data(UCSR0B, TXEN0)
    sim.cpu.write_data(UDR0, ord("G"))
    sim.mcu.advance_cycles(sim.cpu, 200)

    assert sim.serial_output_bytes == b"G"
    assert sim.serial_output_text() == "G"
    sim.clear_serial_output()
    assert sim.serial_output_bytes == b""

    sim.cpu.write_data(UCSR0B, RXEN0)
    sim.inject_serial_rx(b"H")
    assert sim.cpu.read_data(UDR0) == ord("H")


def test_runtime_can_enable_experimental_block_jit() -> None:
    sim = MegaSidecarFirmwareSim(enable_block_jit=True)
    assert sim.cpu.enable_block_jit


def test_runtime_can_run_until_serial_output() -> None:
    sim = MegaSidecarFirmwareSim()
    sim.cpu.load_program_words([0x0000] * 512)
    sim.cpu.write_data(UBRR0L, 0x00)
    sim.cpu.write_data(UCSR0B, TXEN0)
    sim.cpu.write_data(UDR0, ord("S"))

    executed = sim.run_until_serial_output(max_instructions=256, chunk_size=16)

    assert executed > 0
    assert sim.serial_output_text() == "S"


def test_arduino_delay_turbo_fast_forwards_timer0_and_returns_to_the_caller() -> None:
    turbo = ArduinoTimer0DelayTurbo(
        delay_word_address=16,
        timer0_fract_data_address=0x300,
        timer0_millis_data_address=0x301,
        timer0_overflow_count_data_address=0x305,
    )
    sim = MegaSidecarFirmwareSim()
    sim.configure_arduino_delay_turbo(turbo)

    program = [
        _ldi(22, 120),
        _ldi(23, 0),
        _ldi(24, 0),
        _ldi(25, 0),
        *_call(turbo.delay_word_address),
        _break(),
    ]
    while len(program) < turbo.delay_word_address:
        program.append(0x0000)
    program.append(_break())

    sim.cpu.load_program_words(program)
    sim.cpu.write_data(TCCR0B, 0x03)
    sim.cpu.write_data(TIMSK0, TOIE0)
    sim.cpu.set_flag(7, 1)

    executed = sim.run(max_instructions=16)

    timer0_millis = (
        sim.cpu.read_data(turbo.timer0_millis_data_address)
        | (sim.cpu.read_data(turbo.timer0_millis_data_address + 1) << 8)
        | (sim.cpu.read_data(turbo.timer0_millis_data_address + 2) << 16)
        | (sim.cpu.read_data(turbo.timer0_millis_data_address + 3) << 24)
    )
    timer0_overflows = (
        sim.cpu.read_data(turbo.timer0_overflow_count_data_address)
        | (sim.cpu.read_data(turbo.timer0_overflow_count_data_address + 1) << 8)
        | (sim.cpu.read_data(turbo.timer0_overflow_count_data_address + 2) << 16)
        | (sim.cpu.read_data(turbo.timer0_overflow_count_data_address + 3) << 24)
    )

    assert executed > 0
    assert sim.cpu.break_hit
    assert sim.cpu.sp == sim.cpu.config.stack_reset_value
    assert timer0_millis == 119
    assert sim.cpu.read_data(turbo.timer0_fract_data_address) == 101
    assert timer0_overflows == 117
    assert sim.cpu.read_data(TCNT0) == 48


def test_runtime_loads_a_small_intel_hex_program() -> None:
    with tempfile.TemporaryDirectory() as temp_dir:
        hex_path = Path(temp_dir) / "tiny.hex"
        hex_path.write_text(
            "\n".join(
                (
                    _hex_record(0x0000, 0x00, bytes((0x98, 0x95))),
                    _hex_record(0x0000, 0x01, b""),
                )
            )
            + "\n",
            encoding="utf-8",
        )

        sim = MegaSidecarFirmwareSim()
        sim.load_hex(hex_path)
        sim.run(max_instructions=1)
        assert sim.cpu.break_hit


def test_run_mega_cli_prints_serial_output() -> None:
    with tempfile.TemporaryDirectory() as temp_dir:
        hex_path = Path(temp_dir) / "serial.hex"
        program = [
            _ldi(16, 0x00),
            *_sts(16, UBRR0L),
            _ldi(16, TXEN0),
            *_sts(16, UCSR0B),
            _ldi(16, ord("Q")),
            *_sts(16, UDR0),
        ]
        program.extend([0x0000] * 200)
        program.append(_break())
        _write_program_hex(hex_path, program)

        stdout_buffer = io.StringIO()
        with redirect_stdout(stdout_buffer):
            exit_code = cli_main(
                [
                    "run-mega",
                    str(hex_path),
                    "--jit",
                    "--until-serial",
                    "--chunk-size",
                    "16",
                ]
            )

        assert exit_code == 0
        assert stdout_buffer.getvalue() == "Q"


def test_run_mega_cli_reports_missing_serial_output() -> None:
    with tempfile.TemporaryDirectory() as temp_dir:
        hex_path = Path(temp_dir) / "silent.hex"
        _write_program_hex(hex_path, [0x0000] * 128)

        stdout_buffer = io.StringIO()
        stderr_buffer = io.StringIO()
        with redirect_stdout(stdout_buffer), redirect_stderr(stderr_buffer):
            exit_code = cli_main(
                [
                    "run-mega",
                    str(hex_path),
                    "--until-serial",
                    "--chunk-size",
                    "16",
                    "--max-instructions",
                    "64",
                ]
            )

        assert exit_code == 1
        assert stdout_buffer.getvalue() == ""
        assert "no serial output captured" in stderr_buffer.getvalue()


def main() -> int:
    test_port_registers_drive_sensor_status_leds()
    test_spi_mmio_reaches_the_mcp2515_board_model()
    test_spi_mmio_reads_a_real_max31865_measurement()
    test_adc_reads_a10_feedback_voltage()
    test_eeprom_read_write_round_trip()
    test_timer0_overflow_interrupt_vectors_into_the_isr()
    test_usart0_tx_capture_collects_transmitted_bytes()
    test_usart0_rx_injection_lands_in_the_data_register()
    test_runtime_exposes_serial_capture_helpers()
    test_runtime_can_enable_experimental_block_jit()
    test_runtime_can_run_until_serial_output()
    test_arduino_delay_turbo_fast_forwards_timer0_and_returns_to_the_caller()
    test_runtime_loads_a_small_intel_hex_program()
    test_run_mega_cli_prints_serial_output()
    test_run_mega_cli_reports_missing_serial_output()
    print("avrsim Mega runtime tests passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
