"""Compiled-firmware runtime wrapper for the Mega sidecar controller."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from .arduino_turbo import ArduinoTimer0DelayTurbo
from .cpu import CPU, CPUConfig
from .firmware import ProgramImage, load_intel_hex
from .mcu import Atmega2560
from .mega import MegaSidecarSim


MEGA_CLOCK_HZ = 16_000_000


@dataclass
class MegaSidecarFirmwareSim:
    """Bind the AVR CPU core to the Mega sidecar board simulation."""

    board: MegaSidecarSim = field(default_factory=MegaSidecarSim)
    clock_hz: int = MEGA_CLOCK_HZ
    enable_block_jit: bool = False
    mcu: Atmega2560 = field(init=False)
    cpu: CPU = field(init=False)

    def __post_init__(self) -> None:
        self.mcu = Atmega2560(board=self.board, clock_hz=self.clock_hz)
        self.cpu = CPU(
            config=CPUConfig.atmega2560(),
            hooks=self.mcu,
            enable_block_jit=self.enable_block_jit,
        )

    def reset(self, *, clear_program: bool = False) -> None:
        self.cpu.reset(clear_program=clear_program)

    def load_hex(self, path: str | Path, *, clear_program: bool = True) -> ProgramImage:
        image = load_intel_hex(path)
        image.load_into_cpu(self.cpu, clear_program=clear_program)
        return image

    def enable_arduino_delay_turbo(
        self,
        elf_path: str | Path,
        *,
        nm_path: str | Path | None = None,
    ) -> ArduinoTimer0DelayTurbo:
        turbo = ArduinoTimer0DelayTurbo.from_elf(elf_path, nm_path=nm_path)
        self.mcu.arduino_delay_turbo = turbo
        return turbo

    def configure_arduino_delay_turbo(self, turbo: ArduinoTimer0DelayTurbo | None) -> None:
        self.mcu.arduino_delay_turbo = turbo

    def run(self, max_instructions: int | None = None, *, stop_on_break: bool = True) -> int:
        return self.cpu.run(
            max_instructions=max_instructions,
            stop_on_break=stop_on_break,
            stop_on_sleep=False,
        )

    def run_until(
        self,
        predicate: Callable[["MegaSidecarFirmwareSim"], bool],
        *,
        max_instructions: int,
        chunk_size: int = 1000,
    ) -> int:
        executed = 0
        while executed < max_instructions and not predicate(self):
            batch = min(chunk_size, max_instructions - executed)
            executed += self.run(batch, stop_on_break=False)
        return executed

    def run_until_serial_output(
        self,
        *,
        min_bytes: int = 1,
        max_instructions: int,
        chunk_size: int = 1000,
    ) -> int:
        if min_bytes <= 0:
            raise ValueError("min_bytes must be positive")
        return self.run_until(
            lambda sim: len(sim.serial_output_bytes) >= min_bytes,
            max_instructions=max_instructions,
            chunk_size=chunk_size,
        )

    @property
    def serial_output_bytes(self) -> bytes:
        return self.mcu.serial_output_bytes

    def serial_output_text(self, *, encoding: str = "utf-8", errors: str = "replace") -> str:
        return self.mcu.serial_output_text(encoding=encoding, errors=errors)

    def clear_serial_output(self) -> None:
        self.mcu.clear_serial_output()

    def inject_serial_rx(self, payload: bytes | bytearray) -> None:
        self.mcu.inject_usart0_rx(self.cpu, payload)


__all__ = [
    "MEGA_CLOCK_HZ",
    "MegaSidecarFirmwareSim",
]
