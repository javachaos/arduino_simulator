"""Nano-class board-side simulation helpers for avrsim.

This first Nano layer focuses on the real `air_node` hardware path:

- Arduino-style GPIO state
- Arduino-style `Wire` single-master I2C transactions
- Arduino-style `SPI` transactions with chip-select driven device selection
- SHT31 sensor model on the I2C bus
- MCP2515 controller model bridged to project-level CAN frames

It intentionally models the board-side hardware first. The CPU/MMIO bridge can
be layered on later without changing the peripheral-facing APIs here.
"""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Protocol
import math

from .behavior import BoardVerification, load_built_in_profile, verify_board
from .kicad_pcb import board_from_kicad_pcb
from .peripherals import (
    COMMAND_READ_RX_BUFFER_RXB0SIDH,
    COMMAND_RTS_TX0,
    COMMAND_WRITE,
    MCP2515Model,
    Mcp2515Frame,
    REGISTER_CANINTF,
    SHT31_I2C_ADDRESS,
    SHT31Model,
    CanBusModel,
    CanFrame,
)


REPO_ROOT = Path("/Users/fred/Documents/DewPoint")
AIR_NODE_PCB_PATH = REPO_ROOT / "dewpoint_controller/pcb/air_node/air_node.kicad_pcb"

INPUT = "INPUT"
OUTPUT = "OUTPUT"
INPUT_PULLUP = "INPUT_PULLUP"


class I2CDeviceAdapter(Protocol):
    def write(self, payload: bytes) -> bool:
        """Handle one endTransmission payload."""

    def read(self, length: int) -> bytes | None:
        """Handle one requestFrom read."""

    def advance_time_ms(self, elapsed_ms: float) -> None:
        """Advance device-local time."""


class SPIDeviceAdapter(Protocol):
    def preview_transaction(self, data_out: bytes) -> bytes:
        """Return the bytewise response without committing side effects."""

    def commit_transaction(self, data_out: bytes) -> bytes:
        """Apply one completed SPI transaction."""

    def advance_time_ms(self, elapsed_ms: float) -> None:
        """Advance device-local time."""


@dataclass
class SimulationClock:
    """Small deterministic monotonic time base."""

    now_us: int = 0
    _fractional_us: float = 0.0

    @property
    def now_ms(self) -> float:
        return self.now_us / 1000.0

    def advance_ms(self, elapsed_ms: float) -> None:
        if not math.isfinite(elapsed_ms) or elapsed_ms < 0.0:
            raise ValueError("elapsed_ms must be finite and non-negative")
        self._fractional_us += elapsed_ms * 1000.0
        whole_us = int(self._fractional_us)
        if whole_us > 0:
            self.now_us += whole_us
            self._fractional_us -= float(whole_us)

    def advance_us(self, elapsed_us: int) -> None:
        if elapsed_us < 0:
            raise ValueError("elapsed_us must be non-negative")
        self.now_us += int(elapsed_us)


@dataclass
class _PinState:
    mode: str = INPUT
    output_level: int = 0
    input_level: int = 0


@dataclass
class GPIOBank:
    """Minimal Arduino-style GPIO state."""

    pins: dict[str, _PinState] = field(default_factory=dict)
    _external_readers: dict[str, Callable[[], int]] = field(default_factory=dict)

    def define_pin(self, pin_name: str, *, initial_mode: str = INPUT, initial_level: int = 0) -> None:
        self.pins[pin_name] = _PinState(
            mode=initial_mode,
            output_level=1 if initial_level else 0,
            input_level=1 if initial_level else 0,
        )

    def pin_mode(self, pin_name: str, mode: str) -> None:
        pin = self._pin(pin_name)
        if mode not in (INPUT, OUTPUT, INPUT_PULLUP):
            raise ValueError(f"unsupported pin mode {mode}")
        pin.mode = mode
        if mode == INPUT_PULLUP and pin_name not in self._external_readers:
            pin.input_level = 1

    def digital_write(self, pin_name: str, level: int | bool) -> None:
        pin = self._pin(pin_name)
        normalized = 1 if level else 0
        if pin.mode == OUTPUT:
            pin.output_level = normalized
            return
        if pin.mode == INPUT_PULLUP:
            pin.input_level = normalized
            return
        pin.input_level = normalized

    def digital_read(self, pin_name: str) -> int:
        pin = self._pin(pin_name)
        if pin.mode == OUTPUT:
            return pin.output_level
        if pin_name in self._external_readers:
            return 1 if self._external_readers[pin_name]() else 0
        if pin.mode == INPUT_PULLUP:
            return 1
        return 1 if pin.input_level else 0

    def set_input_level(self, pin_name: str, level: int | bool) -> None:
        self._pin(pin_name).input_level = 1 if level else 0

    def attach_external_reader(self, pin_name: str, reader: Callable[[], int]) -> None:
        self._pin(pin_name)
        self._external_readers[pin_name] = reader

    def _pin(self, pin_name: str) -> _PinState:
        if pin_name not in self.pins:
            raise KeyError(f"unknown GPIO pin {pin_name}")
        return self.pins[pin_name]


@dataclass
class WireSHT31Adapter:
    """Wire-facing wrapper for the SHT31 datasheet model."""

    model: SHT31Model

    def write(self, payload: bytes) -> bool:
        if len(payload) != 2:
            return False
        command = (payload[0] << 8) | payload[1]
        return self.model.write_command(command)

    def preview_write(self, payload: bytes) -> bool:
        if len(payload) > 2:
            return False
        if len(payload) < 2:
            return not self.model.bus_error
        command = (payload[0] << 8) | payload[1]
        return self.model.can_accept_command(command)

    def read(self, length: int) -> bytes | None:
        return self.model.read(length)

    def peek_read_length(self) -> int | None:
        return self.model.pending_response_length

    def advance_time_ms(self, elapsed_ms: float) -> None:
        self.model.advance_time_ms(elapsed_ms)


@dataclass
class WireSim:
    """Small subset of Arduino `Wire` for single-controller transactions."""

    devices: dict[int, I2CDeviceAdapter] = field(default_factory=dict)
    clock_hz: int = 100000
    _tx_address: int | None = None
    _tx_buffer: bytearray = field(default_factory=bytearray)
    _rx_buffer: bytearray = field(default_factory=bytearray)
    _rx_index: int = 0

    def begin(self) -> None:
        pass

    def set_clock(self, clock_hz: int) -> None:
        if clock_hz <= 0:
            raise ValueError("clock_hz must be positive")
        self.clock_hz = int(clock_hz)

    def attach_device(self, address: int, device: I2CDeviceAdapter) -> None:
        if address < 0 or address > 0x7F:
            raise ValueError("I2C address must be between 0x00 and 0x7F")
        self.devices[address] = device

    def begin_transmission(self, address: int) -> None:
        self._tx_address = address & 0x7F
        self._tx_buffer = bytearray()

    def write(self, value: int) -> int:
        if self._tx_address is None:
            raise RuntimeError("begin_transmission() must be called before write()")
        self._tx_buffer.append(value & 0xFF)
        return 1

    def end_transmission(self) -> int:
        if self._tx_address is None:
            raise RuntimeError("no active transmission")
        address = self._tx_address
        payload = bytes(self._tx_buffer)
        self._tx_address = None
        self._tx_buffer = bytearray()
        device = self.devices.get(address)
        if device is None:
            return 2
        return 0 if device.write(payload) else 4

    def request_from(self, address: int, length: int) -> int:
        device = self.devices.get(address & 0x7F)
        self._rx_buffer = bytearray()
        self._rx_index = 0
        if device is None:
            return 0
        payload = device.read(length)
        if payload is None or len(payload) != length:
            return 0
        self._rx_buffer = bytearray(payload)
        return len(self._rx_buffer)

    def available(self) -> int:
        return len(self._rx_buffer) - self._rx_index

    def read(self) -> int:
        if self._rx_index >= len(self._rx_buffer):
            return -1
        value = self._rx_buffer[self._rx_index]
        self._rx_index += 1
        return value

    def advance_time_ms(self, elapsed_ms: float) -> None:
        for device in self.devices.values():
            device.advance_time_ms(elapsed_ms)


@dataclass
class MCP2515SpiAdapter:
    """SPI-facing wrapper that preserves bytewise transaction semantics."""

    model: MCP2515Model

    def preview_transaction(self, data_out: bytes) -> bytes:
        try:
            preview_model = deepcopy(self.model)
            return preview_model.spi_transaction(data_out)
        except ValueError:
            return bytes(len(data_out))

    def commit_transaction(self, data_out: bytes) -> bytes:
        try:
            return self.model.spi_transaction(data_out)
        except ValueError:
            return bytes(len(data_out))

    def advance_time_ms(self, elapsed_ms: float) -> None:
        self.model.advance_time_ms(elapsed_ms)


@dataclass
class SPISim:
    """Small subset of Arduino `SPI` with chip-select-driven device routing."""

    gpio: GPIOBank
    devices_by_cs_pin: dict[str, SPIDeviceAdapter] = field(default_factory=dict)
    settings: object | None = None
    _transaction_buffer: bytearray = field(default_factory=bytearray)
    _in_transaction: bool = False
    _selected_device: SPIDeviceAdapter | None = None

    def begin(self) -> None:
        pass

    def attach_device(self, cs_pin_name: str, device: SPIDeviceAdapter) -> None:
        self.devices_by_cs_pin[cs_pin_name] = device

    def begin_transaction(self, settings: object | None = None) -> None:
        self.settings = settings
        self._transaction_buffer = bytearray()
        self._in_transaction = True
        self._selected_device = None

    def transfer(self, value: int) -> int:
        if not self._in_transaction:
            raise RuntimeError("begin_transaction() must be called before transfer()")
        device = self._active_device()
        if self._selected_device is None:
            self._selected_device = device
        elif self._selected_device is not device:
            raise RuntimeError("SPI chip select changed mid-transaction")
        self._transaction_buffer.append(value & 0xFF)
        preview = device.preview_transaction(bytes(self._transaction_buffer))
        if not preview:
            return 0
        return preview[-1]

    def end_transaction(self) -> None:
        if not self._in_transaction:
            return
        if self._transaction_buffer:
            try:
                device = self._selected_device
                if device is not None:
                    device.commit_transaction(bytes(self._transaction_buffer))
            finally:
                self._transaction_buffer = bytearray()
        self._in_transaction = False
        self.settings = None
        self._selected_device = None

    def advance_time_ms(self, elapsed_ms: float) -> None:
        for device in self.devices_by_cs_pin.values():
            device.advance_time_ms(elapsed_ms)

    def _active_device(self, *, allow_none: bool = False) -> SPIDeviceAdapter | None:
        active_devices = [
            device
            for pin_name, device in self.devices_by_cs_pin.items()
            if self.gpio.digital_read(pin_name) == 0
        ]
        if not active_devices:
            if allow_none:
                return None
            raise RuntimeError("no SPI device is currently selected")
        if len(active_devices) > 1:
            raise RuntimeError("multiple SPI devices are selected at the same time")
        return active_devices[0]


@dataclass
class MCP2515CanBridge:
    """Bridges the controller model to project-level CAN frames."""

    controller: MCP2515Model
    outbound_bus: CanBusModel = field(default_factory=CanBusModel)
    _pending_inbound_frames: list[CanFrame] = field(default_factory=list)
    _next_tx_index: int = 0

    def inject_can_frame(self, frame: CanFrame) -> None:
        self._pending_inbound_frames.append(frame)

    def receive_can_frame(self) -> CanFrame | None:
        return self.outbound_bus.receive()

    def advance_time_ms(self, elapsed_ms: float) -> None:
        self.controller.advance_time_ms(elapsed_ms)
        while self._next_tx_index < len(self.controller.transmitted_frames):
            frame = self.controller.transmitted_frames[self._next_tx_index]
            self.outbound_bus.send(
                CanFrame(
                    frame_id=frame.frame_id,
                    length=frame.dlc,
                    data=frame.data,
                )
            )
            self._next_tx_index += 1
        self._deliver_inbound_frames()

    def interrupt_active_low(self) -> bool:
        return self.controller.read_register(REGISTER_CANINTF) != 0

    def _deliver_inbound_frames(self) -> None:
        while self._pending_inbound_frames and not self.controller.message_pending():
            next_frame = self._pending_inbound_frames.pop(0)
            self.controller.inject_received_frame(
                Mcp2515Frame(
                    frame_id=next_frame.frame_id,
                    dlc=next_frame.length,
                    data=next_frame.data,
                ),
                buffer_index=0,
            )


@dataclass
class NanoAirNodeSim:
    """Board-side simulation of the `air_node` Nano + MCP2515 + SHT31 hardware."""

    clock: SimulationClock = field(default_factory=SimulationClock)
    gpio: GPIOBank = field(default_factory=GPIOBank)
    sht31: SHT31Model = field(default_factory=SHT31Model)
    mcp2515: MCP2515Model = field(default_factory=MCP2515Model)
    can_bridge: MCP2515CanBridge = field(init=False)
    wire: WireSim = field(init=False)
    spi: SPISim = field(init=False)

    pin_can_cs: str = "D10"
    pin_can_int: str = "D2"
    pin_status_led: str = "D13"
    pin_sht31_sda: str = "A4"
    pin_sht31_scl: str = "A5"

    def __post_init__(self) -> None:
        self._define_default_pins()
        self.can_bridge = MCP2515CanBridge(self.mcp2515)
        self.wire = WireSim()
        self.spi = SPISim(self.gpio)
        self.wire.attach_device(SHT31_I2C_ADDRESS, WireSHT31Adapter(self.sht31))
        self.spi.attach_device(self.pin_can_cs, MCP2515SpiAdapter(self.mcp2515))
        self.gpio.attach_external_reader(
            self.pin_can_int,
            lambda: 0 if self.can_bridge.interrupt_active_low() else 1,
        )

    def advance_time_ms(self, elapsed_ms: float) -> None:
        self.clock.advance_ms(elapsed_ms)
        self.wire.advance_time_ms(elapsed_ms)
        self.spi.advance_time_ms(elapsed_ms)
        self.can_bridge.advance_time_ms(elapsed_ms)

    def set_sensor_environment(self, temperature_c: float, rh_percent: float) -> None:
        self.sht31.set_environment(temperature_c, rh_percent)

    def set_sensor_faults(self, *, bus_error: bool | None = None, crc_valid: bool | None = None) -> None:
        self.sht31.set_faults(bus_error=bus_error, crc_valid=crc_valid)

    def inject_can_frame(self, frame: CanFrame) -> None:
        self.can_bridge.inject_can_frame(frame)

    def receive_can_frame(self) -> CanFrame | None:
        return self.can_bridge.receive_can_frame()

    def verify_board(self) -> BoardVerification:
        board = board_from_kicad_pcb(str(AIR_NODE_PCB_PATH))
        profile = load_built_in_profile(board.name)
        return verify_board(board, profile)

    @property
    def status_led_on(self) -> bool:
        return self.gpio.digital_read(self.pin_status_led) != 0

    def _define_default_pins(self) -> None:
        for pin_name in [
            "D0",
            "D1",
            "D2",
            "D3",
            "D4",
            "D5",
            "D6",
            "D7",
            "D8",
            "D9",
            "D10",
            "D11",
            "D12",
            "D13",
            "A0",
            "A1",
            "A2",
            "A3",
            "A4",
            "A5",
            "A6",
            "A7",
        ]:
            self.gpio.define_pin(pin_name)
        self.gpio.pin_mode(self.pin_can_cs, OUTPUT)
        self.gpio.digital_write(self.pin_can_cs, 1)
        self.gpio.pin_mode(self.pin_status_led, OUTPUT)
        self.gpio.digital_write(self.pin_status_led, 0)
        self.gpio.pin_mode(self.pin_can_int, INPUT_PULLUP)


__all__ = [
    "AIR_NODE_PCB_PATH",
    "GPIOBank",
    "INPUT",
    "INPUT_PULLUP",
    "NanoAirNodeSim",
    "OUTPUT",
    "SPISim",
    "SimulationClock",
    "WireSim",
]
