"""Native GUI view-model generation for avrsim."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from .behavior import BoardVerification, format_verification_report, load_built_in_profile, verify_board
from .kicad_layout import layout_from_kicad_pcb
from .kicad_pcb import board_from_kicad_pcb
from .layout import BoardLayout
from .peripherals.max31865 import FILTER_60HZ, MAX31865Model, build_config_byte
from .peripherals.mcp2515 import MCP2515Model, Mcp2515Frame, encode_standard_id
from .peripherals.sht31 import (
    SHT31_CMD_MEASURE_HIGH_REPEATABILITY,
    SHT31_CMD_READ_SERIAL_NUMBER,
    SHT31Model,
)


@dataclass(frozen=True)
class GuiScene:
    title: str
    message: str
    duration_ms: int
    active_components: list[str] = field(default_factory=list)
    active_nets: list[str] = field(default_factory=list)
    net_flows: dict[str, tuple[str, str]] = field(default_factory=dict)
    details: list[str] = field(default_factory=list)
    passed: bool = True
    category: str = "info"

    def to_dict(self) -> dict[str, object]:
        return {
            "title": self.title,
            "message": self.message,
            "duration_ms": self.duration_ms,
            "active_components": list(self.active_components),
            "active_nets": list(self.active_nets),
            "net_flows": {
                net_name: [source, sink]
                for net_name, (source, sink) in self.net_flows.items()
            },
            "details": list(self.details),
            "passed": self.passed,
            "category": self.category,
        }


@dataclass(frozen=True)
class GuiModel:
    board_name: str
    board_path: str
    layout: BoardLayout
    scenes: list[GuiScene]
    verification_ok: bool | None = None
    verification_report: str | None = None

    def to_dict(self) -> dict[str, object]:
        return {
            "board_name": self.board_name,
            "board_path": self.board_path,
            "layout": self.layout.to_dict(),
            "scenes": [scene.to_dict() for scene in self.scenes],
            "verification_ok": self.verification_ok,
            "verification_report": self.verification_report,
        }


def _scene(
    title: str,
    message: str,
    duration_ms: int,
    *,
    active_components: list[str] | None = None,
    active_nets: list[str] | None = None,
    net_flows: dict[str, tuple[str, str]] | None = None,
    details: list[str] | None = None,
    category: str = "info",
) -> GuiScene:
    return GuiScene(
        title=title,
        message=message,
        duration_ms=duration_ms,
        active_components=active_components or [],
        active_nets=active_nets or [],
        net_flows=net_flows or {},
        details=details or [],
        category=category,
    )


def _report_scene(report: BoardVerification | None, board_name: str, layout: BoardLayout) -> GuiScene:
    if report is None:
        return _scene(
            "Board Import",
            "Loaded geometry directly from the KiCad board file.",
            1500,
            details=[
                f"Board: {board_name}",
                f"Footprints: {layout.to_dict()['stats']['footprint_count']}",
                f"Tracks: {layout.to_dict()['stats']['track_count']}",
                f"Vias: {layout.to_dict()['stats']['via_count']}",
            ],
            category="verify",
        )

    matched_components = sum(1 for result in report.component_results if result.ok)
    return _scene(
        "Behavior Verification",
        "Confirmed the imported KiCad board matches the built-in avrsim behavior profile.",
        1800,
        active_components=[result.reference for result in report.component_results[:8]],
        details=[
            f"Profile: {report.profile_name}",
            f"Matched components: {matched_components}/{len(report.component_results)}",
            f"Unexpected components: {len(report.unexpected_components)}",
        ],
        category="verify",
    )


def _build_air_node_scenes() -> list[GuiScene]:
    sht31 = SHT31Model(temperature_c=23.45, rh_percent=56.78, serial_number=0x21436587)
    serial_payload = sht31.transact(SHT31_CMD_READ_SERIAL_NUMBER, 6, wait_ms=1.0) or b""
    measurement_payload = sht31.transact(
        SHT31_CMD_MEASURE_HIGH_REPEATABILITY,
        6,
        wait_ms=15.0,
    ) or b""

    controller = MCP2515Model(tx_complete_latency_ms=1.0)
    sidh, sidl = encode_standard_id(0x180)
    controller.write_registers(0x31, (sidh, sidl, 0x00, 0x00, 0x06, 0x29, 0x09, 0x2E, 0x16, 0x01, 0x07, 0x00, 0x00))
    controller.request_to_send(0x01)
    controller.advance_time_ms(1.0)
    frame = controller.transmitted_frames[0]

    return [
        _scene(
            "Power Rails Settled",
            "Local power is distributed from the RJ45 field feed through the regulator and Nano headers.",
            1500,
            active_components=["RJ45", "REG5V", "J1", "J2"],
            active_nets=["+24V", "+5V", "+3V3", "GND", "VCC"],
            net_flows={
                "+24V": ("RJ45", "REG5V"),
                "+5V": ("REG5V", "J1"),
                "VCC": ("J1", "SHT31"),
            },
            details=[
                "Field input enters on RJ45 pin 7 (+24V) and pin 8 (GND).",
                "Buck module feeds the Nano and sensor headers.",
            ],
            category="power",
        ),
        _scene(
            "SHT31 Serial Probe",
            "Single-shot serial-number command on the I2C bus validates the sensor identity path.",
            1800,
            active_components=["J1", "SHT31"],
            active_nets=["/A4{slash}SDA", "/A5{slash}SCL", "VCC", "GND"],
            net_flows={
                "/A4{slash}SDA": ("J1", "SHT31"),
                "/A5{slash}SCL": ("J1", "SHT31"),
            },
            details=[
                f"Command: 0x{SHT31_CMD_READ_SERIAL_NUMBER:04X}",
                f"Payload: {serial_payload.hex().upper()}",
                "Datasheet idle time respected before readback.",
            ],
            category="i2c",
        ),
        _scene(
            "SHT31 Measurement",
            "Temperature and humidity are read with the datasheet conversion timing and CRC checks.",
            1800,
            active_components=["J1", "SHT31"],
            active_nets=["/A4{slash}SDA", "/A5{slash}SCL", "VCC", "GND"],
            net_flows={
                "/A4{slash}SDA": ("J1", "SHT31"),
                "/A5{slash}SCL": ("J1", "SHT31"),
            },
            details=[
                f"Command: 0x{SHT31_CMD_MEASURE_HIGH_REPEATABILITY:04X}",
                f"Payload: {measurement_payload.hex().upper()}",
                "Example reading: 23.45 C, 56.78 %RH",
            ],
            category="i2c",
        ),
        _scene(
            "MCP2515 SPI Init",
            "SPI traffic configures the MCP2515 and arms the interrupt path back to the Nano.",
            1800,
            active_components=["J1", "J2", "J101"],
            active_nets=["/*D10{slash}SS", "/D12{slash}MISO", "/*D11{slash}MOSI", "/D13{slash}SCK", "/D2", "VCC", "GND"],
            net_flows={
                "/*D10{slash}SS": ("J1", "J101"),
                "/*D11{slash}MOSI": ("J1", "J101"),
                "/D12{slash}MISO": ("J101", "J1"),
                "/D13{slash}SCK": ("J1", "J101"),
                "/D2": ("J101", "J1"),
            },
            details=[
                "Chip select, MOSI, MISO, and SCK align with the Nano-to-MCP2515 header.",
                "INT returns to Nano D2.",
            ],
            category="spi",
        ),
        _scene(
            "CAN Sample Publish",
            "A sample frame is loaded into TXB0 and pushed out onto CAN_H/CAN_L to the RJ45 port.",
            2200,
            active_components=["J101", "RJ45"],
            active_nets=["CAN_H", "CAN_L", "+24V", "GND"],
            net_flows={
                "CAN_H": ("J101", "RJ45"),
                "CAN_L": ("J101", "RJ45"),
                "+24V": ("RJ45", "J1"),
            },
            details=[
                f"Transmitted frame: 0x{frame.frame_id:03X}",
                f"DLC: {frame.dlc}",
                f"Bytes: {' '.join(f'{byte:02X}' for byte in frame.data[:frame.dlc])}",
            ],
            category="can",
        ),
    ]


def _build_sidecar_scenes() -> list[GuiScene]:
    max31865 = MAX31865Model(probe_temp_c=11.25)
    max31865.write_register(0x00, build_config_byte(True, True, False, False, FILTER_60HZ))
    max31865.advance_time_ms(55.0)
    raw_register = (max31865.read_register(0x01) << 8) | max31865.read_register(0x02)

    controller = MCP2515Model(tx_complete_latency_ms=1.0)
    sidh, sidl = encode_standard_id(0x181)
    controller.write_registers(0x31, (sidh, sidl, 0x00, 0x00, 0x06, 0x35, 0x09, 0x2C, 0x16, 0x01, 0x08, 0x00, 0x00))
    controller.request_to_send(0x01)
    controller.advance_time_ms(1.0)
    frame = controller.transmitted_frames[0]

    return [
        _scene(
            "24V Input Distribution",
            "Field power enters, passes through the resettable fuse/protection stage, and feeds the local 5V regulator.",
            1700,
            active_components=["J111", "F201", "D202", "D203", "U201"],
            active_nets=["FIELD_24V", "VIN_RAW_24V", "VIN_FUSED_24V", "+5V", "GND"],
            net_flows={
                "FIELD_24V": ("J111", "F201"),
                "VIN_RAW_24V": ("F201", "D202"),
                "VIN_FUSED_24V": ("D202", "U201"),
                "+5V": ("U201", "P_DIG"),
            },
            details=[
                "Reverse-polarity and transient protection sit ahead of the buck module.",
                "5V is then exported to the Mega side headers and peripheral sockets.",
            ],
            category="power",
        ),
        _scene(
            "MCP2515 SPI Link",
            "The Mega-side SPI and control pins exercise the MCP2515 socket on the sidecar.",
            1800,
            active_components=["P_DIG", "J101"],
            active_nets=["/28", "/*52", "/51", "/50", "/27", "+5V", "GND"],
            net_flows={
                "/28": ("P_DIG", "J101"),
                "/*52": ("P_DIG", "J101"),
                "/51": ("P_DIG", "J101"),
                "/50": ("J101", "P_DIG"),
                "/27": ("J101", "P_DIG"),
            },
            details=[
                "D28 = CS, D27 = INT, D52/D51/D50 = SCK/MOSI/MISO.",
                "Socket pinout matches the verified board profile.",
            ],
            category="spi",
        ),
        _scene(
            "MAX31865 One-Shot Read",
            "The sidecar triggers a one-shot RTD conversion and then reads back the raw resistance code.",
            1900,
            active_components=["P_DIG", "J102"],
            active_nets=["/*52", "/50", "/51", "/26", "+5V", "GND"],
            net_flows={
                "/26": ("P_DIG", "J102"),
                "/*52": ("P_DIG", "J102"),
                "/51": ("P_DIG", "J102"),
                "/50": ("J102", "P_DIG"),
            },
            details=[
                "D26 = CS for the MAX31865 socket.",
                f"Raw RTD register: 0x{raw_register:04X}",
                "Conversion delay matches the MAX31865 single-shot timing.",
            ],
            category="spi",
        ),
        _scene(
            "CAN Bus Distribution",
            "The MCP2515 CAN pair fans out to the four RJ45 air-node ports while each port carries fused 24V and GND.",
            2200,
            active_components=["J101", "K1", "K2", "K3", "K4"],
            active_nets=["CANH", "CANL", "K1_24V", "K2_24V", "K3_24V", "K4_24V", "GND"],
            net_flows={
                "CANH": ("J101", "K4"),
                "CANL": ("J101", "K4"),
                "K1_24V": ("F202", "K1"),
                "K2_24V": ("F203", "K2"),
                "K3_24V": ("F204", "K3"),
                "K4_24V": ("F205", "K4"),
            },
            details=[
                f"Example transmitted frame: 0x{frame.frame_id:03X}",
                f"Bytes: {' '.join(f'{byte:02X}' for byte in frame.data[:frame.dlc])}",
                "RJ45 mapping stays 1=CANH, 2=CANL, 7=24V, 8=GND.",
            ],
            category="can",
        ),
        _scene(
            "Actuator Command Loop",
            "Raw PWM leaves on J107, the converted analog command returns on K5 pin 1, and actuator feedback returns on A10.",
            2200,
            active_components=["J107", "K5", "R101", "R102", "P_AUX"],
            active_nets=["/*44", "ACT_Y_CMD", "/ACT_U_RAW", "K5_24V", "GND", "/A10"],
            net_flows={
                "/*44": ("J107", "K5"),
                "ACT_Y_CMD": ("J107", "K5"),
                "/ACT_U_RAW": ("K5", "P_AUX"),
                "/A10": ("R102", "P_AUX"),
                "K5_24V": ("F206", "K5"),
            },
            details=[
                "J107 pin 1 carries the raw PWM output.",
                "K5 pin 1 is the 0-10V command input and pin 3 is feedback U.",
                "R101/R102 divide the feedback into the Mega A10 input.",
            ],
            category="analog",
        ),
    ]


def _build_generic_scenes(board_name: str, layout: BoardLayout) -> list[GuiScene]:
    highlighted_components = [footprint.reference for footprint in layout.footprints[:6]]
    highlighted_nets = sorted(
        {
            track.net_name
            for track in layout.tracks
            if track.net_name
        }
    )[:6]
    return [
        _scene(
            "Layout Import",
            "Loaded board geometry directly from the KiCad PCB file for native visualization.",
            1500,
            active_components=highlighted_components,
            active_nets=highlighted_nets,
            details=[
                f"Board: {board_name}",
                f"Footprints: {len(layout.footprints)}",
                f"Tracks: {len(layout.tracks)}",
            ],
            category="verify",
        )
    ]


def _build_demo_scenes(board_name: str, layout: BoardLayout, report: BoardVerification | None) -> list[GuiScene]:
    scenes = [_report_scene(report, board_name, layout)]
    if board_name == "air_node":
        scenes.extend(_build_air_node_scenes())
    elif board_name == "mega_r3_sidecar_controller_rev_a":
        scenes.extend(_build_sidecar_scenes())
    else:
        scenes.extend(_build_generic_scenes(board_name, layout))
    return scenes


def build_gui_model_from_pcb(pcb_path: str | Path) -> GuiModel:
    path = Path(pcb_path).resolve()
    board = board_from_kicad_pcb(path)
    layout = layout_from_kicad_pcb(path)
    report = None
    verification_report = None

    try:
        profile = load_built_in_profile(board.name)
        report = verify_board(board, profile)
        verification_report = format_verification_report(report)
    except FileNotFoundError:
        report = None

    return GuiModel(
        board_name=board.name,
        board_path=str(path),
        layout=layout,
        scenes=_build_demo_scenes(board.name, layout, report),
        verification_ok=report.ok if report is not None else None,
        verification_report=verification_report,
    )
