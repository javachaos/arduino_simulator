"""Opcode-level CPU tests for avrsim."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from avrsim.cpu import CPU, CPUConfig, UnsupportedInstructionError
from avrsim.cpu.CPU import FLAG_C, FLAG_H, FLAG_I, FLAG_N, FLAG_S, FLAG_T, FLAG_V, FLAG_Z


def _rr_opcode(base: int, d: int, r: int) -> int:
    return base | ((d & 0x1F) << 4) | (r & 0x0F) | ((r & 0x10) << 5)


def _ldi(d: int, k: int) -> int:
    if d < 16 or d > 31:
        raise ValueError("LDI targets registers 16..31")
    return 0xE000 | ((k & 0xF0) << 4) | ((d - 16) << 4) | (k & 0x0F)


def _add(d: int, r: int) -> int:
    return _rr_opcode(0x0C00, d, r)


def _adc(d: int, r: int) -> int:
    return _rr_opcode(0x1C00, d, r)


def _subi(d: int, k: int) -> int:
    if d < 16 or d > 31:
        raise ValueError("SUBI targets registers 16..31")
    return 0x5000 | ((k & 0xF0) << 4) | ((d - 16) << 4) | (k & 0x0F)


def _cpse(d: int, r: int) -> int:
    return _rr_opcode(0x1000, d, r)


def _out(a: int, r: int) -> int:
    return 0xB800 | ((a & 0x30) << 5) | ((r & 0x1F) << 4) | (a & 0x0F)


def _in(d: int, a: int) -> int:
    return 0xB000 | ((a & 0x30) << 5) | ((d & 0x1F) << 4) | (a & 0x0F)


def _sbi(a: int, b: int) -> int:
    return 0x9A00 | ((a & 0x1F) << 3) | (b & 0x07)


def _sbic(a: int, b: int) -> int:
    return 0x9900 | ((a & 0x1F) << 3) | (b & 0x07)


def _sbis(a: int, b: int) -> int:
    return 0x9B00 | ((a & 0x1F) << 3) | (b & 0x07)


def _push(r: int) -> int:
    return 0x920F | ((r & 0x1F) << 4)


def _pop(d: int) -> int:
    return 0x900F | ((d & 0x1F) << 4)


def _rcall(offset: int) -> int:
    return 0xD000 | (offset & 0x0FFF)


def _ret() -> int:
    return 0x9508


def _break() -> int:
    return 0x9598


def _jmp(target: int) -> tuple[int, int]:
    first = 0x940C | (((target >> 17) & 0x1F) << 4) | ((target >> 16) & 0x01)
    second = target & 0xFFFF
    return first, second


def _call(target: int) -> tuple[int, int]:
    first = 0x940E | (((target >> 17) & 0x1F) << 4) | ((target >> 16) & 0x01)
    second = target & 0xFFFF
    return first, second


def _st_x_postinc(r: int) -> int:
    return 0x920D | ((r & 0x1F) << 4)


def _ld_x_postinc(d: int) -> int:
    return 0x900D | ((d & 0x1F) << 4)


def _std_y(q: int, r: int) -> int:
    return 0x8208 | ((q & 0x20) << 8) | ((q & 0x18) << 7) | ((r & 0x1F) << 4) | (q & 0x07)


def _ldd_y(q: int, d: int) -> int:
    return 0x8008 | ((q & 0x20) << 8) | ((q & 0x18) << 7) | ((d & 0x1F) << 4) | (q & 0x07)


def _lpm(d: int, post_increment: bool = False) -> int:
    return (0x9005 if post_increment else 0x9004) | ((d & 0x1F) << 4)


def _elpm(d: int, post_increment: bool = False) -> int:
    return (0x9007 if post_increment else 0x9006) | ((d & 0x1F) << 4)


def _bset(bit_index: int) -> int:
    return 0x9408 | ((bit_index & 0x07) << 4)


def _bclr(bit_index: int) -> int:
    return 0x9488 | ((bit_index & 0x07) << 4)


def _bst(d: int, bit_index: int) -> int:
    return 0xFA00 | ((d & 0x1F) << 4) | (bit_index & 0x07)


def _bld(d: int, bit_index: int) -> int:
    return 0xF800 | ((d & 0x1F) << 4) | (bit_index & 0x07)


def _brbc(flag: int, offset: int) -> int:
    return 0xF400 | ((offset & 0x7F) << 3) | (flag & 0x07)


def _mul(d: int, r: int) -> int:
    return _rr_opcode(0x9C00, d, r)


def _fmul(d: int, r: int) -> int:
    return 0x0308 | (((d - 16) & 0x07) << 4) | ((r - 16) & 0x07)


def _des(round_index: int) -> int:
    return 0x940B | ((round_index & 0x0F) << 4)


def _assert_flag(cpu: CPU, flag: int, expected: int) -> None:
    assert cpu.get_flag(flag) == expected


def _snapshot_cpu(cpu: CPU) -> tuple[int, int, bool, bool, bytes]:
    return (cpu.pc, cpu.cycles, cpu.break_hit, cpu.sleeping, bytes(cpu.data))


def test_add_and_adc_flags_follow_manual_semantics() -> None:
    cpu = CPU(CPUConfig.atmega328p())
    cpu.load_program_words(
        [
            _ldi(16, 0x7F),
            _ldi(17, 0x01),
            _add(16, 17),
            _ldi(18, 0xFF),
            _ldi(19, 0x00),
            _bset(FLAG_C),
            _adc(18, 19),
            _break(),
        ]
    )

    cpu.run()

    assert cpu.read_register(16) == 0x80
    _assert_flag(cpu, FLAG_H, 1)
    _assert_flag(cpu, FLAG_V, 0)
    _assert_flag(cpu, FLAG_N, 0)
    _assert_flag(cpu, FLAG_S, 0)
    _assert_flag(cpu, FLAG_Z, 1)
    _assert_flag(cpu, FLAG_C, 1)
    assert cpu.read_register(18) == 0x00


def test_stack_rcall_push_pop_and_ret_round_trip() -> None:
    cpu = CPU(CPUConfig.atmega328p())
    cpu.load_program_words(
        [
            _ldi(16, 0x11),
            _rcall(3),
            _break(),
            0x0000,
            0x0000,
            _push(16),
            _ldi(16, 0x22),
            _pop(17),
            _ret(),
        ]
    )
    initial_sp = cpu.sp

    cpu.run()

    assert cpu.read_register(16) == 0x22
    assert cpu.read_register(17) == 0x11
    assert cpu.sp == initial_sp
    assert cpu.break_hit


def test_32bit_call_and_ret_use_three_byte_pc_on_atmega2560() -> None:
    cpu = CPU(CPUConfig.atmega2560())
    target = 0x10010
    call_word_0, call_word_1 = _call(target)
    cpu.load_program_words([call_word_0, call_word_1, _break()], start_word=0)
    cpu.load_program_words([_ldi(16, 0x33), _ret()], start_word=target)
    initial_sp = cpu.sp

    cpu.run()

    assert cpu.read_register(16) == 0x33
    assert cpu.sp == initial_sp
    assert cpu.break_hit


def test_cpse_skips_two_word_instruction() -> None:
    cpu = CPU(CPUConfig.atmega328p())
    jump_target = 8
    jmp0, jmp1 = _jmp(jump_target)
    cpu.load_program_words(
        [
            _ldi(16, 0x42),
            _ldi(17, 0x42),
            _cpse(16, 17),
            jmp0,
            jmp1,
            _ldi(18, 0x55),
            _break(),
        ]
    )

    cpu.run()

    assert cpu.read_register(18) == 0x55
    assert cpu.break_hit


def test_x_and_y_addressing_modes_store_and_load_data_space() -> None:
    cpu = CPU(CPUConfig.atmega328p())
    cpu.load_program_words(
        [
            _ldi(26, 0x00),
            _ldi(27, 0x01),
            _ldi(16, 0x12),
            _ldi(17, 0x34),
            _st_x_postinc(16),
            _st_x_postinc(17),
            _ldi(28, 0x00),
            _ldi(29, 0x01),
            _std_y(2, 17),
            _ldi(26, 0x00),
            _ldi(27, 0x01),
            _ld_x_postinc(18),
            _ld_x_postinc(19),
            _ldd_y(2, 20),
            _break(),
        ]
    )

    cpu.run()

    assert cpu.read_data(0x0100) == 0x12
    assert cpu.read_data(0x0101) == 0x34
    assert cpu.read_data(0x0102) == 0x34
    assert cpu.read_register(18) == 0x12
    assert cpu.read_register(19) == 0x34
    assert cpu.read_register(20) == 0x34


def test_in_out_and_skip_bit_in_io_register() -> None:
    cpu = CPU(CPUConfig.atmega328p())
    cpu.load_program_words(
        [
            _ldi(16, 0x00),
            _out(0x05, 16),
            _sbi(0x05, 2),
            _sbic(0x05, 2),
            _ldi(17, 0xAA),
            _sbis(0x05, 2),
            _ldi(18, 0xBB),
            _in(19, 0x05),
            _break(),
        ]
    )

    cpu.run()

    assert cpu.read_register(17) == 0xAA
    assert cpu.read_register(18) == 0x00
    assert cpu.read_register(19) == 0x04


def test_lpm_and_elpm_read_program_memory_bytes() -> None:
    cpu = CPU(CPUConfig.atmega2560())
    cpu.load_program_words(
        [
            _ldi(30, 0x00),
            _ldi(31, 0x02),
            _lpm(16, False),
            _lpm(17, True),
            _ldi(30, 0x00),
            _ldi(31, 0x00),
            _ldi(20, 0x01),
            _out(0x3B, 20),
            _elpm(18, False),
            _break(),
        ]
    )
    cpu.set_program_word(0x0100, 0xBBAA)
    cpu.program[0x10000] = 0x5C

    cpu.run()

    assert cpu.read_register(16) == 0xAA
    assert cpu.read_register(17) == 0xAA
    assert cpu.read_register(18) == 0x5C


def test_flag_bit_instructions_and_bit_transfer_work() -> None:
    cpu = CPU(CPUConfig.atmega328p())
    cpu.load_program_words(
        [
            _bset(FLAG_I),
            _bset(FLAG_T),
            _ldi(16, 0x00),
            _bld(16, 3),
            _bst(16, 3),
            _bclr(FLAG_I),
            _break(),
        ]
    )

    cpu.run()

    assert cpu.read_register(16) == 0x08
    _assert_flag(cpu, FLAG_T, 1)
    _assert_flag(cpu, FLAG_I, 0)


def test_mul_and_fmul_write_r1_r0_and_flags() -> None:
    cpu = CPU(CPUConfig.atmega328p())
    cpu.load_program_words(
        [
            _ldi(16, 0x03),
            _ldi(17, 0x07),
            _mul(16, 17),
            _ldi(18, 0x40),
            _ldi(19, 0x20),
            _fmul(18, 19),
            _break(),
        ]
    )

    cpu.run()

    assert cpu.read_register(0) == 0x00
    assert cpu.read_register(1) == 0x10
    _assert_flag(cpu, FLAG_Z, 0)
    _assert_flag(cpu, FLAG_C, 0)


def test_des_decodes_but_executes_as_explicitly_unsupported() -> None:
    cpu = CPU(CPUConfig.atmega328p())
    cpu.load_program_words([_des(0x03)])
    instruction = cpu.decode_at(0)

    assert instruction.mnemonic == "des"
    try:
        cpu.step()
    except UnsupportedInstructionError:
        return
    raise AssertionError("DES should raise UnsupportedInstructionError")


def test_decode_cache_invalidates_when_flash_contents_change() -> None:
    cpu = CPU(CPUConfig.atmega328p())
    cpu.load_program_words([_break()])
    assert cpu.decode_at(0).mnemonic == "break"

    cpu.set_program_word(0, _des(0x01))
    assert cpu.decode_at(0).mnemonic == "des"

    cpu.load_program_words([_ldi(16, 0x12)], start_word=0)
    refreshed = cpu.decode_at(0)
    assert refreshed.mnemonic == "ldi"
    assert refreshed.operands["d"] == 16
    assert refreshed.operands["k"] == 0x12


def test_block_jit_matches_reference_execution_for_mixed_hot_path_program() -> None:
    words = [
        _ldi(16, 0x10),
        _ldi(17, 0x05),
        _add(16, 17),
        _push(16),
        _pop(18),
        _ldi(26, 0x00),
        _ldi(27, 0x02),
        _st_x_postinc(18),
        _ldi(26, 0x00),
        _ldi(27, 0x02),
        _ld_x_postinc(19),
        _out(0x05, 19),
        _in(20, 0x05),
        _ldi(30, 0x00),
        _ldi(31, 0x04),
        _lpm(21, False),
        _bset(FLAG_T),
        _bld(20, 1),
        _mul(16, 17),
        _break(),
    ]
    reference = CPU(CPUConfig.atmega2560())
    jit = CPU(CPUConfig.atmega2560(), enable_block_jit=True)
    for cpu in (reference, jit):
        cpu.load_program_words(words)
        cpu.set_program_word(0x0200, 0xBBAA)
        cpu.run()

    assert _snapshot_cpu(jit) == _snapshot_cpu(reference)


def test_block_jit_cache_invalidates_when_flash_contents_change() -> None:
    cpu = CPU(CPUConfig.atmega328p(), enable_block_jit=True)
    cpu.load_program_words([_ldi(16, 0x12), _break()])

    cpu.run(max_instructions=1, stop_on_break=False)
    assert cpu.read_register(16) == 0x12
    assert cpu._compiled_block_cache

    cpu.set_program_word(0, _ldi(16, 0x34))
    assert not cpu._compiled_block_cache
    assert cpu.decode_at(0).operands["k"] == 0x34

    cpu.reset(clear_program=False)
    cpu.run()
    assert cpu.read_register(16) == 0x34


def test_trace_cache_spans_hot_conditional_branch_path() -> None:
    cpu = CPU(CPUConfig.atmega328p(), enable_block_jit=True, enable_trace_cache=True)
    cpu.load_program_words(
        [
            _ldi(16, 0x03),
            _subi(16, 0x01),
            _brbc(FLAG_Z, -2),
            _break(),
        ]
    )

    cpu.run()
    cpu.reset(clear_program=False)
    cpu.run()

    trace = cpu._trace_cache.get(0)
    assert trace is not None
    basic_block = cpu._basic_block_cache[0]
    assert len(trace.instructions) > len(basic_block.instructions)


def main() -> int:
    test_add_and_adc_flags_follow_manual_semantics()
    test_stack_rcall_push_pop_and_ret_round_trip()
    test_32bit_call_and_ret_use_three_byte_pc_on_atmega2560()
    test_cpse_skips_two_word_instruction()
    test_x_and_y_addressing_modes_store_and_load_data_space()
    test_in_out_and_skip_bit_in_io_register()
    test_lpm_and_elpm_read_program_memory_bytes()
    test_flag_bit_instructions_and_bit_transfer_work()
    test_mul_and_fmul_write_r1_r0_and_flags()
    test_des_decodes_but_executes_as_explicitly_unsupported()
    test_decode_cache_invalidates_when_flash_contents_change()
    test_block_jit_matches_reference_execution_for_mixed_hot_path_program()
    test_block_jit_cache_invalidates_when_flash_contents_change()
    test_trace_cache_spans_hot_conditional_branch_path()
    print("avrsim CPU tests passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
