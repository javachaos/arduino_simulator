"""Datasheet-grounded peripheral model tests for avrsim."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from avrsim.peripherals import (
    CANINTF_RX0IF,
    CANINTF_TX0IF,
    COMMAND_READ_RX_BUFFER_RXB0SIDH,
    COMMAND_READ_STATUS,
    COMMAND_RTS_TX0,
    COMMAND_WRITE,
    FILTER_60HZ,
    MCP2515Model,
    MAX31865Model,
    MODE_MASK,
    MODE_NORMAL,
    POR_CANCTRL,
    POR_CANSTAT,
    REGISTER_CANCTRL,
    REGISTER_CANINTF,
    REGISTER_CANSTAT,
    REGISTER_TXB0SIDH,
    SHT31_CMD_MEASURE_HIGH_REPEATABILITY,
    SHT31_CMD_READ_SERIAL_NUMBER,
    SHT31_MIN_COMMAND_GAP_MS,
    SHT31Model,
    build_config_byte,
    compute_sht_crc,
    pt1000_model,
    raw_code_to_resistance_ohms,
    resistance_ohms_to_temperature_c,
)
from avrsim.peripherals.max31865 import CONFIG_AUTO_CONVERT, FAULT_OVER_UNDER_VOLTAGE
from avrsim.peripherals.mcp2515 import Mcp2515Frame, encode_standard_id


def _almost_equal(left: float, right: float, tolerance: float) -> bool:
    return abs(left - right) <= tolerance


def test_sht31_crc_matches_datasheet_reference() -> None:
    assert compute_sht_crc(bytes((0xBE, 0xEF))) == 0x92


def test_sht31_measurement_timing_and_formula() -> None:
    model = SHT31Model(temperature_c=23.45, rh_percent=56.78)

    assert model.write_command(SHT31_CMD_MEASURE_HIGH_REPEATABILITY)
    assert model.read(6) is None

    model.advance_time_ms(14.9)
    assert model.read(6) is None

    model.advance_time_ms(0.2)
    payload = model.read(6)
    assert payload is not None

    raw_temp = (payload[0] << 8) | payload[1]
    raw_rh = (payload[3] << 8) | payload[4]
    temp_c = -45.0 + (175.0 * float(raw_temp) / 65535.0)
    rh_percent = 100.0 * float(raw_rh) / 65535.0

    assert _almost_equal(temp_c, 23.45, 0.02)
    assert _almost_equal(rh_percent, 56.78, 0.02)


def test_sht31_serial_read_requires_idle_gap() -> None:
    model = SHT31Model(serial_number=0x11223344)

    assert model.write_command(SHT31_CMD_READ_SERIAL_NUMBER)
    assert not model.write_command(SHT31_CMD_MEASURE_HIGH_REPEATABILITY)

    model.advance_time_ms(1.0)
    payload = model.read(6)
    assert payload is not None

    serial_number = (
        (payload[0] << 24)
        | (payload[1] << 16)
        | (payload[3] << 8)
        | payload[4]
    )
    assert serial_number == 0x11223344

    assert model.write_command(SHT31_CMD_MEASURE_HIGH_REPEATABILITY)


def test_max31865_one_shot_timing_and_fault_clear() -> None:
    device = MAX31865Model(probe_temp_c=25.0)
    config = build_config_byte(True, True, False, False, FILTER_60HZ)

    assert device.read_register(0x01) == 0
    assert device.read_register(0x02) == 0

    device.write_register(0x00, config)
    assert (device.read_register(0x00) & 0x20) != 0
    assert device.read_register(0x01) == 0

    device.advance_time_ms(54.9)
    assert device.read_register(0x01) == 0

    device.advance_time_ms(0.2)
    raw_register = (device.read_register(0x01) << 8) | device.read_register(0x02)
    raw_code = raw_register >> 1
    resistance_ohms = raw_code_to_resistance_ohms(raw_code, pt1000_model())
    temp_c = resistance_ohms_to_temperature_c(resistance_ohms, pt1000_model())
    assert _almost_equal(temp_c, 25.0, 0.15)
    assert (device.read_register(0x00) & 0x20) == 0

    device.set_fault_status(FAULT_OVER_UNDER_VOLTAGE)
    raw_register = (device.read_register(0x01) << 8) | device.read_register(0x02)
    assert (raw_register & 0x0001) != 0

    clear_config = build_config_byte(False, False, False, True, FILTER_60HZ)
    device.write_register(0x00, clear_config)
    assert device.read_register(0x07) == 0
    raw_register = (device.read_register(0x01) << 8) | device.read_register(0x02)
    assert (raw_register & 0x0001) == 0


def test_max31865_auto_conversion_uses_continuous_period() -> None:
    device = MAX31865Model(probe_temp_c=10.0)

    device.write_register(0x00, 0x80 | CONFIG_AUTO_CONVERT)
    device.advance_time_ms(55.0)
    first_raw = (device.read_register(0x01) << 8) | device.read_register(0x02)
    assert first_raw != 0

    device.set_probe_temperature(20.0)
    device.advance_time_ms(17.5)
    assert ((device.read_register(0x01) << 8) | device.read_register(0x02)) == first_raw

    device.advance_time_ms(0.2)
    second_raw = (device.read_register(0x01) << 8) | device.read_register(0x02)
    assert second_raw != first_raw


def test_mcp2515_reset_defaults_and_mode_sync() -> None:
    device = MCP2515Model()

    assert device.read_register(REGISTER_CANSTAT) == POR_CANSTAT
    assert device.read_register(REGISTER_CANCTRL) == POR_CANCTRL
    assert device.read_status() == 0

    device.bit_modify(REGISTER_CANCTRL, MODE_MASK, MODE_NORMAL)
    assert (device.read_register(REGISTER_CANCTRL) & MODE_MASK) == MODE_NORMAL
    assert (device.read_register(REGISTER_CANSTAT) & MODE_MASK) == MODE_NORMAL


def test_mcp2515_spi_write_rts_and_status() -> None:
    device = MCP2515Model(tx_complete_latency_ms=1.0)
    sidh, sidl = encode_standard_id(0x123)

    write_payload = bytes(
        (
            COMMAND_WRITE,
            REGISTER_TXB0SIDH,
            sidh,
            sidl,
            0x00,
            0x00,
            0x03,
            0x11,
            0x22,
            0x33,
            0x00,
            0x00,
            0x00,
            0x00,
            0x00,
        )
    )
    assert device.spi_transaction(write_payload) == bytes(len(write_payload))

    assert device.spi_transaction(bytes((COMMAND_RTS_TX0,))) == b"\x00"
    status_response = device.spi_transaction(bytes((COMMAND_READ_STATUS, 0x00, 0x00)))
    assert (status_response[1] & 0x01) != 0
    assert (status_response[2] & 0x01) != 0

    device.advance_time_ms(1.0)
    assert (device.read_status() & 0x01) == 0
    assert (device.read_status() & 0x20) != 0
    assert device.read_register(REGISTER_CANINTF) & CANINTF_TX0IF
    assert len(device.transmitted_frames) == 1
    assert device.transmitted_frames[0].frame_id == 0x123
    assert device.transmitted_frames[0].dlc == 3
    assert device.transmitted_frames[0].data[0:3] == (0x11, 0x22, 0x33)


def test_mcp2515_rx_buffer_read_clears_flag() -> None:
    device = MCP2515Model()
    frame = Mcp2515Frame(frame_id=0x321, dlc=2, data=(0xAA, 0x55, 0, 0, 0, 0, 0, 0))

    device.inject_received_frame(frame, buffer_index=0)
    assert device.message_pending()
    assert (device.read_register(REGISTER_CANINTF) & CANINTF_RX0IF) != 0

    response = device.spi_transaction(bytes((COMMAND_READ_RX_BUFFER_RXB0SIDH,)) + bytes(13))
    raw = response[1:]
    assert raw[4] == 0x02
    assert raw[5] == 0xAA
    assert raw[6] == 0x55
    assert not device.message_pending()
    assert (device.read_register(REGISTER_CANINTF) & CANINTF_RX0IF) == 0


def main() -> int:
    test_sht31_crc_matches_datasheet_reference()
    test_sht31_measurement_timing_and_formula()
    test_sht31_serial_read_requires_idle_gap()
    test_max31865_one_shot_timing_and_fault_clear()
    test_max31865_auto_conversion_uses_continuous_period()
    test_mcp2515_reset_defaults_and_mode_sync()
    test_mcp2515_spi_write_rts_and_status()
    test_mcp2515_rx_buffer_read_clears_flag()
    print("avrsim peripheral tests passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
