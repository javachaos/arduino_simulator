"""Compiled-firmware runtime wrapper for the Nano air-node."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from .cpu import CPU, CPUConfig
from .firmware import ProgramImage, load_intel_hex
from .mcu import Atmega328P
from .nano import NanoAirNodeSim


NANO_CLOCK_HZ = 16_000_000


@dataclass
class NanoAirNodeFirmwareSim:
    """Bind the AVR CPU core to the Nano air-node board-side simulation."""

    board: NanoAirNodeSim = field(default_factory=NanoAirNodeSim)
    clock_hz: int = NANO_CLOCK_HZ
    enable_block_jit: bool = False
    mcu: Atmega328P = field(init=False)
    cpu: CPU = field(init=False)

    def __post_init__(self) -> None:
        self.mcu = Atmega328P(board=self.board, clock_hz=self.clock_hz)
        self.cpu = CPU(
            config=CPUConfig.atmega328p(),
            hooks=self.mcu,
            enable_block_jit=self.enable_block_jit,
        )

    def reset(self, *, clear_program: bool = False) -> None:
        self.cpu.reset(clear_program=clear_program)

    def load_hex(self, path: str | Path, *, clear_program: bool = True) -> ProgramImage:
        image = load_intel_hex(path)
        image.load_into_cpu(self.cpu, clear_program=clear_program)
        return image

    def run(self, max_instructions: int | None = None, *, stop_on_break: bool = True) -> int:
        return self.cpu.run(
            max_instructions=max_instructions,
            stop_on_break=stop_on_break,
            stop_on_sleep=False,
        )

    def run_until(
        self,
        predicate: Callable[["NanoAirNodeFirmwareSim"], bool],
        *,
        max_instructions: int,
        chunk_size: int = 1000,
    ) -> int:
        executed = 0
        while executed < max_instructions and not predicate(self):
            batch = min(chunk_size, max_instructions - executed)
            executed += self.run(batch, stop_on_break=False)
        return executed

    def run_until_serial_output(
        self,
        *,
        min_bytes: int = 1,
        max_instructions: int,
        chunk_size: int = 1000,
    ) -> int:
        if min_bytes <= 0:
            raise ValueError("min_bytes must be positive")
        return self.run_until(
            lambda sim: len(sim.serial_output_bytes) >= min_bytes,
            max_instructions=max_instructions,
            chunk_size=chunk_size,
        )

    @property
    def serial_output_bytes(self) -> bytes:
        return self.mcu.serial_output_bytes

    def serial_output_text(self, *, encoding: str = "utf-8", errors: str = "replace") -> str:
        return self.mcu.serial_output_text(encoding=encoding, errors=errors)

    def clear_serial_output(self) -> None:
        self.mcu.clear_serial_output()

    def inject_serial_rx(self, payload: bytes | bytearray) -> None:
        self.mcu.inject_usart0_rx(self.cpu, payload)


__all__ = [
    "NANO_CLOCK_HZ",
    "NanoAirNodeFirmwareSim",
]
