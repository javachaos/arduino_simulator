"""ELF symbol loader tests."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from avrsim.arduino_turbo import ArduinoTimer0DelayTurbo
from avrsim.elf_symbols import parse_avr_nm_output


def test_parse_avr_nm_output_normalizes_program_and_data_symbols() -> None:
    symbols = parse_avr_nm_output(
        "\n".join(
            (
                "000016ee t delay",
                "008007fd b timer0_fract",
                "008007fe b timer0_millis",
                "00800802 b timer0_overflow_count",
            )
        )
    )
    turbo = ArduinoTimer0DelayTurbo.from_symbols(symbols)

    assert turbo.delay_word_address == 0x0B77
    assert turbo.timer0_fract_data_address == 0x07FD
    assert turbo.timer0_millis_data_address == 0x07FE
    assert turbo.timer0_overflow_count_data_address == 0x0802


def main() -> int:
    test_parse_avr_nm_output_normalizes_program_and_data_symbols()
    print("avrsim ELF symbol tests passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
