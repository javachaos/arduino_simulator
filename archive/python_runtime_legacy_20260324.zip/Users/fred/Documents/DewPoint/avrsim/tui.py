"""Terminal monitor for avrsim runtimes."""

from __future__ import annotations

from bisect import bisect_right
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .cpu import DecodedInstruction
from .elf_symbols import FirmwareSymbols, load_elf_symbols


@dataclass(frozen=True)
class RuntimeSnapshot:
    """Immutable monitor state rendered by the TUI."""

    title: str
    status: str
    pc_word: int
    sp: int
    cycles: int
    sim_ms: float
    serial_text: str
    serial_byte_count: int
    instruction_text: str
    opcode_text: str
    sreg: int
    registers: tuple[int, ...]
    symbol_text: str | None
    error_text: str | None


class ProgramSymbolResolver:
    """Best-effort program counter to symbol-name resolver."""

    def __init__(self, symbols: FirmwareSymbols) -> None:
        entries = sorted(
            (address, name)
            for name, address in symbols.addresses.items()
            if 0 <= address < 0x800000
        )
        self._addresses = [address for address, _ in entries]
        self._names = [name for _, name in entries]

    @classmethod
    def from_elf(
        cls,
        path: str | Path,
        *,
        nm_path: str | Path | None = None,
    ) -> "ProgramSymbolResolver":
        return cls(load_elf_symbols(path, nm_path=nm_path))

    def resolve_pc(self, pc_word: int) -> str | None:
        if not self._addresses:
            return None
        pc_byte = max(0, int(pc_word) * 2)
        index = bisect_right(self._addresses, pc_byte) - 1
        if index < 0:
            return None
        symbol_name = self._names[index]
        symbol_address = self._addresses[index]
        offset = pc_byte - symbol_address
        if offset <= 0:
            return symbol_name
        return f"{symbol_name}+0x{offset:X}"


def build_runtime_snapshot(
    sim: Any,
    *,
    title: str,
    paused: bool,
    error_text: str | None = None,
    symbol_resolver: ProgramSymbolResolver | None = None,
) -> RuntimeSnapshot:
    cpu = sim.cpu
    instruction = _decode_instruction(cpu)
    if error_text is not None:
        status = "ERROR"
    elif cpu.break_hit:
        status = "BREAK"
    elif cpu.sleeping:
        status = "SLEEP"
    elif paused:
        status = "PAUSE"
    else:
        status = "RUN"
    symbol_text = symbol_resolver.resolve_pc(cpu.pc) if symbol_resolver is not None else None
    return RuntimeSnapshot(
        title=title,
        status=status,
        pc_word=cpu.pc,
        sp=cpu.sp,
        cycles=cpu.cycles,
        sim_ms=(float(cpu.cycles) * 1000.0 / float(sim.clock_hz)),
        serial_text=sim.serial_output_text(),
        serial_byte_count=len(sim.serial_output_bytes),
        instruction_text=_format_instruction(instruction),
        opcode_text=_format_opcode(instruction),
        sreg=cpu.sreg,
        registers=tuple(cpu.read_register(index) for index in range(32)),
        symbol_text=symbol_text,
        error_text=error_text,
    )


def format_cpu_panel(snapshot: RuntimeSnapshot, *, width: int) -> list[str]:
    pause_button = "[Resume: Space]" if snapshot.status in {"PAUSE", "BREAK", "SLEEP"} else "[Pause: Space]"
    step_button = "[Step: S]"
    clear_button = "[Clear Serial: C]"
    quit_button = "[Quit: Q]"
    lines = [
        _clip_line(f"{snapshot.title} | {snapshot.status}", width),
        _clip_line(f"{pause_button} {step_button} {clear_button} {quit_button}", width),
        _clip_line(
            f"PC 0x{snapshot.pc_word:05X} ({snapshot.pc_word * 2:06X}b) | "
            f"SP 0x{snapshot.sp:04X} | cycles {snapshot.cycles} | sim {snapshot.sim_ms:.3f} ms | "
            f"serial {snapshot.serial_byte_count} B",
            width,
        ),
    ]
    if snapshot.symbol_text is not None:
        lines.append(_clip_line(f"Symbol: {snapshot.symbol_text}", width))
    lines.append(_clip_line(f"Next: {snapshot.instruction_text}", width))
    lines.append(_clip_line(f"Word: {snapshot.opcode_text}", width))
    lines.append(_clip_line(f"SREG: {_format_sreg(snapshot.sreg)}", width))
    for row_start in range(0, 32, 8):
        row = "  ".join(
            f"r{index:02d}={snapshot.registers[index]:02X}"
            for index in range(row_start, row_start + 8)
        )
        lines.append(_clip_line(row, width))
    if snapshot.error_text is not None:
        lines.append(_clip_line(f"Error: {snapshot.error_text}", width))
    return lines


def format_serial_panel(snapshot: RuntimeSnapshot, *, width: int, height: int) -> list[str]:
    normalized = snapshot.serial_text.replace("\r\n", "\n").replace("\r", "\n")
    wrapped = _wrap_lines(normalized, width)
    if not wrapped:
        wrapped = ["<no serial output yet>"]
    return wrapped[-max(1, height) :]


def launch_runtime_monitor(
    sim: Any,
    *,
    title: str,
    chunk_size: int,
    refresh_ms: int,
    symbol_resolver: ProgramSymbolResolver | None = None,
) -> int:
    import curses

    state = _MonitorState(paused=False, error_text=None)

    def _main(stdscr: Any) -> int:
        stdscr.nodelay(True)
        stdscr.timeout(0)
        try:
            curses.curs_set(0)
        except curses.error:
            pass
        while True:
            loop_started = time.monotonic()
            if not state.paused and not sim.cpu.break_hit and state.error_text is None:
                try:
                    executed = sim.run(max_instructions=chunk_size, stop_on_break=False)
                    if executed <= 0 or sim.cpu.break_hit:
                        state.paused = True
                except Exception as exc:  # pragma: no cover - exercised interactively
                    state.paused = True
                    state.error_text = f"{type(exc).__name__}: {exc}"

            snapshot = build_runtime_snapshot(
                sim,
                title=title,
                paused=state.paused,
                error_text=state.error_text,
                symbol_resolver=symbol_resolver,
            )
            _render_monitor(stdscr, snapshot)

            while True:
                key = stdscr.getch()
                if key != -1:
                    if key in (ord("q"), ord("Q")):
                        return 0
                    if key == ord(" "):
                        if state.error_text is None:
                            state.paused = not state.paused
                    elif key in (ord("s"), ord("S")):
                        if state.paused and not sim.cpu.break_hit:
                            try:
                                sim.run(max_instructions=1, stop_on_break=False)
                            except Exception as exc:  # pragma: no cover - exercised interactively
                                state.error_text = f"{type(exc).__name__}: {exc}"
                    elif key in (ord("c"), ord("C")):
                        sim.clear_serial_output()
                    _render_monitor(
                        stdscr,
                        build_runtime_snapshot(
                            sim,
                            title=title,
                            paused=state.paused,
                            error_text=state.error_text,
                            symbol_resolver=symbol_resolver,
                        ),
                    )

                elapsed_ms = (time.monotonic() - loop_started) * 1000.0
                if elapsed_ms >= max(1, refresh_ms):
                    break
                time.sleep(0.01)

    return curses.wrapper(_main)


@dataclass
class _MonitorState:
    paused: bool
    error_text: str | None


def _decode_instruction(cpu: Any) -> DecodedInstruction | None:
    try:
        return cpu.decode_at()
    except Exception:
        return None


def _format_instruction(instruction: DecodedInstruction | None) -> str:
    if instruction is None:
        return "<decode unavailable>"
    if not instruction.operands:
        return instruction.mnemonic
    operand_text = ", ".join(
        f"{name}={_format_operand(value)}"
        for name, value in instruction.operands.items()
    )
    return f"{instruction.mnemonic} {operand_text}"


def _format_opcode(instruction: DecodedInstruction | None) -> str:
    if instruction is None:
        return "<unknown>"
    if instruction.next_word is None:
        return f"0x{instruction.opcode:04X}"
    return f"0x{instruction.opcode:04X} 0x{instruction.next_word:04X}"


def _format_operand(value: object) -> str:
    if isinstance(value, bool):
        return "1" if value else "0"
    if isinstance(value, int):
        if value < 0:
            return str(value)
        if value <= 9:
            return str(value)
        return f"0x{value:X}"
    return str(value)


def _format_sreg(sreg: int) -> str:
    bits = (
        ("I", (sreg >> 7) & 0x01),
        ("T", (sreg >> 6) & 0x01),
        ("H", (sreg >> 5) & 0x01),
        ("S", (sreg >> 4) & 0x01),
        ("V", (sreg >> 3) & 0x01),
        ("N", (sreg >> 2) & 0x01),
        ("Z", (sreg >> 1) & 0x01),
        ("C", sreg & 0x01),
    )
    return " ".join(f"{name}={value}" for name, value in bits)


def _wrap_lines(text: str, width: int) -> list[str]:
    width = max(1, width)
    if not text:
        return []
    lines: list[str] = []
    for raw_line in text.split("\n"):
        if raw_line == "":
            lines.append("")
            continue
        remaining = raw_line
        while remaining:
            lines.append(remaining[:width])
            remaining = remaining[width:]
    return lines


def _clip_line(text: str, width: int) -> str:
    width = max(1, width)
    return text[:width]


def _render_monitor(stdscr: Any, snapshot: RuntimeSnapshot) -> None:
    height, width = stdscr.getmaxyx()
    stdscr.erase()
    cpu_height = max(8, min(height - 3, height // 2 + 3))
    cpu_lines = format_cpu_panel(snapshot, width=max(1, width - 2))
    serial_height = max(1, height - cpu_height - 2)
    serial_lines = format_serial_panel(snapshot, width=max(1, width - 2), height=serial_height)

    _add_line(stdscr, 0, "[CPU]", width)
    for row, line in enumerate(cpu_lines[: max(0, cpu_height - 1)], start=1):
        _add_line(stdscr, row, line, width)

    separator_row = min(height - 2, cpu_height)
    _add_line(stdscr, separator_row, "-" * max(1, width - 1), width)
    if separator_row + 1 < height:
        _add_line(stdscr, separator_row + 1, "[Serial]", width)
    for index, line in enumerate(serial_lines, start=separator_row + 2):
        if index >= height:
            break
        _add_line(stdscr, index, line, width)
    stdscr.refresh()


def _add_line(stdscr: Any, row: int, text: str, width: int) -> None:
    if row < 0:
        return
    try:
        stdscr.addnstr(row, 0, text, max(1, width - 1))
    except Exception:  # pragma: no cover - terminal-size dependent
        return


__all__ = [
    "ProgramSymbolResolver",
    "RuntimeSnapshot",
    "build_runtime_snapshot",
    "format_cpu_panel",
    "format_serial_panel",
    "launch_runtime_monitor",
]
