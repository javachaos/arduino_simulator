"""Manual-grounded AVR CPU core for avrsim.

This module implements a fetch/decode/execute interpreter for the classic AVR
instruction encodings used by ATmega328P/ATmega2560-class devices. The opcode
layouts and instruction semantics are grounded in the AVR Instruction Set
Manual, DS40002198A.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Iterable, Protocol


FLAG_C = 0
FLAG_Z = 1
FLAG_N = 2
FLAG_V = 3
FLAG_S = 4
FLAG_H = 5
FLAG_T = 6
FLAG_I = 7

_POINTER_REGISTERS = {
    "X": (26, 27),
    "Y": (28, 29),
    "Z": (30, 31),
}


def _sign_extend(value: int, bits: int) -> int:
    sign_bit = 1 << (bits - 1)
    mask = (1 << bits) - 1
    value &= mask
    return value - (1 << bits) if (value & sign_bit) else value


def _u8(value: int) -> int:
    return value & 0xFF


def _u16(value: int) -> int:
    return value & 0xFFFF


def _bit(value: int, bit_index: int) -> int:
    return (value >> bit_index) & 0x01


def _to_signed8(value: int) -> int:
    value &= 0xFF
    return value - 0x100 if value & 0x80 else value


@dataclass(frozen=True)
class CPUConfig:
    """Static CPU configuration for one AVR core instance."""

    name: str = "generic_avr"
    program_size_bytes: int = 0x10000
    data_size_bytes: int = 0x1000
    sram_start_address: int = 0x0100
    pc_bits: int = 16
    sreg_address: int = 0x5F
    spl_address: int = 0x5D
    sph_address: int = 0x5E
    rampd_address: int | None = 0x58
    rampx_address: int | None = 0x59
    rampy_address: int | None = 0x5A
    rampz_address: int | None = 0x5B
    eind_address: int | None = 0x5C
    default_sp: int | None = None

    def __post_init__(self) -> None:
        if self.program_size_bytes <= 0 or (self.program_size_bytes % 2) != 0:
            raise ValueError("program_size_bytes must be a positive even value")
        if self.data_size_bytes <= 0:
            raise ValueError("data_size_bytes must be positive")
        if self.sram_start_address < 0 or self.sram_start_address >= self.data_size_bytes:
            raise ValueError("sram_start_address must point inside data memory")
        if self.pc_bits < 8 or self.pc_bits > 22:
            raise ValueError("pc_bits must be between 8 and 22 for AVR devices")
        for address_name in (
            "sreg_address",
            "spl_address",
            "sph_address",
            "rampd_address",
            "rampx_address",
            "rampy_address",
            "rampz_address",
            "eind_address",
        ):
            address = getattr(self, address_name)
            if address is None:
                continue
            if address < 0 or address >= self.data_size_bytes:
                raise ValueError(f"{address_name} must point inside data memory")
        if self.default_sp is not None and (
            self.default_sp < self.sram_start_address or self.default_sp >= self.data_size_bytes
        ):
            raise ValueError("default_sp must point inside SRAM")

    @property
    def program_size_words(self) -> int:
        return self.program_size_bytes // 2

    @property
    def pc_mask(self) -> int:
        return (1 << self.pc_bits) - 1

    @property
    def return_address_bytes(self) -> int:
        return 3 if self.pc_bits > 16 else 2

    @property
    def stack_reset_value(self) -> int:
        if self.default_sp is not None:
            return self.default_sp
        return self.data_size_bytes - 1

    @classmethod
    def atmega328p(cls) -> "CPUConfig":
        return cls(
            name="atmega328p",
            program_size_bytes=0x8000,
            data_size_bytes=0x0900,
            sram_start_address=0x0100,
            pc_bits=14,
            default_sp=0x08FF,
        )

    @classmethod
    def atmega2560(cls) -> "CPUConfig":
        return cls(
            name="atmega2560",
            program_size_bytes=0x40000,
            data_size_bytes=0x2200,
            sram_start_address=0x0200,
            pc_bits=17,
            default_sp=0x21FF,
        )


@dataclass(frozen=True)
class DecodedInstruction:
    """Decode result for one instruction word address."""

    address: int
    opcode: int
    next_word: int | None
    mnemonic: str
    word_length: int
    operands: dict[str, int | str | bool]

    @property
    def raw_words(self) -> tuple[int, ...]:
        if self.next_word is None:
            return (self.opcode,)
        return (self.opcode, self.next_word)


@dataclass(frozen=True)
class TranslatedBasicBlock:
    """A cached straight-line run of predecoded instructions."""

    start_address: int
    instructions: tuple[DecodedInstruction, ...]
    translated_ops: tuple["TranslatedOperation", ...]
    expected_next_pcs: tuple[int | None, ...]


@dataclass(frozen=True)
class TranslatedTrace:
    """A cached hot trace that may span multiple basic blocks."""

    start_address: int
    instructions: tuple[DecodedInstruction, ...]
    translated_ops: tuple["TranslatedOperation", ...]
    expected_next_pcs: tuple[int | None, ...]
    hint_versions: tuple[tuple[int, int], ...]
    open_hint_addresses: tuple[int, ...]


@dataclass(frozen=True)
class TranslatedOperation:
    """Compact operands for the hot instruction path in cached blocks."""

    kind: int
    a: int = 0
    b: int = 0
    c: int = 0
    flags: int = 0


_OP_FALLBACK = 0
_OP_NOP = 1
_OP_BREAK = 2
_OP_SLEEP = 3
_OP_WDR = 4
_OP_MOV = 5
_OP_MOVW = 6
_OP_LDI = 7
_OP_ADD = 8
_OP_ADC = 9
_OP_SUB = 10
_OP_SBC = 11
_OP_CP = 12
_OP_CPC = 13
_OP_SUBI = 14
_OP_SBCI = 15
_OP_CPI = 16
_OP_CPSE = 17
_OP_ADIW = 18
_OP_SBIW = 19
_OP_AND = 20
_OP_ANDI = 21
_OP_OR = 22
_OP_ORI = 23
_OP_EOR = 24
_OP_COM = 25
_OP_NEG = 26
_OP_INC = 27
_OP_DEC = 28
_OP_SWAP = 29
_OP_ASR = 30
_OP_LSR = 31
_OP_ROR = 32
_OP_MUL = 33
_OP_MULS = 34
_OP_MULSU = 35
_OP_FMUL = 36
_OP_FMULS = 37
_OP_FMULSU = 38
_OP_RJMP = 39
_OP_RCALL = 40
_OP_JMP = 41
_OP_CALL = 42
_OP_IJMP = 43
_OP_EIJMP = 44
_OP_ICALL = 45
_OP_EICALL = 46
_OP_RET = 47
_OP_RETI = 48
_OP_BRBS = 49
_OP_BRBC = 50
_OP_BSET = 51
_OP_BCLR = 52
_OP_BLD = 53
_OP_BST = 54
_OP_SBRC = 55
_OP_SBRS = 56
_OP_IN = 57
_OP_OUT = 58
_OP_CBI = 59
_OP_SBI = 60
_OP_SBIC = 61
_OP_SBIS = 62
_OP_PUSH = 63
_OP_POP = 64
_OP_LDS = 65
_OP_STS = 66
_OP_LD_PTR = 67
_OP_ST_PTR = 68
_OP_LD_DISP = 69
_OP_ST_DISP = 70
_OP_LPM = 71
_OP_XCH = 72
_OP_LAC = 73
_OP_LAS = 74
_OP_LAT = 75

_PTR_X = 0
_PTR_Y = 1
_PTR_Z = 2

_MODE_DIRECT = 0
_MODE_POSTINC = 1
_MODE_PREDEC = 2

_TRACE_DYNAMIC_SUCCESSORS = frozenset(
    {
        "brbs",
        "brbc",
        "cpse",
        "sbrc",
        "sbrs",
        "sbic",
        "sbis",
        "ijmp",
        "eijmp",
        "icall",
        "eicall",
        "ret",
        "reti",
    }
)


class CPUError(RuntimeError):
    """Base class for CPU simulation failures."""


class ProgramBoundsError(CPUError):
    """Raised when program memory fetches exceed the configured flash window."""


class DataAddressError(CPUError):
    """Raised for invalid data-space accesses."""


class UnsupportedInstructionError(CPUError):
    """Raised when the CPU encounters an unimplemented machine instruction."""


class CPUHooks(Protocol):
    """Optional hook surface for memory-mapped peripherals and runtime glue."""

    def reset(self, cpu: "CPU") -> None:
        """Reinitialize hook-owned state after a CPU reset."""

    def read_data(self, cpu: "CPU", address: int) -> int | None:
        """Return a handled byte value, or `None` to fall back to core memory."""

    def write_data(self, cpu: "CPU", address: int, value: int) -> bool:
        """Handle a write and return `True` when the hook consumed it."""

    def after_step(self, cpu: "CPU", instruction: DecodedInstruction, cycles: int) -> None:
        """Advance hook-owned peripherals after one retired instruction."""


@dataclass
class CPU:
    """A small but real AVR fetch/decode/execute interpreter."""

    config: CPUConfig = field(default_factory=CPUConfig.atmega328p)
    hooks: CPUHooks | None = None
    enable_block_jit: bool = False
    enable_trace_cache: bool = False

    def __post_init__(self) -> None:
        self.program = bytearray((0xFF for _ in range(self.config.program_size_bytes)))
        self.data = bytearray(self.config.data_size_bytes)
        self.pc = 0
        self.cycles = 0
        self.break_hit = False
        self.sleeping = False
        self._interrupt_delay_steps = 0
        self._decode_cache: dict[int, DecodedInstruction] = {}
        self._basic_block_cache: dict[int, TranslatedBasicBlock] = {}
        self._trace_cache: dict[int, TranslatedTrace] = {}
        self._compiled_block_cache: dict[int, Callable[["CPU", int | None, bool, bool], int]] = {}
        self._compiled_trace_cache: dict[int, Callable[["CPU", int | None, bool, bool], int]] = {}
        self._trace_edge_counts: dict[int, dict[int, int]] = {}
        self._trace_preferred_successor: dict[int, int] = {}
        self._trace_hint_versions: dict[int, int] = {}
        self._trace_stable_hits: dict[int, int] = {}
        self.reset(clear_program=False)

    def reset(self, clear_program: bool = False) -> None:
        """Reset CPU-visible state back to power-on defaults."""

        self.data[:] = bytes(len(self.data))
        if clear_program:
            self.program[:] = bytes((0xFF for _ in range(len(self.program))))
            self._invalidate_translation_caches()
        self.pc = 0
        self.cycles = 0
        self.break_hit = False
        self.sleeping = False
        self._interrupt_delay_steps = 0
        self.sp = self.config.stack_reset_value
        if self.hooks is not None:
            self.hooks.reset(self)

    def wake(self) -> None:
        self.sleeping = False

    def load_program_bytes(self, program_bytes: bytes | bytearray, start_byte: int = 0) -> None:
        if start_byte < 0 or start_byte + len(program_bytes) > len(self.program):
            raise ProgramBoundsError("program image does not fit in configured flash")
        self.program[start_byte : start_byte + len(program_bytes)] = program_bytes
        self._invalidate_translation_caches()

    def load_program_words(self, words: Iterable[int], start_word: int = 0) -> None:
        program_bytes = bytearray()
        for word in words:
            program_bytes.append(word & 0xFF)
            program_bytes.append((word >> 8) & 0xFF)
        self.load_program_bytes(program_bytes, start_byte=start_word * 2)

    def set_program_word(self, address: int, word: int) -> None:
        if address < 0 or address >= self.config.program_size_words:
            raise ProgramBoundsError("program word address is out of range")
        byte_address = address * 2
        self.program[byte_address] = word & 0xFF
        self.program[byte_address + 1] = (word >> 8) & 0xFF
        self._invalidate_translation_caches()

    @property
    def sreg(self) -> int:
        return self.data[self.config.sreg_address]

    @sreg.setter
    def sreg(self, value: int) -> None:
        self.data[self.config.sreg_address] = value & 0xFF

    @property
    def sp(self) -> int:
        return self.data[self.config.spl_address] | (self.data[self.config.sph_address] << 8)

    @sp.setter
    def sp(self, value: int) -> None:
        value &= 0xFFFF
        self.data[self.config.spl_address] = value & 0xFF
        self.data[self.config.sph_address] = (value >> 8) & 0xFF

    def read_register(self, index: int) -> int:
        self._validate_register_index(index)
        return self.data[index]

    def write_register(self, index: int, value: int) -> None:
        self._validate_register_index(index)
        self.data[index] = value & 0xFF

    def read_data(self, address: int) -> int:
        self._validate_data_address(address)
        if self.hooks is not None:
            hook_value = self.hooks.read_data(self, address)
            if hook_value is not None:
                return hook_value & 0xFF
        return self.data[address]

    def write_data(self, address: int, value: int) -> None:
        self._validate_data_address(address)
        if self.hooks is not None and self.hooks.write_data(self, address, value & 0xFF):
            return
        self.data[address] = value & 0xFF

    @property
    def interrupts_deferred(self) -> bool:
        return self._interrupt_delay_steps > 0

    def take_interrupt(self, vector_number: int, *, latency_cycles: int = 4) -> None:
        """Enter one interrupt by vector-table index."""

        if vector_number <= 0:
            raise ValueError("interrupt vector number must be positive")
        self.sleeping = False
        self._push_pc(self.pc)
        self.set_flag(FLAG_I, 0)
        self.pc = self._normalize_pc(vector_number * 2)
        self.cycles += latency_cycles

    def read_io(self, address: int) -> int:
        if address < 0 or address > 0x3F:
            raise DataAddressError("I/O address must be in the range 0..63")
        return self.read_data(0x20 + address)

    def write_io(self, address: int, value: int) -> None:
        if address < 0 or address > 0x3F:
            raise DataAddressError("I/O address must be in the range 0..63")
        self.write_data(0x20 + address, value)

    def fetch_word(self, address: int) -> int:
        if address < 0 or address >= self.config.program_size_words:
            raise ProgramBoundsError(f"program word address {address} is out of range")
        byte_address = address * 2
        return self.program[byte_address] | (self.program[byte_address + 1] << 8)

    def read_program_byte(self, byte_address: int) -> int:
        if byte_address < 0 or byte_address >= len(self.program):
            return 0xFF
        return self.program[byte_address]

    def decode_at(self, address: int | None = None) -> DecodedInstruction:
        pc = self.pc if address is None else address
        cached_instruction = self._decode_cache.get(pc)
        if cached_instruction is not None:
            return cached_instruction
        opcode = self.fetch_word(pc)

        def single(mnemonic: str, **operands: int | str | bool) -> DecodedInstruction:
            return DecodedInstruction(
                address=pc,
                opcode=opcode,
                next_word=None,
                mnemonic=mnemonic,
                word_length=1,
                operands=dict(operands),
            )

        def double(mnemonic: str, **operands: int | str | bool) -> DecodedInstruction:
            return DecodedInstruction(
                address=pc,
                opcode=opcode,
                next_word=self.fetch_word(pc + 1),
                mnemonic=mnemonic,
                word_length=2,
                operands=dict(operands),
            )

        if opcode == 0x0000:
            return self._cache_decoded_instruction(pc, single("nop"))
        if opcode == 0x9598:
            return self._cache_decoded_instruction(pc, single("break"))
        if opcode == 0x9588:
            return self._cache_decoded_instruction(pc, single("sleep"))
        if opcode == 0x95A8:
            return self._cache_decoded_instruction(pc, single("wdr"))
        if opcode == 0x9508:
            return self._cache_decoded_instruction(pc, single("ret"))
        if opcode == 0x9518:
            return self._cache_decoded_instruction(pc, single("reti"))
        if opcode == 0x9509:
            return self._cache_decoded_instruction(pc, single("icall"))
        if opcode == 0x9519:
            return self._cache_decoded_instruction(pc, single("eicall"))
        if opcode == 0x9409:
            return self._cache_decoded_instruction(pc, single("ijmp"))
        if opcode == 0x9419:
            return self._cache_decoded_instruction(pc, single("eijmp"))
        if opcode == 0x95C8:
            return self._cache_decoded_instruction(pc, single("lpm", d=0, post_increment=False, extended=False))
        if opcode == 0x95D8:
            return self._cache_decoded_instruction(pc, single("lpm", d=0, post_increment=False, extended=True))
        if opcode in (0x95E8, 0x95F8):
            return self._cache_decoded_instruction(pc, single("spm"))

        if (opcode & 0xFE0E) == 0x940C:
            next_word = self.fetch_word(pc + 1)
            target = ((opcode & 0x01F0) << 13) | ((opcode & 0x0001) << 16) | next_word
            return self._cache_decoded_instruction(pc, DecodedInstruction(
                address=pc,
                opcode=opcode,
                next_word=next_word,
                mnemonic="jmp",
                word_length=2,
                operands={"k": target},
            ))
        if (opcode & 0xFE0E) == 0x940E:
            next_word = self.fetch_word(pc + 1)
            target = ((opcode & 0x01F0) << 13) | ((opcode & 0x0001) << 16) | next_word
            return self._cache_decoded_instruction(pc, DecodedInstruction(
                address=pc,
                opcode=opcode,
                next_word=next_word,
                mnemonic="call",
                word_length=2,
                operands={"k": target},
            ))
        if (opcode & 0xFE0F) == 0x9000:
            return self._cache_decoded_instruction(pc, double("lds", d=(opcode >> 4) & 0x1F, k=self.fetch_word(pc + 1)))
        if (opcode & 0xFE0F) == 0x9200:
            return self._cache_decoded_instruction(pc, double("sts", r=(opcode >> 4) & 0x1F, k=self.fetch_word(pc + 1)))

        if (opcode & 0xFF8F) == 0x9408:
            return self._cache_decoded_instruction(pc, single("bset", s=(opcode >> 4) & 0x07))
        if (opcode & 0xFF8F) == 0x9488:
            return self._cache_decoded_instruction(pc, single("bclr", s=(opcode >> 4) & 0x07))

        if (opcode & 0xFF00) == 0x9800:
            return self._cache_decoded_instruction(pc, single("cbi", a=(opcode >> 3) & 0x1F, b=opcode & 0x07))
        if (opcode & 0xFF00) == 0x9900:
            return self._cache_decoded_instruction(pc, single("sbic", a=(opcode >> 3) & 0x1F, b=opcode & 0x07))
        if (opcode & 0xFF00) == 0x9A00:
            return self._cache_decoded_instruction(pc, single("sbi", a=(opcode >> 3) & 0x1F, b=opcode & 0x07))
        if (opcode & 0xFF00) == 0x9B00:
            return self._cache_decoded_instruction(pc, single("sbis", a=(opcode >> 3) & 0x1F, b=opcode & 0x07))

        if (opcode & 0xFE0F) == 0x900F:
            return self._cache_decoded_instruction(pc, single("pop", d=(opcode >> 4) & 0x1F))
        if (opcode & 0xFE0F) == 0x920F:
            return self._cache_decoded_instruction(pc, single("push", r=(opcode >> 4) & 0x1F))

        if (opcode & 0xFE0F) == 0x9004:
            return self._cache_decoded_instruction(pc, single("lpm", d=(opcode >> 4) & 0x1F, post_increment=False, extended=False))
        if (opcode & 0xFE0F) == 0x9005:
            return self._cache_decoded_instruction(pc, single("lpm", d=(opcode >> 4) & 0x1F, post_increment=True, extended=False))
        if (opcode & 0xFE0F) == 0x9006:
            return self._cache_decoded_instruction(pc, single("lpm", d=(opcode >> 4) & 0x1F, post_increment=False, extended=True))
        if (opcode & 0xFE0F) == 0x9007:
            return self._cache_decoded_instruction(pc, single("lpm", d=(opcode >> 4) & 0x1F, post_increment=True, extended=True))

        if (opcode & 0xFE0F) == 0x9204:
            return self._cache_decoded_instruction(pc, single("xch", d=(opcode >> 4) & 0x1F))
        if (opcode & 0xFE0F) == 0x9205:
            return self._cache_decoded_instruction(pc, single("las", d=(opcode >> 4) & 0x1F))
        if (opcode & 0xFE0F) == 0x9206:
            return self._cache_decoded_instruction(pc, single("lac", d=(opcode >> 4) & 0x1F))
        if (opcode & 0xFE0F) == 0x9207:
            return self._cache_decoded_instruction(pc, single("lat", d=(opcode >> 4) & 0x1F))

        if (opcode & 0xFE0F) == 0x9400:
            return self._cache_decoded_instruction(pc, single("com", d=(opcode >> 4) & 0x1F))
        if (opcode & 0xFE0F) == 0x9401:
            return self._cache_decoded_instruction(pc, single("neg", d=(opcode >> 4) & 0x1F))
        if (opcode & 0xFE0F) == 0x9402:
            return self._cache_decoded_instruction(pc, single("swap", d=(opcode >> 4) & 0x1F))
        if (opcode & 0xFE0F) == 0x9403:
            return self._cache_decoded_instruction(pc, single("inc", d=(opcode >> 4) & 0x1F))
        if (opcode & 0xFE0F) == 0x9405:
            return self._cache_decoded_instruction(pc, single("asr", d=(opcode >> 4) & 0x1F))
        if (opcode & 0xFE0F) == 0x9406:
            return self._cache_decoded_instruction(pc, single("lsr", d=(opcode >> 4) & 0x1F))
        if (opcode & 0xFE0F) == 0x9407:
            return self._cache_decoded_instruction(pc, single("ror", d=(opcode >> 4) & 0x1F))
        if (opcode & 0xFE0F) == 0x940A:
            return self._cache_decoded_instruction(pc, single("dec", d=(opcode >> 4) & 0x1F))
        if (opcode & 0xFF0F) == 0x940B:
            return self._cache_decoded_instruction(pc, single("des", k=(opcode >> 4) & 0x0F))

        if (opcode & 0xFE0F) == 0x900C:
            return self._cache_decoded_instruction(pc, single("ld_ptr", d=(opcode >> 4) & 0x1F, pointer="X", mode="direct"))
        if (opcode & 0xFE0F) == 0x900D:
            return single("ld_ptr", d=(opcode >> 4) & 0x1F, pointer="X", mode="postinc")
        if (opcode & 0xFE0F) == 0x900E:
            return single("ld_ptr", d=(opcode >> 4) & 0x1F, pointer="X", mode="predec")
        if (opcode & 0xFE0F) == 0x920C:
            return self._cache_decoded_instruction(pc, single("st_ptr", r=(opcode >> 4) & 0x1F, pointer="X", mode="direct"))
        if (opcode & 0xFE0F) == 0x920D:
            return single("st_ptr", r=(opcode >> 4) & 0x1F, pointer="X", mode="postinc")
        if (opcode & 0xFE0F) == 0x920E:
            return single("st_ptr", r=(opcode >> 4) & 0x1F, pointer="X", mode="predec")

        if (opcode & 0xFE0F) == 0x9009:
            return self._cache_decoded_instruction(pc, single("ld_ptr", d=(opcode >> 4) & 0x1F, pointer="Y", mode="postinc"))
        if (opcode & 0xFE0F) == 0x900A:
            return single("ld_ptr", d=(opcode >> 4) & 0x1F, pointer="Y", mode="predec")
        if (opcode & 0xFE0F) == 0x9001:
            return self._cache_decoded_instruction(pc, single("ld_ptr", d=(opcode >> 4) & 0x1F, pointer="Z", mode="postinc"))
        if (opcode & 0xFE0F) == 0x9002:
            return single("ld_ptr", d=(opcode >> 4) & 0x1F, pointer="Z", mode="predec")

        if (opcode & 0xFE0F) == 0x9209:
            return single("st_ptr", r=(opcode >> 4) & 0x1F, pointer="Y", mode="postinc")
        if (opcode & 0xFE0F) == 0x920A:
            return single("st_ptr", r=(opcode >> 4) & 0x1F, pointer="Y", mode="predec")
        if (opcode & 0xFE0F) == 0x9201:
            return single("st_ptr", r=(opcode >> 4) & 0x1F, pointer="Z", mode="postinc")
        if (opcode & 0xFE0F) == 0x9202:
            return single("st_ptr", r=(opcode >> 4) & 0x1F, pointer="Z", mode="predec")

        if (opcode & 0xFF00) == 0x9600:
            return self._cache_decoded_instruction(pc, single(
                "adiw",
                d=24 + (((opcode >> 4) & 0x03) * 2),
                k=(opcode & 0x0F) | ((opcode >> 2) & 0x30),
            ))
        if (opcode & 0xFF00) == 0x9700:
            return self._cache_decoded_instruction(pc, single(
                "sbiw",
                d=24 + (((opcode >> 4) & 0x03) * 2),
                k=(opcode & 0x0F) | ((opcode >> 2) & 0x30),
            ))

        if (opcode & 0xFF00) == 0x0200:
            return self._cache_decoded_instruction(pc, single("muls", d=16 + ((opcode >> 4) & 0x0F), r=16 + (opcode & 0x0F)))
        if (opcode & 0xFF88) == 0x0300:
            return single("mulsu", d=16 + ((opcode >> 4) & 0x07), r=16 + (opcode & 0x07))
        if (opcode & 0xFF88) == 0x0308:
            return single("fmul", d=16 + ((opcode >> 4) & 0x07), r=16 + (opcode & 0x07))
        if (opcode & 0xFF88) == 0x0380:
            return single("fmuls", d=16 + ((opcode >> 4) & 0x07), r=16 + (opcode & 0x07))
        if (opcode & 0xFF88) == 0x0388:
            return single("fmulsu", d=16 + ((opcode >> 4) & 0x07), r=16 + (opcode & 0x07))
        if (opcode & 0xFF00) == 0x0100:
            return self._cache_decoded_instruction(pc, single("movw", d=((opcode >> 4) & 0x0F) * 2, r=(opcode & 0x0F) * 2))
        if (opcode & 0xFC00) == 0x9C00:
            return self._cache_decoded_instruction(pc, single("mul", d=(opcode >> 4) & 0x1F, r=(opcode & 0x0F) | ((opcode >> 5) & 0x10)))

        register_d = (opcode >> 4) & 0x1F
        register_r = (opcode & 0x0F) | ((opcode >> 5) & 0x10)
        if (opcode & 0xFC00) == 0x0400:
            return self._cache_decoded_instruction(pc, single("cpc", d=register_d, r=register_r))
        if (opcode & 0xFC00) == 0x0800:
            return single("sbc", d=register_d, r=register_r)
        if (opcode & 0xFC00) == 0x0C00:
            return single("add", d=register_d, r=register_r)
        if (opcode & 0xFC00) == 0x1000:
            return single("cpse", d=register_d, r=register_r)
        if (opcode & 0xFC00) == 0x1400:
            return single("cp", d=register_d, r=register_r)
        if (opcode & 0xFC00) == 0x1800:
            return single("sub", d=register_d, r=register_r)
        if (opcode & 0xFC00) == 0x1C00:
            return single("adc", d=register_d, r=register_r)
        if (opcode & 0xFC00) == 0x2000:
            return single("and", d=register_d, r=register_r)
        if (opcode & 0xFC00) == 0x2400:
            return single("eor", d=register_d, r=register_r)
        if (opcode & 0xFC00) == 0x2800:
            return single("or", d=register_d, r=register_r)
        if (opcode & 0xFC00) == 0x2C00:
            return self._cache_decoded_instruction(pc, single("mov", d=register_d, r=register_r))

        immediate = (opcode & 0x0F) | ((opcode >> 4) & 0xF0)
        immediate_d = 16 + ((opcode >> 4) & 0x0F)
        if (opcode & 0xF000) == 0x3000:
            return self._cache_decoded_instruction(pc, single("cpi", d=immediate_d, k=immediate))
        if (opcode & 0xF000) == 0x4000:
            return single("sbci", d=immediate_d, k=immediate)
        if (opcode & 0xF000) == 0x5000:
            return single("subi", d=immediate_d, k=immediate)
        if (opcode & 0xF000) == 0x6000:
            return single("ori", d=immediate_d, k=immediate)
        if (opcode & 0xF000) == 0x7000:
            return single("andi", d=immediate_d, k=immediate)
        if (opcode & 0xF000) == 0xE000:
            return self._cache_decoded_instruction(pc, single("ldi", d=immediate_d, k=immediate))

        if (opcode & 0xF000) == 0xC000:
            return self._cache_decoded_instruction(pc, single("rjmp", k=_sign_extend(opcode & 0x0FFF, 12)))
        if (opcode & 0xF000) == 0xD000:
            return self._cache_decoded_instruction(pc, single("rcall", k=_sign_extend(opcode & 0x0FFF, 12)))

        if (opcode & 0xFC00) == 0xF000:
            return self._cache_decoded_instruction(pc, single("brbs", s=opcode & 0x07, k=_sign_extend((opcode >> 3) & 0x7F, 7)))
        if (opcode & 0xFC00) == 0xF400:
            return single("brbc", s=opcode & 0x07, k=_sign_extend((opcode >> 3) & 0x7F, 7))
        if (opcode & 0xFE08) == 0xF800:
            return single("bld", d=(opcode >> 4) & 0x1F, b=opcode & 0x07)
        if (opcode & 0xFE08) == 0xFA00:
            return single("bst", d=(opcode >> 4) & 0x1F, b=opcode & 0x07)
        if (opcode & 0xFE08) == 0xFC00:
            return single("sbrc", r=(opcode >> 4) & 0x1F, b=opcode & 0x07)
        if (opcode & 0xFE08) == 0xFE00:
            return single("sbrs", r=(opcode >> 4) & 0x1F, b=opcode & 0x07)

        if (opcode & 0xF800) == 0xB000:
            return self._cache_decoded_instruction(pc, single("in", d=(opcode >> 4) & 0x1F, a=(opcode & 0x0F) | ((opcode >> 5) & 0x30)))
        if (opcode & 0xF800) == 0xB800:
            return self._cache_decoded_instruction(pc, single("out", r=(opcode >> 4) & 0x1F, a=(opcode & 0x0F) | ((opcode >> 5) & 0x30)))

        if (opcode & 0xC000) == 0x8000:
            displacement = ((opcode >> 8) & 0x20) | ((opcode >> 7) & 0x18) | (opcode & 0x07)
            register = (opcode >> 4) & 0x1F
            pointer = "Y" if (opcode & 0x0008) else "Z"
            is_store = (opcode & 0x0200) != 0
            if is_store:
                return self._cache_decoded_instruction(pc, single("st_disp", r=register, pointer=pointer, q=displacement))
            return self._cache_decoded_instruction(pc, single("ld_disp", d=register, pointer=pointer, q=displacement))

        raise UnsupportedInstructionError(f"unsupported opcode 0x{opcode:04X} at word address {pc}")

    def step(self) -> DecodedInstruction:
        if self.sleeping:
            raise CPUError("CPU is sleeping; call wake() before stepping again")

        instruction = self.decode_at(self.pc)
        self._execute_translated_operation(instruction, self._translate_instruction(instruction))
        return instruction

    def _execute_decoded_instruction(self, instruction: DecodedInstruction) -> None:
        self._execute_translated_operation(instruction, self._translate_instruction(instruction))

    def _execute_translated_operation(self, instruction: DecodedInstruction, translated: TranslatedOperation) -> None:
        current_pc = self.pc
        next_pc = current_pc + instruction.word_length
        cycles = 0
        data = self.data
        kind = translated.kind

        if kind == _OP_NOP:
            cycles = 1
        elif kind == _OP_BREAK:
            self.break_hit = True
            cycles = 1
        elif kind == _OP_SLEEP:
            self.sleeping = True
            cycles = 1
        elif kind == _OP_WDR:
            cycles = 1
        elif kind == _OP_MOV:
            data[translated.a] = data[translated.b]
            cycles = 1
        elif kind == _OP_MOVW:
            data[translated.a] = data[translated.b]
            data[translated.a + 1] = data[translated.b + 1]
            cycles = 1
        elif kind == _OP_LDI:
            data[translated.a] = translated.b & 0xFF
            cycles = 1
        elif kind == _OP_ADD or kind == _OP_ADC:
            carry_in = self.get_flag(FLAG_C) if kind == _OP_ADC else 0
            result = self._add8(data[translated.a], data[translated.b], carry_in)
            data[translated.a] = result
            cycles = 1
        elif kind in {_OP_SUB, _OP_SBC, _OP_CP, _OP_CPC}:
            carry_in = self.get_flag(FLAG_C) if kind in {_OP_SBC, _OP_CPC} else 0
            previous_z = self.get_flag(FLAG_Z) if kind in {_OP_SBC, _OP_CPC} else None
            result = self._sub8(data[translated.a], data[translated.b], carry_in, previous_z)
            if kind in {_OP_SUB, _OP_SBC}:
                data[translated.a] = result
            cycles = 1
        elif kind in {_OP_SUBI, _OP_SBCI, _OP_CPI}:
            carry_in = self.get_flag(FLAG_C) if kind == _OP_SBCI else 0
            previous_z = self.get_flag(FLAG_Z) if kind == _OP_SBCI else None
            result = self._sub8(data[translated.a], translated.b, carry_in, previous_z)
            if kind != _OP_CPI:
                data[translated.a] = result
            cycles = 1
        elif kind == _OP_CPSE:
            if data[translated.a] == data[translated.b]:
                next_length = self.decode_at(current_pc + 1).word_length
                next_pc = current_pc + 1 + next_length
                cycles = 1 + next_length
            else:
                cycles = 1
        elif kind == _OP_ADIW:
            value = data[translated.a] | (data[translated.a + 1] << 8)
            result = (value + translated.b) & 0xFFFF
            data[translated.a] = result & 0xFF
            data[translated.a + 1] = (result >> 8) & 0xFF
            self._set_adiw_flags(value, result)
            cycles = 2
        elif kind == _OP_SBIW:
            value = data[translated.a] | (data[translated.a + 1] << 8)
            result = (value - translated.b) & 0xFFFF
            data[translated.a] = result & 0xFF
            data[translated.a + 1] = (result >> 8) & 0xFF
            self._set_sbiw_flags(value, result)
            cycles = 2
        elif kind == _OP_AND:
            result = data[translated.a] & data[translated.b]
            data[translated.a] = result
            self._set_logic_flags(result)
            cycles = 1
        elif kind == _OP_ANDI:
            result = data[translated.a] & translated.b
            data[translated.a] = result
            self._set_logic_flags(result)
            cycles = 1
        elif kind == _OP_OR:
            result = data[translated.a] | data[translated.b]
            data[translated.a] = result
            self._set_logic_flags(result)
            cycles = 1
        elif kind == _OP_ORI:
            result = data[translated.a] | translated.b
            data[translated.a] = result
            self._set_logic_flags(result)
            cycles = 1
        elif kind == _OP_EOR:
            result = data[translated.a] ^ data[translated.b]
            data[translated.a] = result
            self._set_logic_flags(result)
            cycles = 1
        elif kind == _OP_COM:
            result = _u8(0xFF - data[translated.a])
            data[translated.a] = result
            self.set_flag(FLAG_V, 0)
            self.set_flag(FLAG_C, 1)
            self._set_nzs_from_result(result)
            cycles = 1
        elif kind == _OP_NEG:
            original = data[translated.a]
            result = _u8(-original)
            data[translated.a] = result
            self._set_neg_flags(result, original)
            cycles = 1
        elif kind == _OP_INC:
            value = data[translated.a]
            result = _u8(value + 1)
            data[translated.a] = result
            self.set_flag(FLAG_V, 1 if result == 0x80 else 0)
            self._set_nzs_from_result(result)
            cycles = 1
        elif kind == _OP_DEC:
            value = data[translated.a]
            result = _u8(value - 1)
            data[translated.a] = result
            self.set_flag(FLAG_V, 1 if result == 0x7F else 0)
            self._set_nzs_from_result(result)
            cycles = 1
        elif kind == _OP_SWAP:
            value = data[translated.a]
            data[translated.a] = ((value & 0x0F) << 4) | ((value >> 4) & 0x0F)
            cycles = 1
        elif kind == _OP_ASR:
            value = data[translated.a]
            carry = value & 0x01
            result = (value >> 1) | (value & 0x80)
            data[translated.a] = result
            self.set_flag(FLAG_C, carry)
            self.set_flag(FLAG_N, 1 if (result & 0x80) else 0)
            self.set_flag(FLAG_V, self.get_flag(FLAG_N) ^ self.get_flag(FLAG_C))
            self.set_flag(FLAG_S, self.get_flag(FLAG_N) ^ self.get_flag(FLAG_V))
            self.set_flag(FLAG_Z, 1 if result == 0 else 0)
            cycles = 1
        elif kind == _OP_LSR:
            value = data[translated.a]
            carry = value & 0x01
            result = value >> 1
            data[translated.a] = result
            self.set_flag(FLAG_C, carry)
            self.set_flag(FLAG_N, 0)
            self.set_flag(FLAG_V, self.get_flag(FLAG_N) ^ self.get_flag(FLAG_C))
            self.set_flag(FLAG_S, self.get_flag(FLAG_N) ^ self.get_flag(FLAG_V))
            self.set_flag(FLAG_Z, 1 if result == 0 else 0)
            cycles = 1
        elif kind == _OP_ROR:
            value = data[translated.a]
            carry_in = self.get_flag(FLAG_C)
            carry_out = value & 0x01
            result = ((carry_in << 7) | (value >> 1)) & 0xFF
            data[translated.a] = result
            self.set_flag(FLAG_C, carry_out)
            self.set_flag(FLAG_N, 1 if (result & 0x80) else 0)
            self.set_flag(FLAG_V, self.get_flag(FLAG_N) ^ self.get_flag(FLAG_C))
            self.set_flag(FLAG_S, self.get_flag(FLAG_N) ^ self.get_flag(FLAG_V))
            self.set_flag(FLAG_Z, 1 if result == 0 else 0)
            cycles = 1
        elif kind == _OP_MUL:
            product = data[translated.a] * data[translated.b]
            self._write_product(product)
            cycles = 2
        elif kind == _OP_MULS:
            product = _to_signed8(data[translated.a]) * _to_signed8(data[translated.b])
            self._write_product(product)
            cycles = 2
        elif kind == _OP_MULSU:
            product = _to_signed8(data[translated.a]) * data[translated.b]
            self._write_product(product)
            cycles = 2
        elif kind == _OP_FMUL:
            raw = data[translated.a] * data[translated.b]
            self._write_fractional_product(raw)
            cycles = 2
        elif kind == _OP_FMULS:
            raw = _to_signed8(data[translated.a]) * _to_signed8(data[translated.b])
            self._write_fractional_product(raw)
            cycles = 2
        elif kind == _OP_FMULSU:
            raw = _to_signed8(data[translated.a]) * data[translated.b]
            self._write_fractional_product(raw)
            cycles = 2
        elif kind == _OP_RJMP:
            next_pc = current_pc + 1 + translated.a
            cycles = 2
        elif kind == _OP_RCALL:
            return_address = current_pc + 1
            self._push_pc(return_address)
            next_pc = current_pc + 1 + translated.a
            cycles = 4 if self.config.return_address_bytes == 3 else 3
        elif kind == _OP_JMP:
            next_pc = translated.a
            cycles = 3
        elif kind == _OP_CALL:
            return_address = current_pc + 2
            self._push_pc(return_address)
            next_pc = translated.a
            cycles = 5 if self.config.return_address_bytes == 3 else 4
        elif kind == _OP_IJMP:
            next_pc = self._pointer_word_address("Z", None)
            cycles = 2
        elif kind == _OP_EIJMP:
            next_pc = self._pointer_word_address("Z", self.config.eind_address)
            cycles = 2
        elif kind == _OP_ICALL:
            return_address = current_pc + 1
            self._push_pc(return_address)
            next_pc = self._pointer_word_address("Z", None)
            cycles = 4 if self.config.return_address_bytes == 3 else 3
        elif kind == _OP_EICALL:
            self._ensure_extended_pc()
            return_address = current_pc + 1
            self._push_pc(return_address)
            next_pc = self._pointer_word_address("Z", self.config.eind_address)
            cycles = 4
        elif kind == _OP_RET:
            next_pc = self._pop_pc()
            cycles = 5 if self.config.return_address_bytes == 3 else 4
        elif kind == _OP_RETI:
            next_pc = self._pop_pc()
            self.set_flag(FLAG_I, 1)
            self._interrupt_delay_steps = max(self._interrupt_delay_steps, 1)
            cycles = 5 if self.config.return_address_bytes == 3 else 4
        elif kind == _OP_BRBS:
            if self.get_flag(translated.a):
                next_pc = current_pc + 1 + translated.b
                cycles = 2
            else:
                cycles = 1
        elif kind == _OP_BRBC:
            if not self.get_flag(translated.a):
                next_pc = current_pc + 1 + translated.b
                cycles = 2
            else:
                cycles = 1
        elif kind == _OP_BSET:
            self.set_flag(translated.a, 1)
            if translated.a == FLAG_I:
                self._interrupt_delay_steps = max(self._interrupt_delay_steps, 1)
            cycles = 1
        elif kind == _OP_BCLR:
            self.set_flag(translated.a, 0)
            cycles = 1
        elif kind == _OP_BLD:
            value = data[translated.a]
            mask = 1 << translated.b
            if self.get_flag(FLAG_T):
                value |= mask
            else:
                value &= ~mask & 0xFF
            data[translated.a] = value
            cycles = 1
        elif kind == _OP_BST:
            self.set_flag(FLAG_T, 1 if (data[translated.a] & (1 << translated.b)) else 0)
            cycles = 1
        elif kind == _OP_SBRC:
            if (data[translated.a] & (1 << translated.b)) == 0:
                next_length = self.decode_at(current_pc + 1).word_length
                next_pc = current_pc + 1 + next_length
                cycles = 1 + next_length
            else:
                cycles = 1
        elif kind == _OP_SBRS:
            if (data[translated.a] & (1 << translated.b)) != 0:
                next_length = self.decode_at(current_pc + 1).word_length
                next_pc = current_pc + 1 + next_length
                cycles = 1 + next_length
            else:
                cycles = 1
        elif kind == _OP_IN:
            data[translated.a] = self.read_io(translated.b)
            cycles = 1
        elif kind == _OP_OUT:
            self.write_io(translated.b, data[translated.a])
            cycles = 1
        elif kind == _OP_CBI:
            bit_mask = 1 << translated.b
            self.write_io(translated.a, self.read_io(translated.a) & (~bit_mask & 0xFF))
            cycles = 2
        elif kind == _OP_SBI:
            bit_mask = 1 << translated.b
            self.write_io(translated.a, self.read_io(translated.a) | bit_mask)
            cycles = 2
        elif kind == _OP_SBIC:
            if (self.read_io(translated.a) & (1 << translated.b)) == 0:
                next_length = self.decode_at(current_pc + 1).word_length
                next_pc = current_pc + 1 + next_length
                cycles = 1 + next_length
            else:
                cycles = 1
        elif kind == _OP_SBIS:
            if (self.read_io(translated.a) & (1 << translated.b)) != 0:
                next_length = self.decode_at(current_pc + 1).word_length
                next_pc = current_pc + 1 + next_length
                cycles = 1 + next_length
            else:
                cycles = 1
        elif kind == _OP_PUSH:
            self.push_byte(data[translated.a])
            cycles = 2
        elif kind == _OP_POP:
            data[translated.a] = self.pop_byte()
            cycles = 2
        elif kind == _OP_LDS:
            data[translated.a] = self.read_data(self._direct_data_address(translated.b))
            cycles = 2
        elif kind == _OP_STS:
            self.write_data(self._direct_data_address(translated.b), data[translated.a])
            cycles = 2
        elif kind == _OP_LD_PTR:
            data[translated.a] = self._read_pointer_mode(self._decode_pointer(translated.b), self._decode_mode(translated.c))
            cycles = 2
        elif kind == _OP_ST_PTR:
            self._write_pointer_mode(self._decode_pointer(translated.b), self._decode_mode(translated.c), data[translated.a])
            cycles = 2
        elif kind == _OP_LD_DISP:
            address = self._pointer_data_address(self._decode_pointer(translated.b)) + translated.c
            data[translated.a] = self.read_data(address)
            cycles = 2
        elif kind == _OP_ST_DISP:
            address = self._pointer_data_address(self._decode_pointer(translated.b)) + translated.c
            self.write_data(address, data[translated.a])
            cycles = 2
        elif kind == _OP_LPM:
            destination = translated.a
            post_increment = (translated.flags & 0x01) != 0
            extended = (translated.flags & 0x02) != 0
            byte_address = self._program_pointer_byte_address(extended)
            data[destination] = self.read_program_byte(byte_address)
            if post_increment:
                self._increment_program_pointer(extended)
            cycles = 3
        elif kind == _OP_XCH:
            address = self._pointer_data_address("Z")
            self._ensure_sram_operation_address(address, "xch")
            memory_value = self.read_data(address)
            register_value = data[translated.a]
            self.write_data(address, register_value)
            data[translated.a] = memory_value
            cycles = 2
        elif kind == _OP_LAC:
            address = self._pointer_data_address("Z")
            self._ensure_sram_operation_address(address, "lac")
            memory_value = self.read_data(address)
            register_value = data[translated.a]
            data[translated.a] = memory_value
            self.write_data(address, (~register_value & 0xFF) & memory_value)
            cycles = 2
        elif kind == _OP_LAS:
            address = self._pointer_data_address("Z")
            self._ensure_sram_operation_address(address, "las")
            memory_value = self.read_data(address)
            register_value = data[translated.a]
            data[translated.a] = memory_value
            self.write_data(address, register_value | memory_value)
            cycles = 2
        elif kind == _OP_LAT:
            address = self._pointer_data_address("Z")
            self._ensure_sram_operation_address(address, "lat")
            memory_value = self.read_data(address)
            register_value = data[translated.a]
            data[translated.a] = memory_value
            self.write_data(address, register_value ^ memory_value)
            cycles = 2
        elif kind == _OP_FALLBACK:
            return self._execute_decoded_instruction_fallback(instruction)
        else:
            return self._execute_decoded_instruction_fallback(instruction)

        self._retire_instruction(instruction, next_pc, cycles)
        if self._should_record_trace_edge(instruction):
            self._record_trace_edge(instruction.address, self.pc)
        return None

    def _execute_decoded_instruction_fallback(self, instruction: DecodedInstruction) -> None:
        operands = instruction.operands
        mnemonic = instruction.mnemonic
        current_pc = self.pc
        next_pc = current_pc + instruction.word_length
        cycles = 0

        if mnemonic == "des":
            raise UnsupportedInstructionError("DES is not implemented in the CPU simulator yet")
        elif mnemonic == "spm":
            raise UnsupportedInstructionError("SPM is not implemented in the CPU simulator yet")
        else:
            raise UnsupportedInstructionError(f"cannot execute unsupported mnemonic {mnemonic}")

    def _retire_instruction(self, instruction: DecodedInstruction, next_pc: int, cycles: int) -> None:
        self.pc = self._normalize_pc(next_pc)
        self.cycles += cycles
        if self.hooks is not None:
            self.hooks.after_step(self, instruction, cycles)
        if self._interrupt_delay_steps > 0:
            self._interrupt_delay_steps -= 1
        return None

    def run(
        self,
        max_instructions: int | None = None,
        *,
        stop_on_break: bool = True,
        stop_on_sleep: bool = True,
    ) -> int:
        executed = 0
        while max_instructions is None or executed < max_instructions:
            if stop_on_break and self.break_hit:
                break
            if stop_on_sleep and self.sleeping:
                break
            remaining = None if max_instructions is None else (max_instructions - executed)
            block_executed = self._execute_basic_block(
                max_instructions=remaining,
                stop_on_break=stop_on_break,
                stop_on_sleep=stop_on_sleep,
            )
            if block_executed <= 0:
                break
            executed += block_executed
        return executed

    def _execute_basic_block(
        self,
        *,
        max_instructions: int | None,
        stop_on_break: bool,
        stop_on_sleep: bool,
    ) -> int:
        if self.sleeping:
            raise CPUError("CPU is sleeping; call wake() before stepping again")
        block = self._basic_block_cache.get(self.pc)
        if block is None:
            block = self._compile_basic_block(self.pc)
            self._basic_block_cache[self.pc] = block
        if self.enable_block_jit:
            if self.enable_trace_cache:
                trace = self._trace_cache.get(self.pc)
                if trace is None or not self._trace_is_current(trace):
                    trace = self._compile_trace(self.pc)
                    self._trace_cache[self.pc] = trace
                    self._compiled_trace_cache.pop(trace.start_address, None)
                compiled_runner = self._compiled_trace_cache.get(trace.start_address)
                if compiled_runner is None:
                    compiled_runner = self._compile_block_runner(trace)
                    self._compiled_trace_cache[trace.start_address] = compiled_runner
                return compiled_runner(self, max_instructions, stop_on_break, stop_on_sleep)
            compiled_runner = self._compiled_block_cache.get(block.start_address)
            if compiled_runner is None:
                compiled_runner = self._compile_block_runner(self._trace_from_basic_block(block))
                self._compiled_block_cache[block.start_address] = compiled_runner
            return compiled_runner(self, max_instructions, stop_on_break, stop_on_sleep)
        limit = len(block.instructions) if max_instructions is None else min(len(block.instructions), max_instructions)
        executed = 0
        for index in range(limit):
            instruction = block.instructions[index]
            translated = block.translated_ops[index]
            if self.pc != instruction.address:
                break
            self._execute_translated_operation(instruction, translated)
            executed += 1
            if stop_on_break and self.break_hit:
                break
            if stop_on_sleep and self.sleeping:
                break
            expected_next_pc = block.expected_next_pcs[index]
            if expected_next_pc is None or self.pc != expected_next_pc:
                break
        return executed

    def _compile_basic_block(self, start_address: int, *, max_length: int = 64) -> TranslatedBasicBlock:
        instructions: list[DecodedInstruction] = []
        translated_ops: list[TranslatedOperation] = []
        expected_next_pcs: list[int | None] = []
        current_address = start_address
        for _ in range(max_length):
            instruction = self.decode_at(current_address)
            instructions.append(instruction)
            translated_ops.append(self._translate_instruction(instruction))
            if self._instruction_has_static_fallthrough(instruction):
                current_address += instruction.word_length
                expected_next_pcs.append(current_address)
                continue
            expected_next_pcs.append(None)
            break
        return TranslatedBasicBlock(
            start_address=start_address,
            instructions=tuple(instructions),
            translated_ops=tuple(translated_ops),
            expected_next_pcs=tuple(expected_next_pcs),
        )

    @staticmethod
    def _trace_from_basic_block(block: TranslatedBasicBlock) -> TranslatedTrace:
        return TranslatedTrace(
            start_address=block.start_address,
            instructions=block.instructions,
            translated_ops=block.translated_ops,
            expected_next_pcs=block.expected_next_pcs,
            hint_versions=(),
            open_hint_addresses=(),
        )

    def _trace_is_current(self, trace: TranslatedTrace) -> bool:
        if not trace.hint_versions and not trace.open_hint_addresses:
            return True
        if not all(self._trace_hint_versions.get(address, 0) == version for address, version in trace.hint_versions):
            return False
        return all(address not in self._trace_preferred_successor for address in trace.open_hint_addresses)

    def _compile_trace(
        self,
        start_address: int,
        *,
        max_instructions: int = 256,
        max_blocks: int = 64,
    ) -> TranslatedTrace:
        instructions: list[DecodedInstruction] = []
        translated_ops: list[TranslatedOperation] = []
        expected_next_pcs: list[int | None] = []
        hint_versions: list[tuple[int, int]] = []
        open_hint_addresses: list[int] = []
        visited_block_starts: set[int] = set()
        current_address = start_address

        for _ in range(max_blocks):
            if current_address in visited_block_starts or len(instructions) >= max_instructions:
                break
            visited_block_starts.add(current_address)
            block = self._basic_block_cache.get(current_address)
            if block is None:
                block = self._compile_basic_block(current_address)
                self._basic_block_cache[current_address] = block

            remaining_slots = max_instructions - len(instructions)
            if remaining_slots <= 0:
                break
            block_limit = min(len(block.instructions), remaining_slots)
            last_successor: int | None = None

            for index in range(block_limit):
                instruction = block.instructions[index]
                translated = block.translated_ops[index]
                instructions.append(instruction)
                translated_ops.append(translated)
                is_last_instruction = index == (len(block.instructions) - 1)
                if not is_last_instruction:
                    successor = block.expected_next_pcs[index]
                    expected_next_pcs.append(successor)
                    last_successor = successor
                    continue

                successor, hint_version = self._select_trace_successor(instruction)
                expected_next_pcs.append(successor)
                last_successor = successor
                if hint_version is not None:
                    hint_versions.append(hint_version)
                elif instruction.mnemonic in _TRACE_DYNAMIC_SUCCESSORS:
                    open_hint_addresses.append(instruction.address)

            if block_limit < len(block.instructions):
                break
            if last_successor is None:
                break
            current_address = last_successor

        return TranslatedTrace(
            start_address=start_address,
            instructions=tuple(instructions),
            translated_ops=tuple(translated_ops),
            expected_next_pcs=tuple(expected_next_pcs),
            hint_versions=tuple(hint_versions),
            open_hint_addresses=tuple(open_hint_addresses),
        )

    def _select_trace_successor(self, instruction: DecodedInstruction) -> tuple[int | None, tuple[int, int] | None]:
        static_successor = self._static_trace_successor(instruction)
        if static_successor is not None:
            return static_successor, None
        preferred = self._trace_preferred_successor.get(instruction.address)
        if preferred is None:
            return None, None
        return preferred, (instruction.address, self._trace_hint_versions.get(instruction.address, 0))

    def _static_trace_successor(self, instruction: DecodedInstruction) -> int | None:
        operands = instruction.operands
        mnemonic = instruction.mnemonic
        if mnemonic == "rjmp":
            return self._normalize_pc(instruction.address + 1 + int(operands["k"]))
        if mnemonic == "rcall":
            return self._normalize_pc(instruction.address + 1 + int(operands["k"]))
        if mnemonic == "jmp":
            return self._normalize_pc(int(operands["k"]))
        if mnemonic == "call":
            return self._normalize_pc(int(operands["k"]))
        return None

    def _compile_block_runner(
        self, trace: TranslatedTrace
    ) -> Callable[["CPU", int | None, bool, bool], int]:
        source_lines = [
            "def run_block(self, max_instructions, stop_on_break, stop_on_sleep):",
            "    data = self.data",
            "    hooks = self.hooks",
            "    executed = 0",
        ]
        for index, instruction in enumerate(trace.instructions):
            translated = trace.translated_ops[index]
            source_lines.append("    if max_instructions is not None and executed >= max_instructions:")
            source_lines.append("        return executed")
            source_lines.append(f"    if self.pc != {instruction.address}:")
            source_lines.append("        return executed")
            compiled_lines = self._compiled_operation_lines(
                instruction_ref=f"instructions[{index}]",
                instruction=instruction,
                translated=translated,
            )
            if compiled_lines is None:
                source_lines.append(
                    f"    self._execute_translated_operation(instructions[{index}], translated_ops[{index}])"
                )
                source_lines.append("    executed += 1")
            else:
                for line in compiled_lines:
                    source_lines.append(f"    {line}")
            source_lines.append("    if stop_on_break and self.break_hit:")
            source_lines.append("        return executed")
            source_lines.append("    if stop_on_sleep and self.sleeping:")
            source_lines.append("        return executed")
            expected_next_pc = trace.expected_next_pcs[index]
            if expected_next_pc is None:
                source_lines.append("    return executed")
            else:
                source_lines.append(f"    if self.pc != {expected_next_pc}:")
                source_lines.append("        return executed")
        source_lines.append("    return executed")
        env = {
            "instructions": trace.instructions,
            "translated_ops": trace.translated_ops,
            "FLAG_C": FLAG_C,
            "FLAG_I": FLAG_I,
            "FLAG_N": FLAG_N,
            "FLAG_S": FLAG_S,
            "FLAG_T": FLAG_T,
            "FLAG_V": FLAG_V,
            "FLAG_Z": FLAG_Z,
            "_bit": _bit,
            "_to_signed8": _to_signed8,
            "_u8": _u8,
        }
        namespace: dict[str, Callable[["CPU", int | None, bool, bool], int]] = {}
        exec("\n".join(source_lines), env, namespace)
        return namespace["run_block"]

    def _compiled_retire_lines(
        self,
        instruction_ref: str,
        next_pc: int | str,
        cycles: int | str,
        *,
        record_edge: bool = False,
    ) -> list[str]:
        next_pc_expr = str(next_pc)
        cycles_expr = str(cycles)
        lines = [
            f"self.pc = self._normalize_pc({next_pc_expr})",
            f"self.cycles += {cycles_expr}",
            "if hooks is not None:",
            f"    hooks.after_step(self, {instruction_ref}, {cycles_expr})",
            "if self._interrupt_delay_steps > 0:",
            "    self._interrupt_delay_steps -= 1",
        ]
        if record_edge:
            lines.append(f"self._record_trace_edge({instruction_ref}.address, self.pc)")
        lines.append("executed += 1")
        return lines

    def _compiled_operation_lines(
        self,
        *,
        instruction_ref: str,
        instruction: DecodedInstruction,
        translated: TranslatedOperation,
    ) -> list[str] | None:
        next_pc = self._normalize_pc(instruction.address + instruction.word_length)
        kind = translated.kind
        if kind == _OP_NOP:
            return self._compiled_retire_lines(instruction_ref, next_pc, 1)
        if kind == _OP_BREAK:
            return [
                "self.break_hit = True",
                *self._compiled_retire_lines(instruction_ref, next_pc, 1),
            ]
        if kind == _OP_SLEEP:
            return [
                "self.sleeping = True",
                *self._compiled_retire_lines(instruction_ref, next_pc, 1),
            ]
        if kind == _OP_WDR:
            return self._compiled_retire_lines(instruction_ref, next_pc, 1)
        if kind == _OP_MOV:
            return [
                f"data[{translated.a}] = data[{translated.b}]",
                *self._compiled_retire_lines(instruction_ref, next_pc, 1),
            ]
        if kind == _OP_MOVW:
            return [
                f"data[{translated.a}] = data[{translated.b}]",
                f"data[{translated.a + 1}] = data[{translated.b + 1}]",
                *self._compiled_retire_lines(instruction_ref, next_pc, 1),
            ]
        if kind == _OP_LDI:
            return [
                f"data[{translated.a}] = {translated.b & 0xFF}",
                *self._compiled_retire_lines(instruction_ref, next_pc, 1),
            ]
        if kind in {_OP_ADD, _OP_ADC}:
            carry_in = "self.get_flag(FLAG_C)" if kind == _OP_ADC else "0"
            return [
                f"result = self._add8(data[{translated.a}], data[{translated.b}], {carry_in})",
                f"data[{translated.a}] = result",
                *self._compiled_retire_lines(instruction_ref, next_pc, 1),
            ]
        if kind in {_OP_SUB, _OP_SBC, _OP_CP, _OP_CPC}:
            carry_in = "self.get_flag(FLAG_C)" if kind in {_OP_SBC, _OP_CPC} else "0"
            previous_z = "self.get_flag(FLAG_Z)" if kind in {_OP_SBC, _OP_CPC} else "None"
            lines = [
                f"result = self._sub8(data[{translated.a}], data[{translated.b}], {carry_in}, {previous_z})",
            ]
            if kind in {_OP_SUB, _OP_SBC}:
                lines.append(f"data[{translated.a}] = result")
            lines.extend(self._compiled_retire_lines(instruction_ref, next_pc, 1))
            return lines
        if kind in {_OP_SUBI, _OP_SBCI, _OP_CPI}:
            carry_in = "self.get_flag(FLAG_C)" if kind == _OP_SBCI else "0"
            previous_z = "self.get_flag(FLAG_Z)" if kind == _OP_SBCI else "None"
            lines = [
                f"result = self._sub8(data[{translated.a}], {translated.b}, {carry_in}, {previous_z})",
            ]
            if kind != _OP_CPI:
                lines.append(f"data[{translated.a}] = result")
            lines.extend(self._compiled_retire_lines(instruction_ref, next_pc, 1))
            return lines
        if kind == _OP_ADIW:
            return [
                f"value = data[{translated.a}] | (data[{translated.a + 1}] << 8)",
                f"result = (value + {translated.b}) & 0xFFFF",
                f"data[{translated.a}] = result & 0xFF",
                f"data[{translated.a + 1}] = (result >> 8) & 0xFF",
                "self._set_adiw_flags(value, result)",
                *self._compiled_retire_lines(instruction_ref, next_pc, 2),
            ]
        if kind == _OP_SBIW:
            return [
                f"value = data[{translated.a}] | (data[{translated.a + 1}] << 8)",
                f"result = (value - {translated.b}) & 0xFFFF",
                f"data[{translated.a}] = result & 0xFF",
                f"data[{translated.a + 1}] = (result >> 8) & 0xFF",
                "self._set_sbiw_flags(value, result)",
                *self._compiled_retire_lines(instruction_ref, next_pc, 2),
            ]
        if kind in {_OP_AND, _OP_OR, _OP_EOR}:
            operator = { _OP_AND: "&", _OP_OR: "|", _OP_EOR: "^" }[kind]
            return [
                f"result = data[{translated.a}] {operator} data[{translated.b}]",
                f"data[{translated.a}] = result",
                "self._set_logic_flags(result)",
                *self._compiled_retire_lines(instruction_ref, next_pc, 1),
            ]
        if kind in {_OP_ANDI, _OP_ORI}:
            operator = "&" if kind == _OP_ANDI else "|"
            return [
                f"result = data[{translated.a}] {operator} {translated.b}",
                f"data[{translated.a}] = result",
                "self._set_logic_flags(result)",
                *self._compiled_retire_lines(instruction_ref, next_pc, 1),
            ]
        if kind == _OP_COM:
            return [
                f"result = _u8(0xFF - data[{translated.a}])",
                f"data[{translated.a}] = result",
                "self.set_flag(FLAG_V, 0)",
                "self.set_flag(FLAG_C, 1)",
                "self._set_nzs_from_result(result)",
                *self._compiled_retire_lines(instruction_ref, next_pc, 1),
            ]
        if kind == _OP_NEG:
            return [
                f"original = data[{translated.a}]",
                "result = _u8(-original)",
                f"data[{translated.a}] = result",
                "self._set_neg_flags(result, original)",
                *self._compiled_retire_lines(instruction_ref, next_pc, 1),
            ]
        if kind in {_OP_INC, _OP_DEC}:
            delta = 1 if kind == _OP_INC else -1
            overflow_value = 0x80 if kind == _OP_INC else 0x7F
            return [
                f"value = data[{translated.a}]",
                f"result = _u8(value + ({delta}))",
                f"data[{translated.a}] = result",
                f"self.set_flag(FLAG_V, 1 if result == {overflow_value} else 0)",
                "self._set_nzs_from_result(result)",
                *self._compiled_retire_lines(instruction_ref, next_pc, 1),
            ]
        if kind == _OP_SWAP:
            return [
                f"value = data[{translated.a}]",
                f"data[{translated.a}] = ((value & 0x0F) << 4) | ((value >> 4) & 0x0F)",
                *self._compiled_retire_lines(instruction_ref, next_pc, 1),
            ]
        if kind == _OP_ASR:
            return [
                f"value = data[{translated.a}]",
                "carry = value & 0x01",
                "result = (value >> 1) | (value & 0x80)",
                f"data[{translated.a}] = result",
                "self.set_flag(FLAG_C, carry)",
                "self.set_flag(FLAG_N, 1 if (result & 0x80) else 0)",
                "self.set_flag(FLAG_V, self.get_flag(FLAG_N) ^ self.get_flag(FLAG_C))",
                "self.set_flag(FLAG_S, self.get_flag(FLAG_N) ^ self.get_flag(FLAG_V))",
                "self.set_flag(FLAG_Z, 1 if result == 0 else 0)",
                *self._compiled_retire_lines(instruction_ref, next_pc, 1),
            ]
        if kind == _OP_LSR:
            return [
                f"value = data[{translated.a}]",
                "carry = value & 0x01",
                "result = value >> 1",
                f"data[{translated.a}] = result",
                "self.set_flag(FLAG_C, carry)",
                "self.set_flag(FLAG_N, 0)",
                "self.set_flag(FLAG_V, self.get_flag(FLAG_N) ^ self.get_flag(FLAG_C))",
                "self.set_flag(FLAG_S, self.get_flag(FLAG_N) ^ self.get_flag(FLAG_V))",
                "self.set_flag(FLAG_Z, 1 if result == 0 else 0)",
                *self._compiled_retire_lines(instruction_ref, next_pc, 1),
            ]
        if kind == _OP_ROR:
            return [
                f"value = data[{translated.a}]",
                "carry_in = self.get_flag(FLAG_C)",
                "carry_out = value & 0x01",
                "result = ((carry_in << 7) | (value >> 1)) & 0xFF",
                f"data[{translated.a}] = result",
                "self.set_flag(FLAG_C, carry_out)",
                "self.set_flag(FLAG_N, 1 if (result & 0x80) else 0)",
                "self.set_flag(FLAG_V, self.get_flag(FLAG_N) ^ self.get_flag(FLAG_C))",
                "self.set_flag(FLAG_S, self.get_flag(FLAG_N) ^ self.get_flag(FLAG_V))",
                "self.set_flag(FLAG_Z, 1 if result == 0 else 0)",
                *self._compiled_retire_lines(instruction_ref, next_pc, 1),
            ]
        if kind == _OP_MUL:
            return [
                f"self._write_product(data[{translated.a}] * data[{translated.b}])",
                *self._compiled_retire_lines(instruction_ref, next_pc, 2),
            ]
        if kind == _OP_MULS:
            return [
                f"self._write_product(_to_signed8(data[{translated.a}]) * _to_signed8(data[{translated.b}]))",
                *self._compiled_retire_lines(instruction_ref, next_pc, 2),
            ]
        if kind == _OP_MULSU:
            return [
                f"self._write_product(_to_signed8(data[{translated.a}]) * data[{translated.b}])",
                *self._compiled_retire_lines(instruction_ref, next_pc, 2),
            ]
        if kind == _OP_FMUL:
            return [
                f"self._write_fractional_product(data[{translated.a}] * data[{translated.b}])",
                *self._compiled_retire_lines(instruction_ref, next_pc, 2),
            ]
        if kind == _OP_FMULS:
            return [
                f"self._write_fractional_product(_to_signed8(data[{translated.a}]) * _to_signed8(data[{translated.b}]))",
                *self._compiled_retire_lines(instruction_ref, next_pc, 2),
            ]
        if kind == _OP_FMULSU:
            return [
                f"self._write_fractional_product(_to_signed8(data[{translated.a}]) * data[{translated.b}])",
                *self._compiled_retire_lines(instruction_ref, next_pc, 2),
            ]
        if kind == _OP_RJMP:
            return self._compiled_retire_lines(
                instruction_ref,
                self._normalize_pc(instruction.address + 1 + translated.a),
                2,
            )
        if kind == _OP_RCALL:
            return [
                f"self._push_pc({instruction.address + 1})",
                *self._compiled_retire_lines(
                    instruction_ref,
                    self._normalize_pc(instruction.address + 1 + translated.a),
                    4 if self.config.return_address_bytes == 3 else 3,
                ),
            ]
        if kind == _OP_JMP:
            return self._compiled_retire_lines(
                instruction_ref,
                self._normalize_pc(translated.a),
                3,
            )
        if kind == _OP_CALL:
            return [
                f"self._push_pc({instruction.address + 2})",
                *self._compiled_retire_lines(
                    instruction_ref,
                    self._normalize_pc(translated.a),
                    5 if self.config.return_address_bytes == 3 else 4,
                ),
            ]
        if kind == _OP_IJMP:
            return [
                "next_pc = self._pointer_word_address('Z', None)",
                *self._compiled_retire_lines(instruction_ref, "next_pc", 2, record_edge=True),
            ]
        if kind == _OP_EIJMP:
            return [
                "next_pc = self._pointer_word_address('Z', self.config.eind_address)",
                *self._compiled_retire_lines(instruction_ref, "next_pc", 2, record_edge=True),
            ]
        if kind == _OP_ICALL:
            return [
                f"self._push_pc({instruction.address + 1})",
                "next_pc = self._pointer_word_address('Z', None)",
                *self._compiled_retire_lines(
                    instruction_ref,
                    "next_pc",
                    4 if self.config.return_address_bytes == 3 else 3,
                    record_edge=True,
                ),
            ]
        if kind == _OP_EICALL:
            return [
                "self._ensure_extended_pc()",
                f"self._push_pc({instruction.address + 1})",
                "next_pc = self._pointer_word_address('Z', self.config.eind_address)",
                *self._compiled_retire_lines(instruction_ref, "next_pc", 4, record_edge=True),
            ]
        if kind == _OP_RET:
            return [
                "next_pc = self._pop_pc()",
                *self._compiled_retire_lines(
                    instruction_ref,
                    "next_pc",
                    5 if self.config.return_address_bytes == 3 else 4,
                    record_edge=True,
                ),
            ]
        if kind == _OP_RETI:
            return [
                "next_pc = self._pop_pc()",
                "self.set_flag(FLAG_I, 1)",
                "if self._interrupt_delay_steps < 1:",
                "    self._interrupt_delay_steps = 1",
                *self._compiled_retire_lines(
                    instruction_ref,
                    "next_pc",
                    5 if self.config.return_address_bytes == 3 else 4,
                    record_edge=True,
                ),
            ]
        if kind == _OP_BRBS:
            branch_target = self._normalize_pc(instruction.address + 1 + translated.b)
            return [
                f"next_pc = {branch_target} if self.get_flag({translated.a}) else {next_pc}",
                f"cycles = 2 if next_pc == {branch_target} else 1",
                *self._compiled_retire_lines(instruction_ref, "next_pc", "cycles", record_edge=True),
            ]
        if kind == _OP_BRBC:
            branch_target = self._normalize_pc(instruction.address + 1 + translated.b)
            return [
                f"next_pc = {branch_target} if not self.get_flag({translated.a}) else {next_pc}",
                f"cycles = 2 if next_pc == {branch_target} else 1",
                *self._compiled_retire_lines(instruction_ref, "next_pc", "cycles", record_edge=True),
            ]
        if kind == _OP_BSET:
            lines = [f"self.set_flag({translated.a}, 1)"]
            if translated.a == FLAG_I:
                lines.extend(
                    [
                        "if self._interrupt_delay_steps < 1:",
                        "    self._interrupt_delay_steps = 1",
                    ]
                )
            lines.extend(self._compiled_retire_lines(instruction_ref, next_pc, 1))
            return lines
        if kind == _OP_BCLR:
            return [
                f"self.set_flag({translated.a}, 0)",
                *self._compiled_retire_lines(instruction_ref, next_pc, 1),
            ]
        if kind == _OP_BLD:
            return [
                f"value = data[{translated.a}]",
                f"mask = {1 << translated.b}",
                "if self.get_flag(FLAG_T):",
                "    value |= mask",
                "else:",
                "    value &= ~mask & 0xFF",
                f"data[{translated.a}] = value",
                *self._compiled_retire_lines(instruction_ref, next_pc, 1),
            ]
        if kind == _OP_BST:
            return [
                f"self.set_flag(FLAG_T, 1 if (data[{translated.a}] & {1 << translated.b}) else 0)",
                *self._compiled_retire_lines(instruction_ref, next_pc, 1),
            ]
        if kind == _OP_CPSE:
            skip_length = self.decode_at(instruction.address + 1).word_length
            skip_target = self._normalize_pc(instruction.address + 1 + skip_length)
            return [
                f"next_pc = {skip_target} if data[{translated.a}] == data[{translated.b}] else {next_pc}",
                f"cycles = {1 + skip_length} if next_pc == {skip_target} else 1",
                *self._compiled_retire_lines(instruction_ref, "next_pc", "cycles", record_edge=True),
            ]
        if kind == _OP_IN:
            return [
                f"data[{translated.a}] = self.read_io({translated.b})",
                *self._compiled_retire_lines(instruction_ref, next_pc, 1),
            ]
        if kind == _OP_OUT:
            return [
                f"self.write_io({translated.b}, data[{translated.a}])",
                *self._compiled_retire_lines(instruction_ref, next_pc, 1),
            ]
        if kind == _OP_CBI:
            return [
                f"bit_mask = {1 << translated.b}",
                f"self.write_io({translated.a}, self.read_io({translated.a}) & (~bit_mask & 0xFF))",
                *self._compiled_retire_lines(instruction_ref, next_pc, 2),
            ]
        if kind == _OP_SBI:
            return [
                f"bit_mask = {1 << translated.b}",
                f"self.write_io({translated.a}, self.read_io({translated.a}) | bit_mask)",
                *self._compiled_retire_lines(instruction_ref, next_pc, 2),
            ]
        if kind == _OP_SBIC:
            skip_length = self.decode_at(instruction.address + 1).word_length
            skip_target = self._normalize_pc(instruction.address + 1 + skip_length)
            bit_mask = 1 << translated.b
            return [
                f"next_pc = {skip_target} if (self.read_io({translated.a}) & {bit_mask}) == 0 else {next_pc}",
                f"cycles = {1 + skip_length} if next_pc == {skip_target} else 1",
                *self._compiled_retire_lines(instruction_ref, "next_pc", "cycles", record_edge=True),
            ]
        if kind == _OP_SBIS:
            skip_length = self.decode_at(instruction.address + 1).word_length
            skip_target = self._normalize_pc(instruction.address + 1 + skip_length)
            bit_mask = 1 << translated.b
            return [
                f"next_pc = {skip_target} if (self.read_io({translated.a}) & {bit_mask}) != 0 else {next_pc}",
                f"cycles = {1 + skip_length} if next_pc == {skip_target} else 1",
                *self._compiled_retire_lines(instruction_ref, "next_pc", "cycles", record_edge=True),
            ]
        if kind == _OP_PUSH:
            return [
                f"self.push_byte(data[{translated.a}])",
                *self._compiled_retire_lines(instruction_ref, next_pc, 2),
            ]
        if kind == _OP_POP:
            return [
                f"data[{translated.a}] = self.pop_byte()",
                *self._compiled_retire_lines(instruction_ref, next_pc, 2),
            ]
        if kind == _OP_LDS:
            return [
                f"data[{translated.a}] = self.read_data(self._direct_data_address({translated.b}))",
                *self._compiled_retire_lines(instruction_ref, next_pc, 2),
            ]
        if kind == _OP_STS:
            return [
                f"self.write_data(self._direct_data_address({translated.b}), data[{translated.a}])",
                *self._compiled_retire_lines(instruction_ref, next_pc, 2),
            ]
        if kind == _OP_LD_PTR:
            pointer = self._decode_pointer(translated.b)
            mode = self._decode_mode(translated.c)
            return [
                f"data[{translated.a}] = self._read_pointer_mode({pointer!r}, {mode!r})",
                *self._compiled_retire_lines(instruction_ref, next_pc, 2),
            ]
        if kind == _OP_ST_PTR:
            pointer = self._decode_pointer(translated.b)
            mode = self._decode_mode(translated.c)
            return [
                f"self._write_pointer_mode({pointer!r}, {mode!r}, data[{translated.a}])",
                *self._compiled_retire_lines(instruction_ref, next_pc, 2),
            ]
        if kind == _OP_LD_DISP:
            pointer = self._decode_pointer(translated.b)
            return [
                f"address = self._pointer_data_address({pointer!r}) + {translated.c}",
                f"data[{translated.a}] = self.read_data(address)",
                *self._compiled_retire_lines(instruction_ref, next_pc, 2),
            ]
        if kind == _OP_ST_DISP:
            pointer = self._decode_pointer(translated.b)
            return [
                f"address = self._pointer_data_address({pointer!r}) + {translated.c}",
                f"self.write_data(address, data[{translated.a}])",
                *self._compiled_retire_lines(instruction_ref, next_pc, 2),
            ]
        if kind == _OP_LPM:
            post_increment = (translated.flags & 0x01) != 0
            extended = (translated.flags & 0x02) != 0
            lines = [
                f"byte_address = self._program_pointer_byte_address({extended})",
                f"data[{translated.a}] = self.read_program_byte(byte_address)",
            ]
            if post_increment:
                lines.append(f"self._increment_program_pointer({extended})")
            lines.extend(self._compiled_retire_lines(instruction_ref, next_pc, 3))
            return lines
        if kind == _OP_XCH:
            return [
                "address = self._pointer_data_address('Z')",
                "self._ensure_sram_operation_address(address, 'xch')",
                "memory_value = self.read_data(address)",
                f"register_value = data[{translated.a}]",
                "self.write_data(address, register_value)",
                f"data[{translated.a}] = memory_value",
                *self._compiled_retire_lines(instruction_ref, next_pc, 2),
            ]
        if kind == _OP_LAC:
            return [
                "address = self._pointer_data_address('Z')",
                "self._ensure_sram_operation_address(address, 'lac')",
                "memory_value = self.read_data(address)",
                f"register_value = data[{translated.a}]",
                f"data[{translated.a}] = memory_value",
                "self.write_data(address, (~register_value & 0xFF) & memory_value)",
                *self._compiled_retire_lines(instruction_ref, next_pc, 2),
            ]
        if kind == _OP_LAS:
            return [
                "address = self._pointer_data_address('Z')",
                "self._ensure_sram_operation_address(address, 'las')",
                "memory_value = self.read_data(address)",
                f"register_value = data[{translated.a}]",
                f"data[{translated.a}] = memory_value",
                "self.write_data(address, register_value | memory_value)",
                *self._compiled_retire_lines(instruction_ref, next_pc, 2),
            ]
        if kind == _OP_LAT:
            return [
                "address = self._pointer_data_address('Z')",
                "self._ensure_sram_operation_address(address, 'lat')",
                "memory_value = self.read_data(address)",
                f"register_value = data[{translated.a}]",
                f"data[{translated.a}] = memory_value",
                "self.write_data(address, register_value ^ memory_value)",
                *self._compiled_retire_lines(instruction_ref, next_pc, 2),
            ]
        if kind == _OP_SBRC:
            skip_length = self.decode_at(instruction.address + 1).word_length
            skip_target = self._normalize_pc(instruction.address + 1 + skip_length)
            bit_mask = 1 << translated.b
            return [
                f"next_pc = {skip_target} if (data[{translated.a}] & {bit_mask}) == 0 else {next_pc}",
                f"cycles = {1 + skip_length} if next_pc == {skip_target} else 1",
                *self._compiled_retire_lines(instruction_ref, "next_pc", "cycles", record_edge=True),
            ]
        if kind == _OP_SBRS:
            skip_length = self.decode_at(instruction.address + 1).word_length
            skip_target = self._normalize_pc(instruction.address + 1 + skip_length)
            bit_mask = 1 << translated.b
            return [
                f"next_pc = {skip_target} if (data[{translated.a}] & {bit_mask}) != 0 else {next_pc}",
                f"cycles = {1 + skip_length} if next_pc == {skip_target} else 1",
                *self._compiled_retire_lines(instruction_ref, "next_pc", "cycles", record_edge=True),
            ]
        return None

    def _invalidate_translation_caches(self) -> None:
        self._decode_cache.clear()
        self._basic_block_cache.clear()
        self._trace_cache.clear()
        self._compiled_block_cache.clear()
        self._compiled_trace_cache.clear()
        self._trace_edge_counts.clear()
        self._trace_preferred_successor.clear()
        self._trace_hint_versions.clear()
        self._trace_stable_hits.clear()

    @staticmethod
    def _should_record_trace_edge(instruction: DecodedInstruction) -> bool:
        return instruction.mnemonic in _TRACE_DYNAMIC_SUCCESSORS

    def _record_trace_edge(self, instruction_address: int, next_pc: int) -> None:
        preferred = self._trace_preferred_successor.get(instruction_address)
        if preferred == next_pc:
            stable_hits = self._trace_stable_hits.get(instruction_address, 0) + 1
            self._trace_stable_hits[instruction_address] = stable_hits
            if stable_hits >= 8:
                return
        else:
            self._trace_stable_hits[instruction_address] = 0
        edge_counts = self._trace_edge_counts.setdefault(instruction_address, {})
        edge_counts[next_pc] = edge_counts.get(next_pc, 0) + 1
        if preferred is None:
            best_next_pc = next_pc
        else:
            best_next_pc = preferred
            next_count = edge_counts[next_pc]
            preferred_count = edge_counts.get(preferred, 0)
            if next_count > preferred_count or (next_count == preferred_count and next_pc < preferred):
                best_next_pc = next_pc
        if preferred != best_next_pc:
            self._trace_preferred_successor[instruction_address] = best_next_pc
            self._trace_hint_versions[instruction_address] = self._trace_hint_versions.get(instruction_address, 0) + 1
            self._trace_stable_hits[instruction_address] = 0

    @staticmethod
    def _instruction_has_static_fallthrough(instruction: DecodedInstruction) -> bool:
        return instruction.mnemonic not in {
            "break",
            "sleep",
            "cpse",
            "rjmp",
            "rcall",
            "jmp",
            "call",
            "ijmp",
            "eijmp",
            "icall",
            "eicall",
            "ret",
            "reti",
            "brbs",
            "brbc",
            "sbrc",
            "sbrs",
            "sbic",
            "sbis",
            "des",
            "spm",
        }

    def _translate_instruction(self, instruction: DecodedInstruction) -> TranslatedOperation:
        operands = instruction.operands
        mnemonic = instruction.mnemonic
        if mnemonic == "nop":
            return TranslatedOperation(_OP_NOP)
        if mnemonic == "break":
            return TranslatedOperation(_OP_BREAK)
        if mnemonic == "sleep":
            return TranslatedOperation(_OP_SLEEP)
        if mnemonic == "wdr":
            return TranslatedOperation(_OP_WDR)
        if mnemonic == "mov":
            return TranslatedOperation(_OP_MOV, int(operands["d"]), int(operands["r"]))
        if mnemonic == "movw":
            return TranslatedOperation(_OP_MOVW, int(operands["d"]), int(operands["r"]))
        if mnemonic == "ldi":
            return TranslatedOperation(_OP_LDI, int(operands["d"]), int(operands["k"]))
        if mnemonic == "add":
            return TranslatedOperation(_OP_ADD, int(operands["d"]), int(operands["r"]))
        if mnemonic == "adc":
            return TranslatedOperation(_OP_ADC, int(operands["d"]), int(operands["r"]))
        if mnemonic == "sub":
            return TranslatedOperation(_OP_SUB, int(operands["d"]), int(operands["r"]))
        if mnemonic == "sbc":
            return TranslatedOperation(_OP_SBC, int(operands["d"]), int(operands["r"]))
        if mnemonic == "cp":
            return TranslatedOperation(_OP_CP, int(operands["d"]), int(operands["r"]))
        if mnemonic == "cpc":
            return TranslatedOperation(_OP_CPC, int(operands["d"]), int(operands["r"]))
        if mnemonic == "subi":
            return TranslatedOperation(_OP_SUBI, int(operands["d"]), int(operands["k"]))
        if mnemonic == "sbci":
            return TranslatedOperation(_OP_SBCI, int(operands["d"]), int(operands["k"]))
        if mnemonic == "cpi":
            return TranslatedOperation(_OP_CPI, int(operands["d"]), int(operands["k"]))
        if mnemonic == "cpse":
            return TranslatedOperation(_OP_CPSE, int(operands["d"]), int(operands["r"]))
        if mnemonic == "adiw":
            return TranslatedOperation(_OP_ADIW, int(operands["d"]), int(operands["k"]))
        if mnemonic == "sbiw":
            return TranslatedOperation(_OP_SBIW, int(operands["d"]), int(operands["k"]))
        if mnemonic == "and":
            return TranslatedOperation(_OP_AND, int(operands["d"]), int(operands["r"]))
        if mnemonic == "andi":
            return TranslatedOperation(_OP_ANDI, int(operands["d"]), int(operands["k"]))
        if mnemonic == "or":
            return TranslatedOperation(_OP_OR, int(operands["d"]), int(operands["r"]))
        if mnemonic == "ori":
            return TranslatedOperation(_OP_ORI, int(operands["d"]), int(operands["k"]))
        if mnemonic == "eor":
            return TranslatedOperation(_OP_EOR, int(operands["d"]), int(operands["r"]))
        if mnemonic == "com":
            return TranslatedOperation(_OP_COM, int(operands["d"]))
        if mnemonic == "neg":
            return TranslatedOperation(_OP_NEG, int(operands["d"]))
        if mnemonic == "inc":
            return TranslatedOperation(_OP_INC, int(operands["d"]))
        if mnemonic == "dec":
            return TranslatedOperation(_OP_DEC, int(operands["d"]))
        if mnemonic == "swap":
            return TranslatedOperation(_OP_SWAP, int(operands["d"]))
        if mnemonic == "asr":
            return TranslatedOperation(_OP_ASR, int(operands["d"]))
        if mnemonic == "lsr":
            return TranslatedOperation(_OP_LSR, int(operands["d"]))
        if mnemonic == "ror":
            return TranslatedOperation(_OP_ROR, int(operands["d"]))
        if mnemonic == "mul":
            return TranslatedOperation(_OP_MUL, int(operands["d"]), int(operands["r"]))
        if mnemonic == "muls":
            return TranslatedOperation(_OP_MULS, int(operands["d"]), int(operands["r"]))
        if mnemonic == "mulsu":
            return TranslatedOperation(_OP_MULSU, int(operands["d"]), int(operands["r"]))
        if mnemonic == "fmul":
            return TranslatedOperation(_OP_FMUL, int(operands["d"]), int(operands["r"]))
        if mnemonic == "fmuls":
            return TranslatedOperation(_OP_FMULS, int(operands["d"]), int(operands["r"]))
        if mnemonic == "fmulsu":
            return TranslatedOperation(_OP_FMULSU, int(operands["d"]), int(operands["r"]))
        if mnemonic == "rjmp":
            return TranslatedOperation(_OP_RJMP, int(operands["k"]))
        if mnemonic == "rcall":
            return TranslatedOperation(_OP_RCALL, int(operands["k"]))
        if mnemonic == "jmp":
            return TranslatedOperation(_OP_JMP, int(operands["k"]))
        if mnemonic == "call":
            return TranslatedOperation(_OP_CALL, int(operands["k"]))
        if mnemonic == "ijmp":
            return TranslatedOperation(_OP_IJMP)
        if mnemonic == "eijmp":
            return TranslatedOperation(_OP_EIJMP)
        if mnemonic == "icall":
            return TranslatedOperation(_OP_ICALL)
        if mnemonic == "eicall":
            return TranslatedOperation(_OP_EICALL)
        if mnemonic == "ret":
            return TranslatedOperation(_OP_RET)
        if mnemonic == "reti":
            return TranslatedOperation(_OP_RETI)
        if mnemonic == "brbs":
            return TranslatedOperation(_OP_BRBS, int(operands["s"]), int(operands["k"]))
        if mnemonic == "brbc":
            return TranslatedOperation(_OP_BRBC, int(operands["s"]), int(operands["k"]))
        if mnemonic == "bset":
            return TranslatedOperation(_OP_BSET, int(operands["s"]))
        if mnemonic == "bclr":
            return TranslatedOperation(_OP_BCLR, int(operands["s"]))
        if mnemonic == "bld":
            return TranslatedOperation(_OP_BLD, int(operands["d"]), int(operands["b"]))
        if mnemonic == "bst":
            return TranslatedOperation(_OP_BST, int(operands["d"]), int(operands["b"]))
        if mnemonic == "sbrc":
            return TranslatedOperation(_OP_SBRC, int(operands["r"]), int(operands["b"]))
        if mnemonic == "sbrs":
            return TranslatedOperation(_OP_SBRS, int(operands["r"]), int(operands["b"]))
        if mnemonic == "in":
            return TranslatedOperation(_OP_IN, int(operands["d"]), int(operands["a"]))
        if mnemonic == "out":
            return TranslatedOperation(_OP_OUT, int(operands["r"]), int(operands["a"]))
        if mnemonic == "cbi":
            return TranslatedOperation(_OP_CBI, int(operands["a"]), int(operands["b"]))
        if mnemonic == "sbi":
            return TranslatedOperation(_OP_SBI, int(operands["a"]), int(operands["b"]))
        if mnemonic == "sbic":
            return TranslatedOperation(_OP_SBIC, int(operands["a"]), int(operands["b"]))
        if mnemonic == "sbis":
            return TranslatedOperation(_OP_SBIS, int(operands["a"]), int(operands["b"]))
        if mnemonic == "push":
            return TranslatedOperation(_OP_PUSH, int(operands["r"]))
        if mnemonic == "pop":
            return TranslatedOperation(_OP_POP, int(operands["d"]))
        if mnemonic == "lds":
            return TranslatedOperation(_OP_LDS, int(operands["d"]), int(operands["k"]))
        if mnemonic == "sts":
            return TranslatedOperation(_OP_STS, int(operands["r"]), int(operands["k"]))
        if mnemonic == "ld_ptr":
            return TranslatedOperation(
                _OP_LD_PTR,
                int(operands["d"]),
                self._encode_pointer(str(operands["pointer"])),
                self._encode_mode(str(operands["mode"])),
            )
        if mnemonic == "st_ptr":
            return TranslatedOperation(
                _OP_ST_PTR,
                int(operands["r"]),
                self._encode_pointer(str(operands["pointer"])),
                self._encode_mode(str(operands["mode"])),
            )
        if mnemonic == "ld_disp":
            return TranslatedOperation(
                _OP_LD_DISP,
                int(operands["d"]),
                self._encode_pointer(str(operands["pointer"])),
                int(operands["q"]),
            )
        if mnemonic == "st_disp":
            return TranslatedOperation(
                _OP_ST_DISP,
                int(operands["r"]),
                self._encode_pointer(str(operands["pointer"])),
                int(operands["q"]),
            )
        if mnemonic == "lpm":
            flags = 0
            if bool(operands["post_increment"]):
                flags |= 0x01
            if bool(operands["extended"]):
                flags |= 0x02
            return TranslatedOperation(_OP_LPM, int(operands["d"]), flags=flags)
        if mnemonic == "xch":
            return TranslatedOperation(_OP_XCH, int(operands["d"]))
        if mnemonic == "lac":
            return TranslatedOperation(_OP_LAC, int(operands["d"]))
        if mnemonic == "las":
            return TranslatedOperation(_OP_LAS, int(operands["d"]))
        if mnemonic == "lat":
            return TranslatedOperation(_OP_LAT, int(operands["d"]))
        return TranslatedOperation(_OP_FALLBACK)

    @staticmethod
    def _encode_pointer(pointer: str) -> int:
        return {"X": _PTR_X, "Y": _PTR_Y, "Z": _PTR_Z}[pointer]

    @staticmethod
    def _decode_pointer(pointer_code: int) -> str:
        return ("X", "Y", "Z")[pointer_code]

    @staticmethod
    def _encode_mode(mode: str) -> int:
        return {"direct": _MODE_DIRECT, "postinc": _MODE_POSTINC, "predec": _MODE_PREDEC}[mode]

    @staticmethod
    def _decode_mode(mode_code: int) -> str:
        return ("direct", "postinc", "predec")[mode_code]

    def _cache_decoded_instruction(self, address: int, instruction: DecodedInstruction) -> DecodedInstruction:
        self._decode_cache[address] = instruction
        return instruction

    def get_flag(self, bit_index: int) -> int:
        if bit_index < 0 or bit_index > 7:
            raise ValueError("SREG bit index must be between 0 and 7")
        return (self.sreg >> bit_index) & 0x01

    def set_flag(self, bit_index: int, value: int) -> None:
        if bit_index < 0 or bit_index > 7:
            raise ValueError("SREG bit index must be between 0 and 7")
        mask = 1 << bit_index
        if value:
            self.sreg = self.sreg | mask
        else:
            self.sreg = self.sreg & (~mask & 0xFF)

    def push_byte(self, value: int) -> None:
        address = self.sp
        self._ensure_stack_address(address)
        self.write_data(address, value)
        self.sp = address - 1

    def pop_byte(self) -> int:
        address = self.sp + 1
        self._ensure_stack_address(address)
        self.sp = address
        return self.read_data(address)

    def _push_pc(self, value: int) -> None:
        for shift in range((self.config.return_address_bytes - 1) * 8, -1, -8):
            self.push_byte((value >> shift) & 0xFF)

    def _pop_pc(self) -> int:
        value = 0
        for shift in range(0, self.config.return_address_bytes * 8, 8):
            value |= self.pop_byte() << shift
        return value

    def _pointer_data_address(self, pointer: str) -> int:
        low_reg, high_reg = _POINTER_REGISTERS[pointer]
        base = self.read_register(low_reg) | (self.read_register(high_reg) << 8)
        ramp_address = {
            "X": self.config.rampx_address,
            "Y": self.config.rampy_address,
            "Z": self.config.rampz_address,
        }[pointer]
        if ramp_address is not None:
            base |= self.read_data(ramp_address) << 16
        return base

    def _write_pointer_data_address(self, pointer: str, value: int) -> None:
        low_reg, high_reg = _POINTER_REGISTERS[pointer]
        value &= 0xFFFFFF
        self.write_register(low_reg, value & 0xFF)
        self.write_register(high_reg, (value >> 8) & 0xFF)
        ramp_address = {
            "X": self.config.rampx_address,
            "Y": self.config.rampy_address,
            "Z": self.config.rampz_address,
        }[pointer]
        if ramp_address is not None:
            self.write_data(ramp_address, (value >> 16) & 0xFF)

    def _pointer_word_address(self, pointer: str, upper_address: int | None) -> int:
        low_reg, high_reg = _POINTER_REGISTERS[pointer]
        value = self.read_register(low_reg) | (self.read_register(high_reg) << 8)
        if upper_address is not None:
            value |= self.read_data(upper_address) << 16
        return self._normalize_pc(value)

    def _program_pointer_byte_address(self, extended: bool) -> int:
        byte_address = self.read_register(30) | (self.read_register(31) << 8)
        if extended and self.config.rampz_address is not None:
            byte_address |= self.read_data(self.config.rampz_address) << 16
        return byte_address

    def _increment_program_pointer(self, extended: bool) -> None:
        address = (self._program_pointer_byte_address(extended) + 1) & 0xFFFFFF
        self.write_register(30, address & 0xFF)
        self.write_register(31, (address >> 8) & 0xFF)
        if extended and self.config.rampz_address is not None:
            self.write_data(self.config.rampz_address, (address >> 16) & 0xFF)

    def _direct_data_address(self, low_word_address: int) -> int:
        address = low_word_address & 0xFFFF
        if self.config.rampd_address is not None:
            address |= self.read_data(self.config.rampd_address) << 16
        return address

    def _read_pointer_mode(self, pointer: str, mode: str) -> int:
        address = self._pointer_data_address(pointer)
        if mode == "predec":
            address = (address - 1) & 0xFFFFFF
            self._write_pointer_data_address(pointer, address)
        value = self.read_data(address)
        if mode == "postinc":
            self._write_pointer_data_address(pointer, (address + 1) & 0xFFFFFF)
        return value

    def _write_pointer_mode(self, pointer: str, mode: str, value: int) -> None:
        address = self._pointer_data_address(pointer)
        if mode == "predec":
            address = (address - 1) & 0xFFFFFF
            self._write_pointer_data_address(pointer, address)
        self.write_data(address, value)
        if mode == "postinc":
            self._write_pointer_data_address(pointer, (address + 1) & 0xFFFFFF)

    def _add8(self, left: int, right: int, carry_in: int) -> int:
        result = (left + right + carry_in) & 0xFF
        left3 = _bit(left, 3)
        right3 = _bit(right, 3)
        result3 = _bit(result, 3)
        left7 = _bit(left, 7)
        right7 = _bit(right, 7)
        result7 = _bit(result, 7)
        half = (left3 & right3) | (right3 & (1 - result3)) | ((1 - result3) & left3)
        overflow = (left7 & right7 & (1 - result7)) | ((1 - left7) & (1 - right7) & result7)
        carry = (left7 & right7) | (right7 & (1 - result7)) | ((1 - result7) & left7)
        self.set_flag(FLAG_H, half)
        self.set_flag(FLAG_V, overflow)
        self._set_nzs_from_result(result)
        self.set_flag(FLAG_C, carry)
        return result

    def _sub8(self, left: int, right: int, carry_in: int, previous_z: int | None) -> int:
        result = (left - right - carry_in) & 0xFF
        left3 = _bit(left, 3)
        right3 = _bit(right, 3)
        result3 = _bit(result, 3)
        left7 = _bit(left, 7)
        right7 = _bit(right, 7)
        result7 = _bit(result, 7)
        half = ((1 - left3) & right3) | (right3 & result3) | (result3 & (1 - left3))
        overflow = (left7 & (1 - right7) & (1 - result7)) | ((1 - left7) & right7 & result7)
        carry = ((1 - left7) & right7) | (right7 & result7) | (result7 & (1 - left7))
        self.set_flag(FLAG_H, half)
        self.set_flag(FLAG_V, overflow)
        self.set_flag(FLAG_N, result7)
        zero = 1 if result == 0 else 0
        if previous_z is not None:
            zero &= previous_z
        self.set_flag(FLAG_Z, zero)
        self.set_flag(FLAG_S, self.get_flag(FLAG_N) ^ self.get_flag(FLAG_V))
        self.set_flag(FLAG_C, carry)
        return result

    def _set_logic_flags(self, result: int) -> None:
        self.set_flag(FLAG_V, 0)
        self._set_nzs_from_result(result)

    def _set_nzs_from_result(self, result: int) -> None:
        self.set_flag(FLAG_N, 1 if (result & 0x80) else 0)
        self.set_flag(FLAG_Z, 1 if result == 0 else 0)
        self.set_flag(FLAG_S, self.get_flag(FLAG_N) ^ self.get_flag(FLAG_V))

    def _set_neg_flags(self, result: int, original: int) -> None:
        self.set_flag(FLAG_V, 1 if result == 0x80 else 0)
        self.set_flag(FLAG_H, 1 if ((_bit(result, 3) | _bit(original, 3)) != 0) else 0)
        self.set_flag(FLAG_N, 1 if (result & 0x80) else 0)
        self.set_flag(FLAG_Z, 1 if result == 0 else 0)
        self.set_flag(FLAG_S, self.get_flag(FLAG_N) ^ self.get_flag(FLAG_V))
        self.set_flag(FLAG_C, 1 if result != 0 else 0)

    def _set_adiw_flags(self, original: int, result: int) -> None:
        original15 = _bit(original, 15)
        result15 = _bit(result, 15)
        self.set_flag(FLAG_V, (1 - original15) & result15)
        self.set_flag(FLAG_N, result15)
        self.set_flag(FLAG_Z, 1 if result == 0 else 0)
        self.set_flag(FLAG_C, (1 - result15) & original15)
        self.set_flag(FLAG_S, self.get_flag(FLAG_N) ^ self.get_flag(FLAG_V))

    def _set_sbiw_flags(self, original: int, result: int) -> None:
        original15 = _bit(original, 15)
        result15 = _bit(result, 15)
        self.set_flag(FLAG_V, original15 & (1 - result15))
        self.set_flag(FLAG_N, result15)
        self.set_flag(FLAG_Z, 1 if result == 0 else 0)
        self.set_flag(FLAG_C, result15 & (1 - original15))
        self.set_flag(FLAG_S, self.get_flag(FLAG_N) ^ self.get_flag(FLAG_V))

    def _write_product(self, product: int) -> None:
        result = product & 0xFFFF
        self.write_register(0, result & 0xFF)
        self.write_register(1, (result >> 8) & 0xFF)
        self.set_flag(FLAG_Z, 1 if result == 0 else 0)
        self.set_flag(FLAG_C, 1 if (result & 0x8000) else 0)

    def _write_fractional_product(self, raw_product: int) -> None:
        raw = raw_product & 0xFFFF
        self.set_flag(FLAG_C, 1 if (raw & 0x8000) else 0)
        result = (raw << 1) & 0xFFFF
        self.write_register(0, result & 0xFF)
        self.write_register(1, (result >> 8) & 0xFF)
        self.set_flag(FLAG_Z, 1 if result == 0 else 0)

    def _ensure_extended_pc(self) -> None:
        if self.config.return_address_bytes != 3:
            raise UnsupportedInstructionError("extended indirect call requires a device with a 22-bit PC")

    def _ensure_sram_operation_address(self, address: int, instruction_name: str) -> None:
        if address < self.config.sram_start_address:
            raise DataAddressError(f"{instruction_name} requires an internal SRAM address, got 0x{address:04X}")
        self._validate_data_address(address)

    def _normalize_pc(self, value: int) -> int:
        return value & self.config.pc_mask

    def _validate_register_index(self, index: int) -> None:
        if index < 0 or index > 31:
            raise ValueError("register index must be between 0 and 31")

    def _validate_data_address(self, address: int) -> None:
        if address < 0 or address >= len(self.data):
            raise DataAddressError(f"data-space address 0x{address:X} is out of range")

    def _ensure_stack_address(self, address: int) -> None:
        if address < self.config.sram_start_address or address >= len(self.data):
            raise DataAddressError(f"stack access 0x{address:04X} is outside SRAM")
