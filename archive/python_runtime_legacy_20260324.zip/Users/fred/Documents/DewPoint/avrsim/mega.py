"""Mega-side sidecar board simulation helpers for avrsim."""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from pathlib import Path

from .behavior import BoardVerification, load_built_in_profile, verify_board
from .kicad_pcb import board_from_kicad_pcb
from .nano import (
    GPIOBank,
    INPUT,
    INPUT_PULLUP,
    MCP2515CanBridge,
    MCP2515SpiAdapter,
    OUTPUT,
    SPISim,
    SimulationClock,
)
from .peripherals import (
    MAX31865Model,
    MCP2515Model,
    CanFrame,
)


REPO_ROOT = Path("/Users/fred/Documents/DewPoint")
MEGA_SIDECAR_PCB_PATH = (
    REPO_ROOT
    / "dewpoint_controller/pcb/mega_r3_sidecar_controller_rev_a/mega_r3_sidecar_controller_rev_a.kicad_pcb"
)

ADC_REFERENCE_VOLTAGE_V = 5.0
ADC_MAX_COUNT = 1023
ACTUATOR_FEEDBACK_DIVIDER_GAIN = 2.0


@dataclass
class MAX31865SpiAdapter:
    """SPI-facing wrapper for the MAX31865 register interface."""

    model: MAX31865Model

    def preview_transaction(self, data_out: bytes) -> bytes:
        try:
            preview_model = deepcopy(self.model)
            return self._transaction(preview_model, data_out)
        except ValueError:
            return bytes(len(data_out))

    def commit_transaction(self, data_out: bytes) -> bytes:
        try:
            return self._transaction(self.model, data_out)
        except ValueError:
            return bytes(len(data_out))

    def advance_time_ms(self, elapsed_ms: float) -> None:
        self.model.advance_time_ms(elapsed_ms)

    @staticmethod
    def _transaction(model: MAX31865Model, data_out: bytes) -> bytes:
        if not data_out:
            return b""
        register = data_out[0] & 0x7F
        if (data_out[0] & 0x80) != 0:
            for offset, value in enumerate(data_out[1:]):
                model.write_register(register + offset, value)
            return bytes(len(data_out))
        payload = [0]
        payload.extend(model.read_registers(register, max(0, len(data_out) - 1)))
        return bytes(payload)


@dataclass
class MegaSidecarSim:
    """Board-side simulation of the Mega R3 sidecar controller hardware."""

    clock: SimulationClock = field(default_factory=SimulationClock)
    gpio: GPIOBank = field(default_factory=GPIOBank)
    mcp2515: MCP2515Model = field(default_factory=MCP2515Model)
    max31865: MAX31865Model = field(default_factory=MAX31865Model)
    can_bridge: MCP2515CanBridge = field(init=False)
    spi: SPISim = field(init=False)

    analog_reference_voltage_v: float = ADC_REFERENCE_VOLTAGE_V
    analog_input_volts: dict[str, float] = field(default_factory=dict)
    pwm_duty_by_pin: dict[str, int] = field(default_factory=dict)

    pin_can_cs: str = "D27"
    pin_can_int: str = "D28"
    pin_pipe_rtd_cs: str = "D26"
    pin_actuator_command_pwm: str = "D44"
    pin_actuator_feedback: str = "A10"
    pin_keypad: str = "A0"
    pin_cooling_call: str = "D24"
    sensor_status_led_pins: tuple[str, str, str, str] = ("D30", "D31", "D32", "D33")

    _cooling_call_level: int = 1

    def __post_init__(self) -> None:
        self._define_default_pins()
        self.can_bridge = MCP2515CanBridge(self.mcp2515)
        self.spi = SPISim(self.gpio)
        self.spi.attach_device(self.pin_can_cs, MCP2515SpiAdapter(self.mcp2515))
        self.spi.attach_device(self.pin_pipe_rtd_cs, MAX31865SpiAdapter(self.max31865))
        self.gpio.attach_external_reader(
            self.pin_can_int,
            lambda: 0 if self.can_bridge.interrupt_active_low() else 1,
        )
        self.gpio.attach_external_reader(
            self.pin_cooling_call,
            lambda: 1 if self._cooling_call_level else 0,
        )
        self.set_keypad_adc_raw(ADC_MAX_COUNT)
        self.set_analog_input_voltage(self.pin_actuator_feedback, 0.0)
        self.set_pwm_duty(self.pin_actuator_command_pwm, 0)

    def advance_time_ms(self, elapsed_ms: float) -> None:
        self.clock.advance_ms(elapsed_ms)
        self.max31865.advance_time_ms(elapsed_ms)
        self.can_bridge.advance_time_ms(elapsed_ms)

    def inject_can_frame(self, frame: CanFrame) -> None:
        self.can_bridge.inject_can_frame(frame)

    def receive_can_frame(self) -> CanFrame | None:
        return self.can_bridge.receive_can_frame()

    def set_pipe_temperature(self, probe_temp_c: float) -> None:
        self.max31865.set_probe_temperature(probe_temp_c)

    def set_pipe_fault_status(self, fault_status: int) -> None:
        self.max31865.set_fault_status(fault_status)

    def set_analog_input_voltage(self, pin_name: str, voltage_v: float) -> None:
        clamped = max(0.0, min(self.analog_reference_voltage_v, float(voltage_v)))
        self.analog_input_volts[pin_name] = clamped

    def analog_input_counts(self, pin_name: str) -> int:
        voltage_v = self.analog_input_volts.get(pin_name, self.analog_reference_voltage_v)
        counts = int(round((voltage_v / self.analog_reference_voltage_v) * float(ADC_MAX_COUNT)))
        return max(0, min(ADC_MAX_COUNT, counts))

    def set_keypad_adc_raw(self, raw_count: int) -> None:
        normalized = max(0, min(ADC_MAX_COUNT, int(raw_count)))
        voltage_v = (float(normalized) / float(ADC_MAX_COUNT)) * self.analog_reference_voltage_v
        self.set_analog_input_voltage(self.pin_keypad, voltage_v)

    def set_actuator_feedback_voltage(self, voltage_v: float) -> None:
        """Set the external 0-10V actuator feedback that is divided into A10."""

        divided = max(0.0, float(voltage_v)) / ACTUATOR_FEEDBACK_DIVIDER_GAIN
        self.set_analog_input_voltage(self.pin_actuator_feedback, divided)

    def set_cooling_call_active(self, active: bool) -> None:
        self._cooling_call_level = 0 if active else 1

    def set_pwm_duty(self, pin_name: str, duty: int) -> None:
        self.pwm_duty_by_pin[pin_name] = max(0, min(255, int(duty)))

    def pwm_duty(self, pin_name: str) -> int:
        return self.pwm_duty_by_pin.get(pin_name, 0)

    @property
    def sensor_status_leds(self) -> tuple[bool, bool, bool, bool]:
        return tuple(self.gpio.digital_read(pin_name) != 0 for pin_name in self.sensor_status_led_pins)

    def verify_board(self) -> BoardVerification:
        board = board_from_kicad_pcb(str(MEGA_SIDECAR_PCB_PATH))
        profile = load_built_in_profile(board.name)
        return verify_board(board, profile)

    def _define_default_pins(self) -> None:
        for pin_number in range(54):
            self.gpio.define_pin(f"D{pin_number}")
        for analog_index in range(16):
            self.gpio.define_pin(f"A{analog_index}")

        self.gpio.pin_mode(self.pin_can_cs, OUTPUT)
        self.gpio.digital_write(self.pin_can_cs, 1)
        self.gpio.set_input_level(self.pin_can_cs, 1)
        self.gpio.pin_mode(self.pin_pipe_rtd_cs, OUTPUT)
        self.gpio.digital_write(self.pin_pipe_rtd_cs, 1)
        self.gpio.set_input_level(self.pin_pipe_rtd_cs, 1)
        self.gpio.pin_mode(self.pin_can_int, INPUT_PULLUP)
        self.gpio.pin_mode(self.pin_cooling_call, INPUT_PULLUP)
        self.gpio.pin_mode(self.pin_actuator_command_pwm, OUTPUT)
        self.gpio.digital_write(self.pin_actuator_command_pwm, 0)
        for pin_name in self.sensor_status_led_pins:
            self.gpio.pin_mode(pin_name, OUTPUT)
            self.gpio.digital_write(pin_name, 0)


__all__ = [
    "ACTUATOR_FEEDBACK_DIVIDER_GAIN",
    "ADC_MAX_COUNT",
    "ADC_REFERENCE_VOLTAGE_V",
    "MAX31865SpiAdapter",
    "MEGA_SIDECAR_PCB_PATH",
    "MegaSidecarSim",
]
