"""Mega sidecar board simulation tests."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from avrsim.mega import MegaSidecarSim
from avrsim.peripherals import CanFrame


def test_mega_sidecar_board_verification() -> None:
    board = MegaSidecarSim()
    report = board.verify_board()
    assert report.ok


def test_can_bridge_interrupts_and_frames() -> None:
    board = MegaSidecarSim()
    frame = CanFrame(frame_id=0x321, length=2, data=(0xAA, 0x55, 0, 0, 0, 0, 0, 0))
    board.inject_can_frame(frame)
    board.advance_time_ms(0.1)
    assert board.gpio.digital_read(board.pin_can_int) == 0


def test_actuator_feedback_helper_scales_into_a10() -> None:
    board = MegaSidecarSim()
    board.set_actuator_feedback_voltage(8.0)
    assert abs(board.analog_input_volts["A10"] - 4.0) <= 1.0e-6
    assert 817 <= board.analog_input_counts("A10") <= 819


def main() -> int:
    test_mega_sidecar_board_verification()
    test_can_bridge_interrupts_and_frames()
    test_actuator_feedback_helper_scales_into_a10()
    print("avrsim Mega sidecar board tests passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
