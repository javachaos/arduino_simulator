"""Helpers for loading AVR firmware symbols from ELF files."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import shutil
import subprocess


_AVR_DATA_VMA_BASE = 0x800000


class ElfSymbolError(RuntimeError):
    """Raised when firmware symbol discovery fails."""


@dataclass(frozen=True)
class FirmwareSymbols:
    """Named firmware symbols loaded from an ELF image."""

    addresses: dict[str, int]

    def require(self, name: str) -> int:
        try:
            return self.addresses[name]
        except KeyError as exc:
            raise ElfSymbolError(f"required symbol {name!r} is not present in the ELF image") from exc

    def require_word_address(self, name: str) -> int:
        address = self.require(name)
        if (address & 0x01) != 0:
            raise ElfSymbolError(f"symbol {name!r} does not have an even byte address")
        return address // 2

    def require_data_address(self, name: str) -> int:
        address = self.require(name)
        if address >= _AVR_DATA_VMA_BASE:
            return address - _AVR_DATA_VMA_BASE
        return address


def parse_avr_nm_output(output: str) -> FirmwareSymbols:
    addresses: dict[str, int] = {}
    for raw_line in output.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        parts = line.split(maxsplit=2)
        if len(parts) < 3:
            continue
        address_text, _, name = parts
        try:
            address = int(address_text, 16)
        except ValueError:
            continue
        addresses[name] = address
    return FirmwareSymbols(addresses)


def load_elf_symbols(path: str | Path, *, nm_path: str | Path | None = None) -> FirmwareSymbols:
    elf_path = Path(path)
    if not elf_path.is_file():
        raise ElfSymbolError(f"ELF file does not exist: {elf_path}")
    avr_nm = Path(nm_path) if nm_path is not None else find_avr_nm()
    if avr_nm is None:
        raise ElfSymbolError("could not locate avr-nm; install the Arduino AVR toolchain or provide --avr-nm")
    try:
        result = subprocess.run(
            [str(avr_nm), "-an", str(elf_path)],
            check=True,
            capture_output=True,
            text=True,
        )
    except (OSError, subprocess.CalledProcessError) as exc:
        raise ElfSymbolError(f"failed to load symbols from {elf_path}: {exc}") from exc
    return parse_avr_nm_output(result.stdout)


def find_avr_nm() -> Path | None:
    which_path = shutil.which("avr-nm")
    if which_path:
        return Path(which_path)
    arduino_tool_root = Path.home() / "Library" / "Arduino15" / "packages" / "arduino" / "tools" / "avr-gcc"
    if not arduino_tool_root.exists():
        return None
    candidates = sorted(arduino_tool_root.glob("*/bin/avr-nm"))
    if not candidates:
        return None
    return candidates[-1]


def sibling_elf_path(hex_path: str | Path) -> Path:
    return Path(hex_path).with_suffix(".elf")


__all__ = [
    "ElfSymbolError",
    "FirmwareSymbols",
    "find_avr_nm",
    "load_elf_symbols",
    "parse_avr_nm_output",
    "sibling_elf_path",
]
