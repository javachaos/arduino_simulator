"""Terminal monitor formatter tests."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from avrsim.elf_symbols import FirmwareSymbols
from avrsim.nano_runtime import NanoAirNodeFirmwareSim
from avrsim.tui import (
    ProgramSymbolResolver,
    build_runtime_snapshot,
    format_cpu_panel,
    format_serial_panel,
)


def test_symbol_resolver_reports_the_active_function_offset() -> None:
    resolver = ProgramSymbolResolver(
        FirmwareSymbols(
            {
                "setup": 0x0010,
                "loop": 0x0040,
                "timer0_millis": 0x8007FE,
            }
        )
    )

    assert resolver.resolve_pc(0x0008) == "setup"
    assert resolver.resolve_pc(0x0009) == "setup+0x2"
    assert resolver.resolve_pc(0x0020) == "loop"


def test_cpu_panel_shows_visible_pause_and_step_controls() -> None:
    sim = NanoAirNodeFirmwareSim()
    sim.cpu.load_program_words([0x0000])

    running_snapshot = build_runtime_snapshot(sim, title="Nano Monitor", paused=False)
    running_lines = format_cpu_panel(running_snapshot, width=120)
    assert running_lines[0] == "Nano Monitor | RUN"
    assert "[Pause: Space]" in running_lines[1]
    assert "[Step: S]" in running_lines[1]
    assert "[Quit: Q]" in running_lines[1]

    paused_snapshot = build_runtime_snapshot(sim, title="Nano Monitor", paused=True)
    paused_lines = format_cpu_panel(paused_snapshot, width=120)
    assert paused_lines[0] == "Nano Monitor | PAUSE"
    assert "[Resume: Space]" in paused_lines[1]


def test_serial_panel_uses_a_placeholder_before_any_output_arrives() -> None:
    sim = NanoAirNodeFirmwareSim()
    sim.cpu.load_program_words([0x0000])
    snapshot = build_runtime_snapshot(sim, title="Nano Monitor", paused=False)
    lines = format_serial_panel(snapshot, width=40, height=4)

    assert lines == ["<no serial output yet>"]


def main() -> int:
    test_symbol_resolver_reports_the_active_function_offset()
    test_cpu_panel_shows_visible_pause_and_step_controls()
    test_serial_panel_uses_a_placeholder_before_any_output_arrives()
    print("avrsim TUI tests passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
