"""Project-level CAN application protocol tests for avrsim."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from avrsim.peripherals.can import (
    CAN_AIR_SAMPLE_BASE_ID,
    CAN_IDENTITY_BASE_ID,
    CanAirNodeModel,
    CanBusModel,
    decode_identity_frame,
    decode_sample_frame,
    encode_identity_frame,
    encode_sample_frame,
)


def _almost_equal(left: float, right: float, tolerance: float) -> bool:
    return abs(left - right) <= tolerance


def test_can_sample_round_trip() -> None:
    frame = encode_sample_frame(2, 23.45, 56.78, True, 17)
    assert frame.frame_id == CAN_AIR_SAMPLE_BASE_ID + 1
    sample = decode_sample_frame(frame)
    assert sample.node_id == 2
    assert sample.sensor_ok
    assert sample.sequence == 17
    assert _almost_equal(sample.temp_c, 23.45, 0.01)
    assert _almost_equal(sample.rh_percent, 56.78, 0.01)


def test_can_identity_round_trip() -> None:
    frame = encode_identity_frame(1, 0x112233445566)
    assert frame.frame_id == CAN_IDENTITY_BASE_ID
    identity = decode_identity_frame(frame)
    assert identity.node_id == 1
    assert identity.sensor_id == 0x112233445566


def test_can_bus_and_node_model() -> None:
    bus = CanBusModel()
    node = CanAirNodeModel(
        node_id=3,
        sensor_id=0x010203040506,
        sequence=9,
        sensor_ok=False,
        temp_c=19.25,
        rh_percent=48.0,
    )
    node.publish_current_sample(bus)
    assert bus.pending_count() == 2

    sample_frame = bus.receive()
    identity_frame = bus.receive()
    assert sample_frame is not None
    assert identity_frame is not None
    sample = decode_sample_frame(sample_frame)
    identity = decode_identity_frame(identity_frame)
    assert sample.node_id == 3
    assert not sample.sensor_ok
    assert sample.sequence == 9
    assert identity.sensor_id == 0x010203040506


def main() -> int:
    test_can_sample_round_trip()
    test_can_identity_round_trip()
    test_can_bus_and_node_model()
    print("avrsim CAN application protocol tests passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
