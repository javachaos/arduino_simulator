"""Semantic fast-forward helpers for Arduino-core timing routines."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .elf_symbols import FirmwareSymbols, load_elf_symbols


@dataclass(frozen=True)
class ArduinoTimer0DelayTurbo:
    """Symbol addresses needed to short-circuit Arduino delay() safely."""

    delay_word_address: int
    timer0_fract_data_address: int
    timer0_millis_data_address: int
    timer0_overflow_count_data_address: int

    @classmethod
    def from_symbols(cls, symbols: FirmwareSymbols) -> "ArduinoTimer0DelayTurbo":
        return cls(
            delay_word_address=symbols.require_word_address("delay"),
            timer0_fract_data_address=symbols.require_data_address("timer0_fract"),
            timer0_millis_data_address=symbols.require_data_address("timer0_millis"),
            timer0_overflow_count_data_address=symbols.require_data_address("timer0_overflow_count"),
        )

    @classmethod
    def from_elf(
        cls,
        path: str | Path,
        *,
        nm_path: str | Path | None = None,
    ) -> "ArduinoTimer0DelayTurbo":
        return cls.from_symbols(load_elf_symbols(path, nm_path=nm_path))


__all__ = ["ArduinoTimer0DelayTurbo"]
