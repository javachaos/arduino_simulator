"""Tests for the native avrsim GUI model."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from avrsim.gui_model import GuiScene, build_gui_model_from_pcb
from avrsim.kicad_layout import layout_from_kicad_pcb
from avrsim.layout import Point
from avrsim.tk_gui import describe_net_electrical, project_canvas_point, scene_status


def test_air_node_layout_and_gui_model() -> None:
    layout = layout_from_kicad_pcb(
        "/Users/fred/Documents/DewPoint/dewpoint_controller/pcb/air_node/air_node.kicad_pcb"
    )
    assert layout.name == "air_node"
    assert len(layout.footprints) == 7
    assert len(layout.edge_cuts) == 4
    assert len(layout.tracks) > 50
    assert len(layout.vias) >= 2
    assert len(layout.zones) == 2

    j101 = next(footprint for footprint in layout.footprints if footprint.reference == "J101")
    j101_pads = {pad.number: pad for pad in j101.pads}
    assert j101_pads["7"].position.x_mm < j101_pads["1"].position.x_mm

    rj45 = next(footprint for footprint in layout.footprints if footprint.reference == "RJ45")
    rj45_pads = {pad.number: pad for pad in rj45.pads if pad.number}
    assert rj45_pads["8"].position.x_mm > rj45_pads["1"].position.x_mm

    model = build_gui_model_from_pcb(
        "/Users/fred/Documents/DewPoint/dewpoint_controller/pcb/air_node/air_node.kicad_pcb"
    )
    assert model.board_name == "air_node"
    assert model.verification_ok is True
    assert len(model.scenes) >= 5
    assert any(scene.category == "can" for scene in model.scenes)
    assert any("/A4{slash}SDA" in scene.active_nets for scene in model.scenes)
    assert any(scene.net_flows.get("/A4{slash}SDA") == ("J1", "SHT31") for scene in model.scenes)

    top_left = project_canvas_point(
        Point(layout.bounds.min_x_mm, layout.bounds.min_y_mm),
        layout.bounds,
        width_px=1200,
        height_px=900,
        zoom=1.0,
        pan_x=0.0,
        pan_y=0.0,
    )
    bottom_left = project_canvas_point(
        Point(layout.bounds.min_x_mm, layout.bounds.max_y_mm),
        layout.bounds,
        width_px=1200,
        height_px=900,
        zoom=1.0,
        pan_x=0.0,
        pan_y=0.0,
    )
    assert top_left[1] < bottom_left[1]


def test_sidecar_layout_and_gui_model() -> None:
    layout = layout_from_kicad_pcb(
        "/Users/fred/Documents/DewPoint/dewpoint_controller/pcb/mega_r3_sidecar_controller_rev_a/mega_r3_sidecar_controller_rev_a.kicad_pcb"
    )
    assert layout.name == "mega_r3_sidecar_controller_rev_a"
    assert len(layout.footprints) == 34
    assert len(layout.edge_cuts) == 4
    assert len(layout.tracks) > 250
    assert len(layout.vias) > 10

    p_dig = next(footprint for footprint in layout.footprints if footprint.reference == "P_DIG")
    p_dig_pads = {pad.number: pad for pad in p_dig.pads}
    assert p_dig_pads["2"].position.x_mm < p_dig_pads["1"].position.x_mm

    model = build_gui_model_from_pcb(
        "/Users/fred/Documents/DewPoint/dewpoint_controller/pcb/mega_r3_sidecar_controller_rev_a/mega_r3_sidecar_controller_rev_a.kicad_pcb"
    )
    assert model.board_name == "mega_r3_sidecar_controller_rev_a"
    assert model.verification_ok is True
    assert len(model.scenes) >= 5
    assert any(scene.category == "analog" for scene in model.scenes)
    assert any("CANH" in scene.active_nets for scene in model.scenes)
    assert any(scene.net_flows.get("/*44") == ("J107", "K5") for scene in model.scenes)


def test_scene_status_transitions() -> None:
    assert scene_status(
        index=0,
        current_index=0,
        scene_count=5,
        playing=True,
        run_complete=False,
    ) == ("ACTIVE", "#ffd166")
    assert scene_status(
        index=0,
        current_index=0,
        scene_count=5,
        playing=False,
        run_complete=False,
    ) == ("PAUSED", "#ffd166")
    assert scene_status(
        index=3,
        current_index=4,
        scene_count=5,
        playing=False,
        run_complete=True,
    ) == ("PASS", "#8ccf7f")
    assert scene_status(
        index=4,
        current_index=4,
        scene_count=5,
        playing=False,
        run_complete=True,
    ) == ("PASS", "#8ccf7f")
    assert scene_status(
        index=4,
        current_index=3,
        scene_count=5,
        playing=True,
        run_complete=False,
    ) == ("QUEUED", "#9fb3c8")


def test_describe_net_electrical() -> None:
    scene = GuiScene(
        title="Test",
        message="Test scene",
        duration_ms=1000,
        active_nets=["CANH", "+24V", "/*44"],
        net_flows={
            "CANH": ("J101", "K1"),
            "+24V": ("RJ45", "REG5V"),
        },
    )

    canh = describe_net_electrical(scene, "CANH")
    assert "dominant" in canh.voltage_text
    assert "J101 -> K1" in (canh.note_text or "")

    rail = describe_net_electrical(scene, "+24V")
    assert rail.voltage_text == "24 V nominal DC"
    assert "not solved" in rail.current_text

    pwm = describe_net_electrical(scene, "/*44")
    assert pwm.voltage_text == "0-5 V PWM logic output"


def main() -> int:
    test_air_node_layout_and_gui_model()
    test_sidecar_layout_and_gui_model()
    test_scene_status_transitions()
    test_describe_net_electrical()
    print("avrsim GUI model tests passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
