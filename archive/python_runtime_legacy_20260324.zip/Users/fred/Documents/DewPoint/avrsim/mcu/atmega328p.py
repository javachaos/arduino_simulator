"""ATmega328P memory-mapped runtime bindings for avrsim."""

from __future__ import annotations

from dataclasses import dataclass, field

from ..cpu import CPU
from ..cpu.CPU import CPUHooks, DecodedInstruction, FLAG_I
from ..nano import INPUT, INPUT_PULLUP, OUTPUT, NanoAirNodeSim


# Data-space addresses for the ATmega328P.
PINB = 0x23
DDRB = 0x24
PORTB = 0x25
PINC = 0x26
DDRC = 0x27
PORTC = 0x28
PIND = 0x29
DDRD = 0x2A
PORTD = 0x2B

TIFR0 = 0x35
TCCR0A = 0x44
TCCR0B = 0x45
TCNT0 = 0x46

SPCR = 0x4C
SPSR = 0x4D
SPDR = 0x4E

TIMSK0 = 0x6E

UCSR0A = 0xC0
UCSR0B = 0xC1
UCSR0C = 0xC2
UBRR0L = 0xC4
UBRR0H = 0xC5
UDR0 = 0xC6

TWBR = 0xB8
TWSR = 0xB9
TWAR = 0xBA
TWDR = 0xBB
TWCR = 0xBC
TWAMR = 0xBD

# Interrupt vector numbers from avr/iom328p.h
TIMER0_OVF_VECTOR = 16
USART_RX_VECTOR = 18
USART_UDRE_VECTOR = 19
USART_TX_VECTOR = 20
TWI_VECTOR = 24

# Timer0 bits.
TOIE0 = 1 << 0
TOV0 = 1 << 0

# SPI bits.
SPI2X = 1 << 0
WCOL = 1 << 6
SPIF = 1 << 7
MSTR = 1 << 4
SPE = 1 << 6

# USART0 bits.
MPCM0 = 1 << 0
U2X0 = 1 << 1
UPE0 = 1 << 2
DOR0 = 1 << 3
FE0 = 1 << 4
UDRE0 = 1 << 5
TXC0 = 1 << 6
RXC0 = 1 << 7
UCSZ02 = 1 << 2
TXEN0 = 1 << 3
RXEN0 = 1 << 4
UDRIE0 = 1 << 5
TXCIE0 = 1 << 6
RXCIE0 = 1 << 7

# TWI bits.
TWIE = 1 << 0
TWEN = 1 << 2
TWWC = 1 << 3
TWSTO = 1 << 4
TWSTA = 1 << 5
TWEA = 1 << 6
TWINT = 1 << 7

# TWI master statuses from compat/twi.h
TW_START = 0x08
TW_REP_START = 0x10
TW_MT_SLA_ACK = 0x18
TW_MT_SLA_NACK = 0x20
TW_MT_DATA_ACK = 0x28
TW_MT_DATA_NACK = 0x30
TW_MR_SLA_ACK = 0x40
TW_MR_SLA_NACK = 0x48
TW_MR_DATA_ACK = 0x50
TW_MR_DATA_NACK = 0x58
TW_NO_INFO = 0xF8

_PORT_BIT_TO_PIN = {
    "B": {
        0: "D8",
        1: "D9",
        2: "D10",
        3: "D11",
        4: "D12",
        5: "D13",
    },
    "C": {
        0: "A0",
        1: "A1",
        2: "A2",
        3: "A3",
        4: "A4",
        5: "A5",
    },
    "D": {
        0: "D0",
        1: "D1",
        2: "D2",
        3: "D3",
        4: "D4",
        5: "D5",
        6: "D6",
        7: "D7",
    },
}

_PORT_ADDRESS_BY_NAME = {
    "B": (PINB, DDRB, PORTB),
    "C": (PINC, DDRC, PORTC),
    "D": (PIND, DDRD, PORTD),
}

_TIMER0_PRESCALER = {
    0: None,
    1: 1,
    2: 8,
    3: 64,
    4: 256,
    5: 1024,
    6: None,
    7: None,
}


@dataclass
class Atmega328P(CPUHooks):
    """Minimal but real ATmega328P MMIO layer for the Nano air-node."""

    board: NanoAirNodeSim = field(default_factory=NanoAirNodeSim)
    clock_hz: int = 16_000_000

    _timer0_cycle_remainder: int = 0
    _timer0_interrupt_pending: bool = False
    _spi_transaction_active: bool = False
    _twi_interrupt_pending: bool = False
    _twi_bus_active: bool = False
    _twi_device: object | None = None
    _twi_read_mode: bool = False
    _twi_write_buffer: bytearray = field(default_factory=bytearray)
    _twi_read_buffer: bytearray = field(default_factory=bytearray)
    _twi_read_index: int = 0
    _usart0_tx_log: bytearray = field(default_factory=bytearray)
    _usart0_rx_queue: bytearray = field(default_factory=bytearray)
    _usart0_tx_busy_byte: int | None = None
    _usart0_tx_cycles_remaining: int = 0

    def reset(self, cpu: CPU) -> None:
        self._timer0_cycle_remainder = 0
        self._timer0_interrupt_pending = False
        self._spi_transaction_active = False
        self._twi_interrupt_pending = False
        self._twi_bus_active = False
        self._twi_device = None
        self._twi_read_mode = False
        self._twi_write_buffer = bytearray()
        self._twi_read_buffer = bytearray()
        self._twi_read_index = 0
        self._usart0_tx_log = bytearray()
        self._usart0_rx_queue = bytearray()
        self._usart0_tx_busy_byte = None
        self._usart0_tx_cycles_remaining = 0
        cpu.data[TIFR0] = 0
        cpu.data[TWSR] = TW_NO_INFO
        cpu.data[UCSR0A] = UDRE0 | TXC0
        cpu.data[UCSR0B] = 0
        cpu.data[UCSR0C] = 0
        cpu.data[UBRR0L] = 0
        cpu.data[UBRR0H] = 0
        cpu.data[UDR0] = 0
        self._sync_all_ports(cpu)

    @property
    def serial_output_bytes(self) -> bytes:
        return bytes(self._usart0_tx_log)

    def serial_output_text(self, *, encoding: str = "utf-8", errors: str = "replace") -> str:
        return self.serial_output_bytes.decode(encoding, errors=errors)

    def clear_serial_output(self) -> None:
        self._usart0_tx_log = bytearray()

    def inject_usart0_rx(self, cpu: CPU, payload: bytes | bytearray) -> None:
        self._usart0_rx_queue.extend(int(byte) & 0xFF for byte in payload)
        self._service_usart0_receive_latch(cpu)

    def read_data(self, cpu: CPU, address: int) -> int | None:
        if address == PINB:
            return self._read_pin_register("B")
        if address == PINC:
            return self._read_pin_register("C")
        if address == PIND:
            return self._read_pin_register("D")
        if address == UDR0:
            value = cpu.data[UDR0]
            cpu.data[UCSR0A] &= ~RXC0
            self._service_usart0_receive_latch(cpu)
            return value & 0xFF
        if address == SPDR:
            value = cpu.data[SPDR]
            cpu.data[SPSR] &= ~(SPIF | WCOL)
            return value
        handled = {
            DDRB,
            PORTB,
            DDRC,
            PORTC,
            DDRD,
            PORTD,
            TIFR0,
            TCCR0A,
            TCCR0B,
            TCNT0,
            SPCR,
            SPSR,
            TIMSK0,
            UCSR0A,
            UCSR0B,
            UCSR0C,
            UBRR0L,
            UBRR0H,
            TWBR,
            TWSR,
            TWAR,
            TWDR,
            TWCR,
            TWAMR,
            UDR0,
        }
        if address in handled:
            return cpu.data[address]
        return None

    def write_data(self, cpu: CPU, address: int, value: int) -> bool:
        value &= 0xFF
        if address == DDRB:
            cpu.data[DDRB] = value
            self._sync_port(cpu, "B")
            return True
        if address == PORTB:
            cpu.data[PORTB] = value
            self._sync_port(cpu, "B")
            return True
        if address == DDRC:
            cpu.data[DDRC] = value
            self._sync_port(cpu, "C")
            return True
        if address == PORTC:
            cpu.data[PORTC] = value
            self._sync_port(cpu, "C")
            return True
        if address == DDRD:
            cpu.data[DDRD] = value
            self._sync_port(cpu, "D")
            return True
        if address == PORTD:
            cpu.data[PORTD] = value
            self._sync_port(cpu, "D")
            return True
        if address == PINB:
            cpu.data[PORTB] ^= value
            self._sync_port(cpu, "B")
            return True
        if address == PINC:
            cpu.data[PORTC] ^= value
            self._sync_port(cpu, "C")
            return True
        if address == PIND:
            cpu.data[PORTD] ^= value
            self._sync_port(cpu, "D")
            return True
        if address == TIFR0:
            cpu.data[TIFR0] &= ~(value & 0xFF)
            if (cpu.data[TIFR0] & TOV0) == 0:
                self._timer0_interrupt_pending = False
            return True
        if address in (TCCR0A, TCCR0B, TCNT0, TIMSK0, SPCR, TWBR, TWAR, TWDR, TWAMR, UBRR0L, UBRR0H, UCSR0C):
            cpu.data[address] = value
            return True
        if address == UCSR0A:
            current = cpu.data[UCSR0A]
            current = (current & ~(MPCM0 | U2X0)) | (value & (MPCM0 | U2X0))
            if (value & TXC0) != 0:
                current &= ~TXC0
            cpu.data[UCSR0A] = current
            return True
        if address == UCSR0B:
            cpu.data[UCSR0B] = value
            if (value & RXEN0) == 0:
                cpu.data[UCSR0A] &= ~RXC0
            else:
                self._service_usart0_receive_latch(cpu)
            return True
        if address == SPSR:
            cpu.data[SPSR] = (cpu.data[SPSR] & (SPIF | WCOL)) | (value & SPI2X)
            return True
        if address == UDR0:
            self._write_udr0(cpu, value)
            return True
        if address == SPDR:
            self._write_spdr(cpu, value)
            return True
        if address == TWSR:
            cpu.data[TWSR] = (cpu.data[TWSR] & 0xF8) | (value & 0x03)
            return True
        if address == TWCR:
            self._write_twcr(cpu, value)
            return True
        return False

    def after_step(self, cpu: CPU, instruction: DecodedInstruction, cycles: int) -> None:
        del instruction
        self.advance_cycles(cpu, cycles)

    def advance_cycles(self, cpu: CPU, cycles: int) -> None:
        if cycles <= 0:
            return
        self._advance_elapsed_time(cpu, cycles)
        self._service_interrupts(cpu)

    def _advance_elapsed_time(self, cpu: CPU, cycles: int) -> None:
        elapsed_ms = float(cycles) * 1000.0 / float(self.clock_hz)
        self.board.advance_time_ms(elapsed_ms)
        self._advance_timer0(cpu, cycles)
        self._advance_usart0(cpu, cycles)

    def _advance_timer0(self, cpu: CPU, cycles: int) -> None:
        prescaler = _TIMER0_PRESCALER[cpu.data[TCCR0B] & 0x07]
        if prescaler is None:
            self._timer0_cycle_remainder = 0
            return

        total_cycles = self._timer0_cycle_remainder + cycles
        tick_count, self._timer0_cycle_remainder = divmod(total_cycles, prescaler)
        if tick_count <= 0:
            return

        counter = cpu.data[TCNT0]
        for _ in range(tick_count):
            counter += 1
            if counter > 0xFF:
                counter = 0
                cpu.data[TIFR0] |= TOV0
                if (cpu.data[TIMSK0] & TOIE0) != 0:
                    self._timer0_interrupt_pending = True
        cpu.data[TCNT0] = counter & 0xFF

    def _service_interrupts(self, cpu: CPU) -> None:
        if cpu.interrupts_deferred or cpu.get_flag(FLAG_I) == 0:
            return
        if self._timer0_interrupt_pending and (cpu.data[TIMSK0] & TOIE0) != 0:
            self._timer0_interrupt_pending = False
            cpu.take_interrupt(TIMER0_OVF_VECTOR)
            self._advance_elapsed_time(cpu, 4)
            return
        if (
            (cpu.data[UCSR0A] & RXC0) != 0
            and (cpu.data[UCSR0B] & RXCIE0) != 0
            and (cpu.data[UCSR0B] & RXEN0) != 0
        ):
            cpu.take_interrupt(USART_RX_VECTOR)
            self._advance_elapsed_time(cpu, 4)
            return
        if (
            (cpu.data[UCSR0A] & UDRE0) != 0
            and (cpu.data[UCSR0B] & UDRIE0) != 0
            and (cpu.data[UCSR0B] & TXEN0) != 0
        ):
            cpu.take_interrupt(USART_UDRE_VECTOR)
            self._advance_elapsed_time(cpu, 4)
            return
        if (
            (cpu.data[UCSR0A] & TXC0) != 0
            and (cpu.data[UCSR0B] & TXCIE0) != 0
            and (cpu.data[UCSR0B] & TXEN0) != 0
        ):
            cpu.take_interrupt(USART_TX_VECTOR)
            self._advance_elapsed_time(cpu, 4)
            return
        if (
            self._twi_interrupt_pending
            and (cpu.data[TWCR] & TWIE) != 0
            and (cpu.data[TWCR] & TWINT) != 0
        ):
            self._twi_interrupt_pending = False
            cpu.take_interrupt(TWI_VECTOR)
            self._advance_elapsed_time(cpu, 4)

    def _read_pin_register(self, port_name: str) -> int:
        value = 0
        for bit_index, pin_name in _PORT_BIT_TO_PIN[port_name].items():
            if self.board.gpio.digital_read(pin_name) != 0:
                value |= 1 << bit_index
        return value & 0xFF

    def _sync_all_ports(self, cpu: CPU) -> None:
        self._sync_port(cpu, "B")
        self._sync_port(cpu, "C")
        self._sync_port(cpu, "D")

    def _sync_port(self, cpu: CPU, port_name: str) -> None:
        _, ddr_address, port_address = _PORT_ADDRESS_BY_NAME[port_name]
        ddr_value = cpu.data[ddr_address]
        port_value = cpu.data[port_address]

        for bit_index, pin_name in _PORT_BIT_TO_PIN[port_name].items():
            old_level = self.board.gpio.digital_read(pin_name)
            bit_mask = 1 << bit_index
            if (ddr_value & bit_mask) != 0:
                self.board.gpio.pin_mode(pin_name, OUTPUT)
                self.board.gpio.digital_write(pin_name, 1 if (port_value & bit_mask) else 0)
            else:
                input_mode = INPUT_PULLUP if (port_value & bit_mask) else INPUT
                self.board.gpio.pin_mode(pin_name, input_mode)
            new_level = self.board.gpio.digital_read(pin_name)
            if pin_name == self.board.pin_can_cs:
                self._handle_spi_chip_select(old_level, new_level, cpu)

    def _handle_spi_chip_select(self, old_level: int, new_level: int, cpu: CPU) -> None:
        if old_level == new_level:
            return
        if new_level == 0:
            if not self._spi_transaction_active:
                self.board.spi.begin_transaction(self._spi_settings(cpu))
                self._spi_transaction_active = True
            return
        if self._spi_transaction_active:
            self.board.spi.end_transaction()
            self._spi_transaction_active = False

    def _spi_settings(self, cpu: CPU) -> dict[str, int]:
        return {
            "spcr": cpu.data[SPCR] & 0xFF,
            "spsr": cpu.data[SPSR] & 0xFF,
        }

    def _write_spdr(self, cpu: CPU, value: int) -> None:
        cpu.data[SPDR] = value & 0xFF
        if (cpu.data[SPCR] & (SPE | MSTR)) != (SPE | MSTR):
            return

        if self.board.gpio.digital_read(self.board.pin_can_cs) == 0:
            if not self._spi_transaction_active:
                self.board.spi.begin_transaction(self._spi_settings(cpu))
                self._spi_transaction_active = True
            response = self.board.spi.transfer(value & 0xFF)
        else:
            response = 0x00

        cpu.data[SPDR] = response & 0xFF
        cpu.data[SPSR] = (cpu.data[SPSR] & SPI2X) | SPIF

    def _write_udr0(self, cpu: CPU, value: int) -> None:
        cpu.data[UDR0] = value & 0xFF
        if (cpu.data[UCSR0B] & TXEN0) == 0:
            return
        self._usart0_tx_busy_byte = value & 0xFF
        self._usart0_tx_cycles_remaining = self._usart0_frame_cycles(cpu)
        cpu.data[UCSR0A] &= ~(UDRE0 | TXC0)

    def _advance_usart0(self, cpu: CPU, cycles: int) -> None:
        if self._usart0_tx_busy_byte is not None:
            self._usart0_tx_cycles_remaining -= cycles
            if self._usart0_tx_cycles_remaining <= 0:
                self._usart0_tx_log.append(self._usart0_tx_busy_byte & 0xFF)
                self._usart0_tx_busy_byte = None
                self._usart0_tx_cycles_remaining = 0
                cpu.data[UCSR0A] |= UDRE0 | TXC0
        self._service_usart0_receive_latch(cpu)

    def _service_usart0_receive_latch(self, cpu: CPU) -> None:
        if (cpu.data[UCSR0B] & RXEN0) == 0:
            return
        if (cpu.data[UCSR0A] & RXC0) != 0:
            return
        if not self._usart0_rx_queue:
            return
        cpu.data[UDR0] = self._usart0_rx_queue.pop(0) & 0xFF
        cpu.data[UCSR0A] |= RXC0

    def _usart0_frame_cycles(self, cpu: CPU) -> int:
        ubrr = cpu.data[UBRR0L] | ((cpu.data[UBRR0H] & 0x0F) << 8)
        double_speed = (cpu.data[UCSR0A] & U2X0) != 0
        divisor = 8 if double_speed else 16
        baud = self.clock_hz / float(divisor * (ubrr + 1))
        if baud <= 0.0:
            return 1
        frame_bits = 10
        cycles = int(round((self.clock_hz * frame_bits) / baud))
        return max(1, cycles)

    def _write_twcr(self, cpu: CPU, value: int) -> None:
        cpu.data[TWCR] = value & 0xFF
        if (value & TWINT) != 0:
            cpu.data[TWCR] &= ~TWINT

        if (value & TWEN) == 0:
            self._reset_twi_runtime(cpu)
            return

        if (value & TWSTO) != 0:
            self._finish_twi_write_if_needed()
            cpu.data[TWCR] &= ~TWSTO
            self._twi_bus_active = False
            self._twi_device = None
            self._twi_read_mode = False
            self._twi_read_buffer = bytearray()
            self._twi_read_index = 0
            return

        if (value & TWSTA) != 0:
            self._finish_twi_write_if_needed()
            status = TW_REP_START if self._twi_bus_active else TW_START
            self._twi_bus_active = True
            self._queue_twi_status(cpu, status)
            return

        current_status = cpu.data[TWSR] & 0xF8
        if current_status in (TW_START, TW_REP_START):
            self._handle_twi_address_phase(cpu)
            return
        if current_status in (TW_MT_SLA_ACK, TW_MT_DATA_ACK):
            self._handle_twi_write_phase(cpu)
            return
        if current_status in (TW_MR_SLA_ACK, TW_MR_DATA_ACK):
            self._handle_twi_read_phase(cpu, ack_requested=(value & TWEA) != 0)

    def _reset_twi_runtime(self, cpu: CPU) -> None:
        self._twi_interrupt_pending = False
        self._twi_bus_active = False
        self._twi_device = None
        self._twi_read_mode = False
        self._twi_write_buffer = bytearray()
        self._twi_read_buffer = bytearray()
        self._twi_read_index = 0
        cpu.data[TWCR] = 0
        cpu.data[TWSR] = (cpu.data[TWSR] & 0x03) | TW_NO_INFO

    def _queue_twi_status(self, cpu: CPU, status: int) -> None:
        cpu.data[TWSR] = (cpu.data[TWSR] & 0x03) | (status & 0xF8)
        cpu.data[TWCR] |= TWINT
        self._twi_interrupt_pending = (cpu.data[TWCR] & TWIE) != 0

    def _handle_twi_address_phase(self, cpu: CPU) -> None:
        slarw = cpu.data[TWDR] & 0xFF
        address = (slarw >> 1) & 0x7F
        read_mode = (slarw & 0x01) != 0
        device = self.board.wire.devices.get(address)

        self._twi_device = device
        self._twi_read_mode = read_mode
        self._twi_write_buffer = bytearray()
        self._twi_read_buffer = bytearray()
        self._twi_read_index = 0

        if device is None:
            self._queue_twi_status(cpu, TW_MR_SLA_NACK if read_mode else TW_MT_SLA_NACK)
            return

        if not read_mode:
            self._queue_twi_status(cpu, TW_MT_SLA_ACK)
            return

        read_length = self._peek_i2c_read_length(device)
        if read_length is None or read_length <= 0:
            self._queue_twi_status(cpu, TW_MR_SLA_NACK)
            return
        payload = device.read(read_length)
        if payload is None or len(payload) != read_length:
            self._queue_twi_status(cpu, TW_MR_SLA_NACK)
            return

        self._twi_read_buffer = bytearray(payload)
        self._queue_twi_status(cpu, TW_MR_SLA_ACK)

    def _handle_twi_write_phase(self, cpu: CPU) -> None:
        if self._twi_device is None:
            self._queue_twi_status(cpu, TW_MT_DATA_NACK)
            return

        next_buffer = bytes(self._twi_write_buffer + bytes((cpu.data[TWDR] & 0xFF,)))
        if not self._preview_i2c_write(self._twi_device, next_buffer):
            self._queue_twi_status(cpu, TW_MT_DATA_NACK)
            return

        self._twi_write_buffer.append(cpu.data[TWDR] & 0xFF)
        self._queue_twi_status(cpu, TW_MT_DATA_ACK)

    def _handle_twi_read_phase(self, cpu: CPU, *, ack_requested: bool) -> None:
        if self._twi_read_index >= len(self._twi_read_buffer):
            self._queue_twi_status(cpu, TW_MR_DATA_NACK)
            return

        cpu.data[TWDR] = self._twi_read_buffer[self._twi_read_index] & 0xFF
        self._twi_read_index += 1
        self._queue_twi_status(cpu, TW_MR_DATA_ACK if ack_requested else TW_MR_DATA_NACK)

        if (not ack_requested) or self._twi_read_index >= len(self._twi_read_buffer):
            self._twi_device = None
            self._twi_read_mode = False

    def _finish_twi_write_if_needed(self) -> None:
        if self._twi_device is not None and not self._twi_read_mode and self._twi_write_buffer:
            self._twi_device.write(bytes(self._twi_write_buffer))
        self._twi_write_buffer = bytearray()

    @staticmethod
    def _preview_i2c_write(device: object, payload: bytes) -> bool:
        preview = getattr(device, "preview_write", None)
        if callable(preview):
            return bool(preview(payload))
        return True

    @staticmethod
    def _peek_i2c_read_length(device: object) -> int | None:
        peek = getattr(device, "peek_read_length", None)
        if callable(peek):
            value = peek()
            return None if value is None else int(value)
        return None


__all__ = [
    "Atmega328P",
    "DDRB",
    "DDRC",
    "DDRD",
    "PINB",
    "PINC",
    "PIND",
    "PORTB",
    "PORTC",
    "PORTD",
    "SPCR",
    "SPDR",
    "SPE",
    "SPIF",
    "SPSR",
    "TCCR0A",
    "TCCR0B",
    "TCNT0",
    "TIFR0",
    "TIMSK0",
    "TIMER0_OVF_VECTOR",
    "TOIE0",
    "TOV0",
    "RXC0",
    "RXCIE0",
    "RXEN0",
    "TXC0",
    "TXCIE0",
    "TXEN0",
    "U2X0",
    "UBRR0H",
    "UBRR0L",
    "UCSR0A",
    "UCSR0B",
    "UCSR0C",
    "UDR0",
    "UDRE0",
    "UDRIE0",
    "USART_RX_VECTOR",
    "USART_TX_VECTOR",
    "USART_UDRE_VECTOR",
    "TWBR",
    "TWCR",
    "TWDR",
    "TWEN",
    "TWEA",
    "TWIE",
    "TWINT",
    "TWSTA",
    "TWSTO",
    "TWSR",
    "TW_MT_DATA_ACK",
    "TW_MT_DATA_NACK",
    "TW_MT_SLA_ACK",
    "TW_MT_SLA_NACK",
    "TW_MR_DATA_ACK",
    "TW_MR_DATA_NACK",
    "TW_MR_SLA_ACK",
    "TW_MR_SLA_NACK",
    "TW_REP_START",
    "TW_START",
    "TWI_VECTOR",
]
