"""ATmega2560 memory-mapped runtime bindings for avrsim."""

from __future__ import annotations

from dataclasses import dataclass, field

from ..arduino_turbo import ArduinoTimer0DelayTurbo
from ..cpu import CPU
from ..cpu.CPU import CPUHooks, DecodedInstruction, FLAG_I
from ..mega import MegaSidecarSim


# Data-space addresses for the ATmega2560.
PINA = 0x20
DDRA = 0x21
PORTA = 0x22
PINB = 0x23
DDRB = 0x24
PORTB = 0x25
PINC = 0x26
DDRC = 0x27
PORTC = 0x28
PIND = 0x29
DDRD = 0x2A
PORTD = 0x2B
PINE = 0x2C
DDRE = 0x2D
PORTE = 0x2E
PINF = 0x2F
DDRF = 0x30
PORTF = 0x31
PING = 0x32
DDRG = 0x33
PORTG = 0x34

TIFR0 = 0x35
EECR = 0x3F
EEDR = 0x40
EEARL = 0x41
EEARH = 0x42

TCCR0A = 0x44
TCCR0B = 0x45
TCNT0 = 0x46
OCR0A = 0x47
OCR0B = 0x48

SPCR = 0x4C
SPSR = 0x4D
SPDR = 0x4E

TIMSK0 = 0x6E

ADCL = 0x78
ADCH = 0x79
ADCSRA = 0x7A
ADCSRB = 0x7B
ADMUX = 0x7C
DIDR2 = 0x7D
DIDR0 = 0x7E

UCSR0A = 0xC0
UCSR0B = 0xC1
UCSR0C = 0xC2
UBRR0L = 0xC4
UBRR0H = 0xC5
UDR0 = 0xC6

PINH = 0x100
DDRH = 0x101
PORTH = 0x102
PINJ = 0x103
DDRJ = 0x104
PORTJ = 0x105
PINK = 0x106
DDRK = 0x107
PORTK = 0x108
PINL = 0x109
DDRL = 0x10A
PORTL = 0x10B

TCCR5A = 0x120
TCCR5B = 0x121
TCCR5C = 0x122
TCNT5L = 0x124
TCNT5H = 0x125
ICR5L = 0x126
ICR5H = 0x127
OCR5AL = 0x128
OCR5AH = 0x129
OCR5BL = 0x12A
OCR5BH = 0x12B
OCR5CL = 0x12C
OCR5CH = 0x12D

# Interrupt vector numbers from avr/iom2560.h
TIMER0_OVF_VECTOR = 23
USART_RX_VECTOR = 25
USART_UDRE_VECTOR = 26
USART_TX_VECTOR = 27
ADC_VECTOR = 29

# Timer0 bits.
TOIE0 = 1 << 0
TOV0 = 1 << 0

# SPI bits.
SPI2X = 1 << 0
WCOL = 1 << 6
SPIF = 1 << 7
MSTR = 1 << 4
SPE = 1 << 6

# USART0 bits.
MPCM0 = 1 << 0
U2X0 = 1 << 1
UPE0 = 1 << 2
DOR0 = 1 << 3
FE0 = 1 << 4
UDRE0 = 1 << 5
TXC0 = 1 << 6
RXC0 = 1 << 7
UCSZ02 = 1 << 2
TXEN0 = 1 << 3
RXEN0 = 1 << 4
UDRIE0 = 1 << 5
TXCIE0 = 1 << 6
RXCIE0 = 1 << 7

# EEPROM bits.
EERE = 1 << 0
EEPE = 1 << 1
EEMPE = 1 << 2

# ADC bits.
ADPS0 = 1 << 0
ADPS1 = 1 << 1
ADPS2 = 1 << 2
ADIE = 1 << 3
ADIF = 1 << 4
ADATE = 1 << 5
ADSC = 1 << 6
ADEN = 1 << 7
MUX5 = 1 << 3

_PORT_BIT_TO_PIN = {
    "A": {0: "D22", 1: "D23", 2: "D24", 3: "D25", 4: "D26", 5: "D27", 6: "D28", 7: "D29"},
    "B": {0: "D53", 1: "D52", 2: "D51", 3: "D50", 4: "D10", 5: "D11", 6: "D12", 7: "D13"},
    "C": {0: "D37", 1: "D36", 2: "D35", 3: "D34", 4: "D33", 5: "D32", 6: "D31", 7: "D30"},
    "D": {0: "D21", 1: "D20", 2: "D19", 3: "D18", 7: "D38"},
    "E": {0: "D0", 1: "D1", 3: "D5", 4: "D2", 5: "D3"},
    "F": {0: "A0", 1: "A1", 2: "A2", 3: "A3", 4: "A4", 5: "A5", 6: "A6", 7: "A7"},
    "G": {0: "D41", 1: "D40", 2: "D39", 5: "D4"},
    "H": {0: "D17", 1: "D16", 3: "D6", 4: "D7", 5: "D8", 6: "D9"},
    "J": {0: "D15", 1: "D14"},
    "K": {0: "A8", 1: "A9", 2: "A10", 3: "A11", 4: "A12", 5: "A13", 6: "A14", 7: "A15"},
    "L": {0: "D49", 1: "D48", 2: "D47", 3: "D46", 4: "D45", 5: "D44", 6: "D43", 7: "D42"},
}

_PORT_ADDRESS_BY_NAME = {
    "A": (PINA, DDRA, PORTA),
    "B": (PINB, DDRB, PORTB),
    "C": (PINC, DDRC, PORTC),
    "D": (PIND, DDRD, PORTD),
    "E": (PINE, DDRE, PORTE),
    "F": (PINF, DDRF, PORTF),
    "G": (PING, DDRG, PORTG),
    "H": (PINH, DDRH, PORTH),
    "J": (PINJ, DDRJ, PORTJ),
    "K": (PINK, DDRK, PORTK),
    "L": (PINL, DDRL, PORTL),
}

_TIMER0_PRESCALER = {
    0: None,
    1: 1,
    2: 8,
    3: 64,
    4: 256,
    5: 1024,
    6: None,
    7: None,
}

_ADC_PRESCALER = {
    0: 2,
    1: 2,
    2: 4,
    3: 8,
    4: 16,
    5: 32,
    6: 64,
    7: 128,
}


@dataclass
class Atmega2560(CPUHooks):
    """Minimal but real ATmega2560 MMIO layer for the Mega sidecar."""

    board: MegaSidecarSim = field(default_factory=MegaSidecarSim)
    clock_hz: int = 16_000_000
    eeprom: bytearray = field(default_factory=lambda: bytearray((0xFF for _ in range(0x1000))))
    arduino_delay_turbo: ArduinoTimer0DelayTurbo | None = None

    _timer0_cycle_remainder: int = 0
    _timer0_interrupt_pending: bool = False
    _spi_transaction_active: bool = False
    _usart0_tx_log: bytearray = field(default_factory=bytearray)
    _usart0_rx_queue: bytearray = field(default_factory=bytearray)
    _usart0_tx_busy_byte: int | None = None
    _usart0_tx_cycles_remaining: int = 0
    _adc_cycles_remaining: int = 0
    _adc_interrupt_pending: bool = False
    _eeprom_master_write_enabled: bool = False

    def reset(self, cpu: CPU) -> None:
        self._timer0_cycle_remainder = 0
        self._timer0_interrupt_pending = False
        self._spi_transaction_active = False
        self._usart0_tx_log = bytearray()
        self._usart0_rx_queue = bytearray()
        self._usart0_tx_busy_byte = None
        self._usart0_tx_cycles_remaining = 0
        self._adc_cycles_remaining = 0
        self._adc_interrupt_pending = False
        self._eeprom_master_write_enabled = False
        cpu.data[TIFR0] = 0
        cpu.data[UCSR0A] = UDRE0 | TXC0
        cpu.data[UCSR0B] = 0
        cpu.data[UCSR0C] = 0
        cpu.data[UBRR0L] = 0
        cpu.data[UBRR0H] = 0
        cpu.data[UDR0] = 0
        cpu.data[ADCSRA] = 0
        cpu.data[ADCSRB] = 0
        cpu.data[ADMUX] = 0
        cpu.data[ADCL] = 0
        cpu.data[ADCH] = 0
        cpu.data[EECR] = 0
        cpu.data[EEDR] = 0xFF
        cpu.data[EEARL] = 0
        cpu.data[EEARH] = 0
        self._sync_all_ports(cpu)

    @property
    def serial_output_bytes(self) -> bytes:
        return bytes(self._usart0_tx_log)

    def serial_output_text(self, *, encoding: str = "utf-8", errors: str = "replace") -> str:
        return self.serial_output_bytes.decode(encoding, errors=errors)

    def clear_serial_output(self) -> None:
        self._usart0_tx_log = bytearray()

    def inject_usart0_rx(self, cpu: CPU, payload: bytes | bytearray) -> None:
        self._usart0_rx_queue.extend(int(byte) & 0xFF for byte in payload)
        self._service_usart0_receive_latch(cpu)

    def read_data(self, cpu: CPU, address: int) -> int | None:
        for port_name, (pin_address, _, _) in _PORT_ADDRESS_BY_NAME.items():
            if address == pin_address:
                return self._read_pin_register(port_name)
        if address == UDR0:
            value = cpu.data[UDR0]
            cpu.data[UCSR0A] &= ~RXC0
            self._service_usart0_receive_latch(cpu)
            return value & 0xFF
        if address == SPDR:
            value = cpu.data[SPDR]
            cpu.data[SPSR] &= ~(SPIF | WCOL)
            return value
        handled = {
            DDRA, PORTA, DDRB, PORTB, DDRC, PORTC, DDRD, PORTD, DDRE, PORTE,
            DDRF, PORTF, DDRG, PORTG, DDRH, PORTH, DDRJ, PORTJ, DDRK, PORTK,
            DDRL, PORTL, TIFR0, TCCR0A, TCCR0B, TCNT0, OCR0A, OCR0B, SPCR, SPSR,
            TIMSK0, UCSR0A, UCSR0B, UCSR0C, UBRR0L, UBRR0H, EECR, EEDR, EEARL,
            EEARH, ADCL, ADCH, ADCSRA, ADCSRB, ADMUX, DIDR0, DIDR2, TCCR5A,
            TCCR5B, TCCR5C, TCNT5L, TCNT5H, ICR5L, ICR5H, OCR5AL, OCR5AH,
            OCR5BL, OCR5BH, OCR5CL, OCR5CH, UDR0,
        }
        if address in handled:
            return cpu.data[address]
        return None

    def write_data(self, cpu: CPU, address: int, value: int) -> bool:
        value &= 0xFF
        for port_name, (_, ddr_address, port_address) in _PORT_ADDRESS_BY_NAME.items():
            if address == ddr_address or address == port_address:
                cpu.data[address] = value
                self._sync_port(cpu, port_name)
                return True
        if address == TIFR0:
            cpu.data[TIFR0] &= ~value
            return True
        if address == UCSR0A:
            writable_mask = MPCM0 | U2X0
            cpu.data[UCSR0A] = (cpu.data[UCSR0A] & ~(writable_mask | TXC0)) | (value & writable_mask)
            if (value & TXC0) != 0:
                cpu.data[UCSR0A] &= ~TXC0
            return True
        if address == UCSR0B:
            cpu.data[UCSR0B] = value
            if (cpu.data[UCSR0B] & RXEN0) != 0:
                self._service_usart0_receive_latch(cpu)
            else:
                cpu.data[UCSR0A] &= ~RXC0
            return True
        if address == UCSR0C:
            cpu.data[UCSR0C] = value
            return True
        if address in {UBRR0L, UBRR0H, SPCR, OCR0A, OCR0B, TCCR0A, TCCR0B, TCNT0, TIMSK0}:
            cpu.data[address] = value
            return True
        if address == SPSR:
            cpu.data[SPSR] = (cpu.data[SPSR] & (SPIF | WCOL)) | (value & SPI2X)
            return True
        if address == UDR0:
            self._write_udr0(cpu, value)
            return True
        if address == SPDR:
            self._write_spdr(cpu, value)
            return True
        if address in {ADCL, ADCH, ADMUX, ADCSRB, DIDR0, DIDR2, EEDR, EEARL, EEARH}:
            cpu.data[address] = value
            return True
        if address == ADCSRA:
            self._write_adcsra(cpu, value)
            return True
        if address == EECR:
            self._write_eecr(cpu, value)
            return True
        if address in {TCCR5A, TCCR5B, TCCR5C, TCNT5L, TCNT5H, ICR5L, ICR5H, OCR5AL, OCR5AH, OCR5BL, OCR5BH, OCR5CL, OCR5CH}:
            cpu.data[address] = value
            if address in {OCR5CL, OCR5CH}:
                self._sync_pwm_outputs(cpu)
            return True
        return False

    def after_step(self, cpu: CPU, instruction: DecodedInstruction, cycles: int) -> None:
        del instruction
        self.advance_cycles(cpu, cycles)
        self._maybe_fast_forward_arduino_delay(cpu)

    def advance_cycles(self, cpu: CPU, cycles: int) -> None:
        if cycles <= 0:
            return
        self._advance_elapsed_time(cpu, cycles)
        self._service_interrupts(cpu)

    def _advance_elapsed_time(self, cpu: CPU, cycles: int) -> None:
        elapsed_ms = float(cycles) * 1000.0 / float(self.clock_hz)
        self.board.advance_time_ms(elapsed_ms)
        self._advance_timer0(cpu, cycles)
        self._advance_usart0(cpu, cycles)
        self._advance_adc(cpu, cycles)

    def _advance_elapsed_time_without_timer0_interrupts(self, cpu: CPU, cycles: int) -> None:
        elapsed_ms = float(cycles) * 1000.0 / float(self.clock_hz)
        self.board.advance_time_ms(elapsed_ms)
        self._advance_usart0(cpu, cycles)
        self._advance_adc(cpu, cycles)

    def _advance_timer0(self, cpu: CPU, cycles: int) -> None:
        prescaler = _TIMER0_PRESCALER[cpu.data[TCCR0B] & 0x07]
        if prescaler is None:
            self._timer0_cycle_remainder = 0
            return
        total_cycles = self._timer0_cycle_remainder + cycles
        tick_count, self._timer0_cycle_remainder = divmod(total_cycles, prescaler)
        if tick_count <= 0:
            return
        counter = cpu.data[TCNT0]
        for _ in range(tick_count):
            counter += 1
            if counter > 0xFF:
                counter = 0
                cpu.data[TIFR0] |= TOV0
                if (cpu.data[TIMSK0] & TOIE0) != 0:
                    self._timer0_interrupt_pending = True
        cpu.data[TCNT0] = counter & 0xFF

    def _advance_usart0(self, cpu: CPU, cycles: int) -> None:
        if self._usart0_tx_busy_byte is None:
            self._service_usart0_receive_latch(cpu)
            return
        self._usart0_tx_cycles_remaining -= cycles
        if self._usart0_tx_cycles_remaining <= 0:
            self._usart0_tx_log.append(self._usart0_tx_busy_byte & 0xFF)
            self._usart0_tx_busy_byte = None
            self._usart0_tx_cycles_remaining = 0
            cpu.data[UCSR0A] |= UDRE0 | TXC0
        self._service_usart0_receive_latch(cpu)

    def _advance_adc(self, cpu: CPU, cycles: int) -> None:
        if self._adc_cycles_remaining <= 0:
            return
        self._adc_cycles_remaining -= cycles
        if self._adc_cycles_remaining > 0:
            return
        self._complete_adc_conversion(cpu)

    def _service_interrupts(self, cpu: CPU) -> None:
        if cpu.interrupts_deferred or cpu.get_flag(FLAG_I) == 0:
            return
        if self._timer0_interrupt_pending and (cpu.data[TIMSK0] & TOIE0) != 0:
            self._timer0_interrupt_pending = False
            cpu.take_interrupt(TIMER0_OVF_VECTOR)
            self._advance_elapsed_time(cpu, 4)
            return
        if (
            (cpu.data[UCSR0A] & RXC0) != 0
            and (cpu.data[UCSR0B] & RXCIE0) != 0
            and (cpu.data[UCSR0B] & RXEN0) != 0
        ):
            cpu.take_interrupt(USART_RX_VECTOR)
            self._advance_elapsed_time(cpu, 4)
            return
        if (
            (cpu.data[UCSR0A] & UDRE0) != 0
            and (cpu.data[UCSR0B] & UDRIE0) != 0
            and (cpu.data[UCSR0B] & TXEN0) != 0
        ):
            cpu.take_interrupt(USART_UDRE_VECTOR)
            self._advance_elapsed_time(cpu, 4)
            return
        if (
            (cpu.data[UCSR0A] & TXC0) != 0
            and (cpu.data[UCSR0B] & TXCIE0) != 0
            and (cpu.data[UCSR0B] & TXEN0) != 0
        ):
            cpu.take_interrupt(USART_TX_VECTOR)
            self._advance_elapsed_time(cpu, 4)
            return
        if self._adc_interrupt_pending and (cpu.data[ADCSRA] & ADIE) != 0:
            self._adc_interrupt_pending = False
            cpu.take_interrupt(ADC_VECTOR)
            self._advance_elapsed_time(cpu, 4)

    def _read_pin_register(self, port_name: str) -> int:
        value = 0
        for bit_index, pin_name in _PORT_BIT_TO_PIN[port_name].items():
            if self.board.gpio.digital_read(pin_name) != 0:
                value |= 1 << bit_index
        return value & 0xFF

    def _sync_all_ports(self, cpu: CPU) -> None:
        for port_name in _PORT_ADDRESS_BY_NAME:
            self._sync_port(cpu, port_name)
        self._sync_pwm_outputs(cpu)

    def _sync_port(self, cpu: CPU, port_name: str) -> None:
        _, ddr_address, port_address = _PORT_ADDRESS_BY_NAME[port_name]
        ddr_value = cpu.data[ddr_address]
        port_value = cpu.data[port_address]
        for bit_index, pin_name in _PORT_BIT_TO_PIN[port_name].items():
            old_level = self.board.gpio.digital_read(pin_name)
            if (ddr_value & (1 << bit_index)) != 0:
                self.board.gpio.pin_mode(pin_name, "OUTPUT")
                level = 1 if (port_value & (1 << bit_index)) != 0 else 0
                self.board.gpio.digital_write(pin_name, level)
                if pin_name == self.board.pin_actuator_command_pwm:
                    self.board.set_pwm_duty(pin_name, 255 if level else 0)
            elif (port_value & (1 << bit_index)) != 0:
                self.board.gpio.pin_mode(pin_name, "INPUT_PULLUP")
            else:
                self.board.gpio.pin_mode(pin_name, "INPUT")
            new_level = self.board.gpio.digital_read(pin_name)
            if pin_name in {self.board.pin_can_cs, self.board.pin_pipe_rtd_cs}:
                self._handle_spi_chip_select(old_level, new_level, cpu)

    def _sync_pwm_outputs(self, cpu: CPU) -> None:
        duty = cpu.data[OCR5CL] & 0xFF
        self.board.set_pwm_duty(self.board.pin_actuator_command_pwm, duty)

    def _write_spdr(self, cpu: CPU, value: int) -> None:
        cpu.data[SPDR] = value & 0xFF
        if (cpu.data[SPCR] & (SPE | MSTR)) != (SPE | MSTR):
            return
        if self.board.spi._active_device(allow_none=True) is None:
            cpu.data[SPDR] = 0x00
            cpu.data[SPSR] |= SPIF
            return
        if not self._spi_transaction_active:
            self.board.spi.begin_transaction(self._spi_settings(cpu))
            self._spi_transaction_active = True
        response = self.board.spi.transfer(value & 0xFF)
        cpu.data[SPDR] = response & 0xFF
        cpu.data[SPSR] |= SPIF

    def _handle_spi_chip_select(self, old_level: int, new_level: int, cpu: CPU) -> None:
        if old_level == new_level:
            return
        if new_level == 0:
            if not self._spi_transaction_active:
                self.board.spi.begin_transaction(self._spi_settings(cpu))
                self._spi_transaction_active = True
            return
        if self._spi_transaction_active and self.board.spi._active_device(allow_none=True) is None:
            self.board.spi.end_transaction()
            self._spi_transaction_active = False

    def _spi_settings(self, cpu: CPU) -> dict[str, int]:
        return {
            "spcr": cpu.data[SPCR] & 0xFF,
            "spsr": cpu.data[SPSR] & 0xFF,
        }

    def _write_udr0(self, cpu: CPU, value: int) -> None:
        cpu.data[UDR0] = value & 0xFF
        if (cpu.data[UCSR0B] & TXEN0) == 0:
            return
        self._usart0_tx_busy_byte = value & 0xFF
        self._usart0_tx_cycles_remaining = self._usart0_frame_cycles(cpu)
        cpu.data[UCSR0A] &= ~(UDRE0 | TXC0)

    def _usart0_frame_cycles(self, cpu: CPU) -> int:
        ubrr = cpu.data[UBRR0L] | ((cpu.data[UBRR0H] & 0x0F) << 8)
        divisor = 8 if (cpu.data[UCSR0A] & U2X0) != 0 else 16
        baud = float(self.clock_hz) / float(divisor * (ubrr + 1))
        frame_seconds = 10.0 / baud
        return max(1, int(round(frame_seconds * float(self.clock_hz))))

    def _service_usart0_receive_latch(self, cpu: CPU) -> None:
        if (cpu.data[UCSR0A] & RXC0) != 0 or (cpu.data[UCSR0B] & RXEN0) == 0:
            return
        if not self._usart0_rx_queue:
            return
        cpu.data[UDR0] = self._usart0_rx_queue.pop(0)
        cpu.data[UCSR0A] |= RXC0

    def _write_adcsra(self, cpu: CPU, value: int) -> None:
        preserved = cpu.data[ADCSRA] & ADIF
        updated = (value & 0xFF) | preserved
        if (value & ADIF) != 0:
            updated &= ~ADIF
        cpu.data[ADCSRA] = updated
        if (cpu.data[ADCSRA] & ADEN) == 0:
            cpu.data[ADCSRA] &= ~(ADSC | ADIF)
            self._adc_cycles_remaining = 0
            return
        if (value & ADSC) != 0 and self._adc_cycles_remaining <= 0:
            prescaler = _ADC_PRESCALER[cpu.data[ADCSRA] & (ADPS2 | ADPS1 | ADPS0)]
            self._adc_cycles_remaining = max(1, 13 * prescaler)
            cpu.data[ADCSRA] |= ADSC

    def _complete_adc_conversion(self, cpu: CPU) -> None:
        channel = ((cpu.data[ADCSRB] & MUX5) >> 3) * 8 + (cpu.data[ADMUX] & 0x07)
        pin_name = f"A{channel}"
        value = self.board.analog_input_counts(pin_name)
        cpu.data[ADCL] = value & 0xFF
        cpu.data[ADCH] = (value >> 8) & 0x03
        cpu.data[ADCSRA] &= ~ADSC
        cpu.data[ADCSRA] |= ADIF
        self._adc_cycles_remaining = 0
        if (cpu.data[ADCSRA] & ADIE) != 0:
            self._adc_interrupt_pending = True

    def _write_eecr(self, cpu: CPU, value: int) -> None:
        cpu.data[EECR] = value & (EERE | EEPE | EEMPE)
        if (value & EERE) != 0:
            address = self._eeprom_address(cpu)
            cpu.data[EEDR] = self.eeprom[address]
            cpu.data[EECR] &= ~EERE
        if (value & EEMPE) != 0:
            self._eeprom_master_write_enabled = True
        if (value & EEPE) != 0 and self._eeprom_master_write_enabled:
            address = self._eeprom_address(cpu)
            self.eeprom[address] = cpu.data[EEDR] & 0xFF
            self._eeprom_master_write_enabled = False
            cpu.data[EECR] &= ~(EEPE | EEMPE)

    def _maybe_fast_forward_arduino_delay(self, cpu: CPU) -> None:
        turbo = self.arduino_delay_turbo
        if turbo is None or cpu.pc != turbo.delay_word_address:
            return
        if cpu.get_flag(FLAG_I) == 0:
            return
        if (cpu.data[TIMSK0] & TOIE0) == 0:
            return
        prescaler = _TIMER0_PRESCALER[cpu.data[TCCR0B] & 0x07]
        if prescaler is None:
            return
        self._fast_forward_arduino_delay(cpu, self._read_u32_argument(cpu), turbo)

    def _fast_forward_arduino_delay(
        self,
        cpu: CPU,
        delay_ms: int,
        turbo: ArduinoTimer0DelayTurbo,
    ) -> None:
        if delay_ms > 0:
            delay_cycles = int(delay_ms) * self.clock_hz // 1000
            self._advance_elapsed_time_without_timer0_interrupts(cpu, delay_cycles)
            self._fast_forward_timer0_state(cpu, delay_cycles, turbo)
        return_cycles = 5 if cpu.config.return_address_bytes == 3 else 4
        cpu.pc = self._pop_return_address(cpu)
        cpu.cycles += return_cycles
        self.advance_cycles(cpu, return_cycles)

    def _fast_forward_timer0_state(
        self,
        cpu: CPU,
        cycles: int,
        turbo: ArduinoTimer0DelayTurbo,
    ) -> None:
        prescaler = _TIMER0_PRESCALER[cpu.data[TCCR0B] & 0x07]
        if prescaler is None or cycles <= 0:
            return
        total_cycles = self._timer0_cycle_remainder + cycles
        tick_count, self._timer0_cycle_remainder = divmod(total_cycles, prescaler)
        if tick_count <= 0:
            return

        total_ticks = cpu.data[TCNT0] + tick_count
        overflow_count, counter = divmod(total_ticks, 256)
        cpu.data[TCNT0] = counter & 0xFF
        if overflow_count <= 0:
            return

        millis_inc, fract_inc, fract_max = self._arduino_timer0_increments(prescaler)
        millis_value = self._read_u32(cpu, turbo.timer0_millis_data_address)
        fract_value = cpu.read_data(turbo.timer0_fract_data_address)
        overflow_value = self._read_u32(cpu, turbo.timer0_overflow_count_data_address)

        millis_value = (millis_value + (overflow_count * millis_inc)) & 0xFFFFFFFF
        fract_total = fract_value + (overflow_count * fract_inc)
        millis_value = (millis_value + (fract_total // fract_max)) & 0xFFFFFFFF
        fract_value = fract_total % fract_max
        overflow_value = (overflow_value + overflow_count) & 0xFFFFFFFF

        self._write_u32(cpu, turbo.timer0_millis_data_address, millis_value)
        cpu.write_data(turbo.timer0_fract_data_address, fract_value & 0xFF)
        self._write_u32(cpu, turbo.timer0_overflow_count_data_address, overflow_value)
        cpu.data[TIFR0] &= ~TOV0
        self._timer0_interrupt_pending = False

    def _arduino_timer0_increments(self, prescaler: int) -> tuple[int, int, int]:
        overflow_us = (prescaler * 256 * 1_000_000) // self.clock_hz
        millis_inc = overflow_us // 1000
        fract_inc = (overflow_us % 1000) >> 3
        fract_max = 1000 >> 3
        return millis_inc, fract_inc, fract_max

    def _read_u32_argument(self, cpu: CPU) -> int:
        return (
            cpu.read_register(22)
            | (cpu.read_register(23) << 8)
            | (cpu.read_register(24) << 16)
            | (cpu.read_register(25) << 24)
        )

    def _pop_return_address(self, cpu: CPU) -> int:
        value = 0
        for shift in range(0, cpu.config.return_address_bytes * 8, 8):
            value |= cpu.pop_byte() << shift
        return value & cpu.config.pc_mask

    def _read_u32(self, cpu: CPU, address: int) -> int:
        return (
            cpu.read_data(address)
            | (cpu.read_data(address + 1) << 8)
            | (cpu.read_data(address + 2) << 16)
            | (cpu.read_data(address + 3) << 24)
        )

    def _write_u32(self, cpu: CPU, address: int, value: int) -> None:
        for index in range(4):
            cpu.write_data(address + index, (value >> (8 * index)) & 0xFF)

    def _eeprom_address(self, cpu: CPU) -> int:
        address = cpu.data[EEARL] | ((cpu.data[EEARH] & 0x0F) << 8)
        return max(0, min(len(self.eeprom) - 1, address))


__all__ = [
    "ADC_VECTOR",
    "ADCH",
    "ADCL",
    "ADCSRA",
    "ADCSRB",
    "ADMUX",
    "ADSC",
    "ADEN",
    "ADIF",
    "ADIE",
    "Atmega2560",
    "DDRA",
    "DDRB",
    "DDRC",
    "DDRD",
    "DDRE",
    "DDRF",
    "DDRG",
    "DDRH",
    "DDRJ",
    "DDRK",
    "DDRL",
    "EEDR",
    "EEARH",
    "EEARL",
    "EECR",
    "OCR5CH",
    "OCR5CL",
    "PINB",
    "PINC",
    "PIND",
    "PINE",
    "PINF",
    "PING",
    "PINH",
    "PINJ",
    "PINK",
    "PINL",
    "PORTA",
    "PORTB",
    "PORTC",
    "PORTD",
    "PORTE",
    "PORTF",
    "PORTG",
    "PORTH",
    "PORTJ",
    "PORTK",
    "PORTL",
    "RXC0",
    "RXCIE0",
    "RXEN0",
    "SPCR",
    "SPDR",
    "SPE",
    "SPIF",
    "SPSR",
    "TCCR0A",
    "TCCR0B",
    "TCNT0",
    "TIFR0",
    "TIMSK0",
    "TIMER0_OVF_VECTOR",
    "TOIE0",
    "TOV0",
    "TXC0",
    "TXCIE0",
    "TXEN0",
    "U2X0",
    "UBRR0H",
    "UBRR0L",
    "UCSR0A",
    "UCSR0B",
    "UCSR0C",
    "UDR0",
    "UDRE0",
    "UDRIE0",
    "USART_RX_VECTOR",
    "USART_TX_VECTOR",
    "USART_UDRE_VECTOR",
]
