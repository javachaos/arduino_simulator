"""Tkinter board viewer for avrsim."""

from __future__ import annotations

import math
import platform
import sys
import tkinter as tk
from dataclasses import dataclass
from tkinter import ttk

from .gui_model import GuiModel, GuiScene, build_gui_model_from_pcb
from .layout import BoardLayout, CirclePrimitive, LinePrimitive, PadGeometry, Point, TextPrimitive, ViaGeometry, ZonePolygon


LAYER_COLORS = {
    "F.Cu": "#d96c4f",
    "B.Cu": "#5c80d8",
    "F.SilkS": "#ede6d6",
    "B.SilkS": "#c9d2ea",
    "F.Fab": "#98a29b",
    "B.Fab": "#98a29b",
    "F.CrtYd": "#7a837d",
    "B.CrtYd": "#7a837d",
    "Edge.Cuts": "#87d17c",
}

CATEGORY_COLORS = {
    "verify": "#8ccf7f",
    "power": "#ffd166",
    "i2c": "#7bdff2",
    "spi": "#9d8df1",
    "can": "#ff7f7f",
    "analog": "#f3a6ff",
    "info": "#9fb3c8",
}


@dataclass(frozen=True)
class HoverTarget:
    item_kind: str
    layer: str
    net_name: str | None = None
    component: str | None = None
    pad_number: str | None = None


@dataclass(frozen=True)
class NetElectricalSummary:
    voltage_text: str
    current_text: str
    note_text: str | None = None


def _fit_scale(bounds, width_px: float, height_px: float, zoom: float, margin_px: float = 32.0) -> float:
    scale_x = (width_px - (margin_px * 2.0)) / max(bounds.width_mm, 1.0)
    scale_y = (height_px - (margin_px * 2.0)) / max(bounds.height_mm, 1.0)
    return min(scale_x, scale_y) * zoom


def project_canvas_point(
    point: Point,
    bounds,
    *,
    width_px: float,
    height_px: float,
    zoom: float,
    pan_x: float,
    pan_y: float,
    margin_px: float = 32.0,
) -> tuple[float, float]:
    scale = _fit_scale(bounds, width_px, height_px, zoom, margin_px)
    x_px = margin_px + ((point.x_mm - bounds.min_x_mm) * scale) + pan_x
    y_px = margin_px + ((point.y_mm - bounds.min_y_mm) * scale) + pan_y
    return (x_px, y_px)


def scene_status(
    *,
    index: int,
    current_index: int,
    scene_count: int,
    playing: bool,
    run_complete: bool,
) -> tuple[str, str]:
    if index < current_index:
        return ("PASS", "#8ccf7f")
    if index > current_index:
        return ("QUEUED", "#9fb3c8")
    if run_complete and current_index == (scene_count - 1):
        return ("PASS", "#8ccf7f")
    if playing:
        return ("ACTIVE", "#ffd166")
    return ("PAUSED", "#ffd166")


def describe_net_electrical(scene: GuiScene, net_name: str) -> NetElectricalSummary:
    normalized = net_name.upper()
    flow = scene.net_flows.get(net_name)
    flow_note = f"Flow: {flow[0]} -> {flow[1]}" if flow is not None else None

    if normalized == "GND":
        return NetElectricalSummary(
            voltage_text="0 V reference",
            current_text="Return current is load-dependent and not solved",
            note_text=flow_note,
        )

    if "24V" in normalized or normalized in {"FIELD_24V", "VIN_RAW_24V", "VIN_FUSED_24V"}:
        return NetElectricalSummary(
            voltage_text="24 V nominal DC",
            current_text="Load-dependent and not solved",
            note_text=flow_note,
        )

    if normalized in {"+5V", "VCC"}:
        return NetElectricalSummary(
            voltage_text="5 V nominal DC",
            current_text="Load-dependent and not solved",
            note_text=flow_note,
        )

    if normalized == "+3V3":
        return NetElectricalSummary(
            voltage_text="3.3 V nominal DC",
            current_text="Load-dependent and not solved",
            note_text=flow_note,
        )

    if normalized in {"CANH", "CAN_H"}:
        return NetElectricalSummary(
            voltage_text="~2.5 V recessive, ~3.5 V dominant",
            current_text="Differential bus current is transceiver-driven and not solved",
            note_text=flow_note or "Pair this line with CANL for the differential state",
        )

    if normalized in {"CANL", "CAN_L"}:
        return NetElectricalSummary(
            voltage_text="~2.5 V recessive, ~1.5 V dominant",
            current_text="Differential bus current is transceiver-driven and not solved",
            note_text=flow_note or "Pair this line with CANH for the differential state",
        )

    if net_name in {"/A4{slash}SDA", "/A5{slash}SCL"}:
        return NetElectricalSummary(
            voltage_text="0-5 V open-drain logic with pull-up",
            current_text="Pull-up-limited signal current is not solved",
            note_text=flow_note,
        )

    if net_name in {"ACT_Y_CMD", "/ACT_U_RAW"}:
        role_text = "0-10 V command" if net_name == "ACT_Y_CMD" else "0-10 V raw feedback"
        return NetElectricalSummary(
            voltage_text=role_text,
            current_text="Analog source current is stage-dependent and not solved",
            note_text=flow_note,
        )

    if normalized == "/A10":
        return NetElectricalSummary(
            voltage_text="0-5 V scaled analog feedback",
            current_text="ADC input current is negligible and not solved",
            note_text=flow_note,
        )

    if net_name.startswith("/A"):
        return NetElectricalSummary(
            voltage_text="0-5 V analog signal range",
            current_text="Input current is source-dependent and not solved",
            note_text=flow_note,
        )

    if net_name.startswith("/*44"):
        return NetElectricalSummary(
            voltage_text="0-5 V PWM logic output",
            current_text="Driver current depends on the external stage and is not solved",
            note_text=flow_note,
        )

    if net_name.startswith("/*") or net_name.startswith("/"):
        return NetElectricalSummary(
            voltage_text="0-5 V digital logic",
            current_text="Logic-level current is source/sink dependent and not solved",
            note_text=flow_note,
        )

    return NetElectricalSummary(
        voltage_text="Not annotated for this scene",
        current_text="Not modeled",
        note_text=flow_note,
    )


def check_tk_runtime() -> str | None:
    if platform.system() != "Darwin":
        return None

    patchlevel = None
    try:
        interpreter = tk.Tcl()
        patchlevel = str(interpreter.eval("info patchlevel"))
    except Exception:
        patchlevel = None

    executable = PathLike.from_executable(sys.executable)
    if executable.is_apple_system_python and patchlevel and patchlevel.startswith("8.5"):
        return (
            "The current Python is Apple Command Line Tools Python linked against macOS Tk 8.5, "
            "which aborts when opening native Tk windows on this macOS build.\n\n"
            "Use a Homebrew Python with a matching Homebrew Tk package instead, for example:\n"
            "  brew install python@3.13 python-tk@3.13\n"
            "  /opt/homebrew/bin/python3.13 -m avrsim gui <board.kicad_pcb>\n\n"
            "The non-GUI commands still work with /usr/bin/python3:\n"
            "  python3 -m avrsim gui-data <board.kicad_pcb>\n"
            "  python3 -m avrsim layout-json <board.kicad_pcb>"
        )

    return None


def launch_tk_gui(pcb_path: str) -> None:
    app = AvrSimTkApp(build_gui_model_from_pcb(pcb_path))
    app.run()


class PathLike:
    def __init__(self, executable: str) -> None:
        self.executable = executable

    @property
    def is_apple_system_python(self) -> bool:
        return (
            self.executable == "/usr/bin/python3"
            or self.executable.startswith("/Library/Developer/CommandLineTools/")
        )

    @staticmethod
    def from_executable(executable: str) -> "PathLike":
        return PathLike(executable)


class AvrSimTkApp:
    def __init__(self, model: GuiModel) -> None:
        self.model = model
        self.root = tk.Tk()
        self.root.title(f"avrsim - {self.model.board_name}")
        self.root.geometry("1480x920")
        self.root.minsize(1080, 720)
        self.playing = True
        self.scene_index = 0
        self.scene_elapsed_ms = 0
        self.pulse_phase = 0
        self.zoom = 1.0
        self.pan_x = 0.0
        self.pan_y = 0.0
        self.last_drag_xy: tuple[int, int] | None = None
        self.component_positions = {
            footprint.reference: footprint.position
            for footprint in self.model.layout.footprints
        }
        self._active_net_names: set[str] = set()
        self._active_component_names: set[str] = set()
        self._static_signature: tuple[object, ...] | None = None
        self._item_hover_targets: dict[int, HoverTarget] = {}
        self._overlay_item_ids: set[int] = set()
        self._view_width_px = 100.0
        self._view_height_px = 100.0
        self._view_scale = 1.0
        self._hover_canvas_xy: tuple[int, int] | None = None
        self._tooltip_visible = False
        self.layer_visibility = {
            "front_copper": tk.BooleanVar(value=True),
            "back_copper": tk.BooleanVar(value=True),
            "pads": tk.BooleanVar(value=True),
            "silk": tk.BooleanVar(value=True),
            "edge": tk.BooleanVar(value=True),
            "zones": tk.BooleanVar(value=True),
            "labels": tk.BooleanVar(value=True),
        }
        self._refresh_scene_cache()
        self._build_ui()
        self._render_sidebar()
        self._redraw_board()
        self.root.after(120, self._tick)

    def run(self) -> None:
        self.root.mainloop()

    def _build_ui(self) -> None:
        self.root.configure(bg="#12161d")
        main = ttk.Frame(self.root, padding=0)
        main.pack(fill=tk.BOTH, expand=True)

        style = ttk.Style()
        style.theme_use("clam")
        style.configure("App.TFrame", background="#12161d")
        style.configure("Sidebar.TFrame", background="#171c24")
        style.configure("Card.TFrame", background="#1d2430")
        style.configure("App.TLabel", background="#12161d", foreground="#eef2f6")
        style.configure("Sidebar.TLabel", background="#171c24", foreground="#eef2f6")
        style.configure("Muted.TLabel", background="#171c24", foreground="#9fb3c8")
        style.configure("Card.TLabel", background="#1d2430", foreground="#eef2f6")
        style.configure("App.TButton", padding=6)
        main.configure(style="App.TFrame")

        self.sidebar = ttk.Frame(main, width=360, padding=16, style="Sidebar.TFrame")
        self.sidebar.pack(side=tk.LEFT, fill=tk.Y)
        self.sidebar.pack_propagate(False)

        board_area = ttk.Frame(main, padding=10, style="App.TFrame")
        board_area.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.canvas = tk.Canvas(
            board_area,
            background="#0f141b",
            highlightthickness=0,
            bd=0,
        )
        self.canvas.pack(fill=tk.BOTH, expand=True)
        self.canvas.bind("<Configure>", lambda _event: self._redraw_board())
        self.canvas.bind("<ButtonPress-1>", self._begin_pan)
        self.canvas.bind("<B1-Motion>", self._drag_pan)
        self.canvas.bind("<ButtonRelease-1>", self._end_pan)
        self.canvas.bind("<Double-Button-1>", lambda _event: self._reset_view())
        self.canvas.bind("<MouseWheel>", self._mousewheel_zoom)
        self.canvas.bind("<Motion>", self._handle_hover_motion)
        self.canvas.bind("<Leave>", lambda _event: self._hide_tooltip())

        self.tooltip_window = tk.Toplevel(self.root)
        self.tooltip_window.withdraw()
        self.tooltip_window.overrideredirect(True)
        self.tooltip_window.attributes("-topmost", True)
        self.tooltip_label = tk.Label(
            self.tooltip_window,
            background="#0b1016",
            foreground="#eef2f6",
            relief=tk.SOLID,
            borderwidth=1,
            justify=tk.LEFT,
            padx=8,
            pady=6,
            font=("TkDefaultFont", 10),
        )
        self.tooltip_label.pack()

        title = ttk.Label(
            self.sidebar,
            text=f"{self.model.board_name}",
            style="Sidebar.TLabel",
            font=("TkDefaultFont", 16, "bold"),
            wraplength=320,
        )
        title.pack(anchor=tk.W)

        path_label = ttk.Label(
            self.sidebar,
            text=self.model.board_path,
            style="Muted.TLabel",
            wraplength=320,
        )
        path_label.pack(anchor=tk.W, pady=(6, 12))

        controls = ttk.Frame(self.sidebar, style="Sidebar.TFrame")
        controls.pack(fill=tk.X, pady=(0, 12))
        ttk.Button(controls, text="Pause", command=self._pause, style="App.TButton").pack(side=tk.LEFT)
        ttk.Button(controls, text="Play", command=self._play, style="App.TButton").pack(side=tk.LEFT, padx=(8, 0))
        ttk.Button(controls, text="Step", command=self._step, style="App.TButton").pack(side=tk.LEFT, padx=(8, 0))
        ttk.Button(controls, text="Reset", command=self._reset_demo, style="App.TButton").pack(side=tk.LEFT, padx=(8, 0))

        view_controls = ttk.Frame(self.sidebar, style="Sidebar.TFrame")
        view_controls.pack(fill=tk.X, pady=(0, 16))
        ttk.Button(view_controls, text="Zoom +", command=lambda: self._scale_view(1.1), style="App.TButton").pack(side=tk.LEFT)
        ttk.Button(view_controls, text="Zoom -", command=lambda: self._scale_view(1.0 / 1.1), style="App.TButton").pack(side=tk.LEFT, padx=(8, 0))
        ttk.Button(view_controls, text="Fit", command=self._reset_view, style="App.TButton").pack(side=tk.LEFT, padx=(8, 0))

        self.current_scene_title = ttk.Label(
            self.sidebar,
            text="",
            style="Sidebar.TLabel",
            font=("TkDefaultFont", 12, "bold"),
            wraplength=320,
        )
        self.current_scene_title.pack(anchor=tk.W)

        self.current_scene_message = ttk.Label(
            self.sidebar,
            text="",
            style="Muted.TLabel",
            wraplength=320,
        )
        self.current_scene_message.pack(anchor=tk.W, pady=(6, 12))

        scene_card = ttk.Frame(self.sidebar, padding=12, style="Card.TFrame")
        scene_card.pack(fill=tk.X, pady=(0, 12))
        ttk.Label(scene_card, text="Tests", style="Card.TLabel", font=("TkDefaultFont", 11, "bold")).pack(anchor=tk.W)
        self.scene_list_frame = ttk.Frame(scene_card, style="Card.TFrame")
        self.scene_list_frame.pack(fill=tk.X, pady=(8, 0))

        detail_card = ttk.Frame(self.sidebar, padding=12, style="Card.TFrame")
        detail_card.pack(fill=tk.BOTH, expand=True, pady=(0, 12))
        ttk.Label(detail_card, text="Test Details", style="Card.TLabel", font=("TkDefaultFont", 11, "bold")).pack(anchor=tk.W)
        self.detail_text = tk.Text(
            detail_card,
            height=14,
            wrap=tk.WORD,
            background="#1d2430",
            foreground="#eef2f6",
            relief=tk.FLAT,
            highlightthickness=0,
            insertbackground="#eef2f6",
        )
        self.detail_text.pack(fill=tk.BOTH, expand=True, pady=(8, 0))
        self.detail_text.configure(state=tk.DISABLED)

        layer_card = ttk.Frame(self.sidebar, padding=12, style="Card.TFrame")
        layer_card.pack(fill=tk.X)
        ttk.Label(layer_card, text="Layers", style="Card.TLabel", font=("TkDefaultFont", 11, "bold")).pack(anchor=tk.W)
        for key, label in [
            ("front_copper", "Front Copper"),
            ("back_copper", "Back Copper"),
            ("pads", "Pads and Vias"),
            ("silk", "Silkscreen / Fab"),
            ("edge", "Board Outline"),
            ("zones", "Zones / Keepouts"),
            ("labels", "Labels"),
        ]:
            ttk.Checkbutton(
                layer_card,
                text=label,
                variable=self.layer_visibility[key],
                command=self._redraw_board,
            ).pack(anchor=tk.W, pady=1)

    def _render_sidebar(self) -> None:
        for child in self.scene_list_frame.winfo_children():
            child.destroy()

        current_scene = self.model.scenes[self.scene_index]
        self.current_scene_title.configure(text=current_scene.title)
        self.current_scene_message.configure(text=current_scene.message)

        detail_lines = list(current_scene.details)
        if self.model.verification_report and self.scene_index == 0:
            detail_lines.append("")
            detail_lines.append("Verification Summary:")
            detail_lines.extend(self.model.verification_report.splitlines()[:8])

        self.detail_text.configure(state=tk.NORMAL)
        self.detail_text.delete("1.0", tk.END)
        self.detail_text.insert("1.0", "\n".join(detail_lines))
        self.detail_text.configure(state=tk.DISABLED)

        run_complete = self._run_complete()

        for index, scene in enumerate(self.model.scenes):
            prefix, foreground = scene_status(
                index=index,
                current_index=self.scene_index,
                scene_count=len(self.model.scenes),
                playing=self.playing,
                run_complete=run_complete,
            )

            row = ttk.Frame(self.scene_list_frame, style="Card.TFrame")
            row.pack(fill=tk.X, pady=2)
            tk.Label(
                row,
                text=prefix,
                foreground=foreground,
                background="#1d2430",
                width=8,
                anchor="w",
                font=("TkDefaultFont", 9, "bold"),
            ).pack(side=tk.LEFT)
            tk.Label(
                row,
                text=scene.title,
                foreground="#eef2f6",
                background="#1d2430",
                anchor="w",
                wraplength=240,
                justify=tk.LEFT,
            ).pack(side=tk.LEFT, fill=tk.X, expand=True)

    def _pause(self) -> None:
        self.playing = False
        self._render_sidebar()
        self._redraw_board()

    def _play(self) -> None:
        self.playing = True
        self._render_sidebar()
        self._redraw_board()

    def _step(self) -> None:
        self.playing = False
        if self.scene_index < (len(self.model.scenes) - 1):
            self.scene_index += 1
            self.scene_elapsed_ms = 0
            self._refresh_scene_cache()
            self._render_sidebar()
            self._redraw_board()

    def _reset_demo(self) -> None:
        self.playing = True
        self.scene_index = 0
        self.scene_elapsed_ms = 0
        self._refresh_scene_cache()
        self._render_sidebar()
        self._redraw_board()

    def _scale_view(self, factor: float) -> None:
        self.zoom = max(0.25, min(4.0, self.zoom * factor))
        self._redraw_board()

    def _reset_view(self) -> None:
        self.zoom = 1.0
        self.pan_x = 0.0
        self.pan_y = 0.0
        self._redraw_board()

    def _begin_pan(self, event: tk.Event) -> None:
        self.last_drag_xy = (event.x, event.y)
        self._hide_tooltip()

    def _drag_pan(self, event: tk.Event) -> None:
        if self.last_drag_xy is None:
            return
        last_x, last_y = self.last_drag_xy
        self.pan_x += event.x - last_x
        self.pan_y += event.y - last_y
        self.last_drag_xy = (event.x, event.y)
        self._redraw_board()

    def _end_pan(self, _event: tk.Event) -> None:
        self.last_drag_xy = None

    def _mousewheel_zoom(self, event: tk.Event) -> None:
        factor = 1.1 if event.delta > 0 else (1.0 / 1.1)
        self._scale_view(factor)

    def _tick(self) -> None:
        redraw_needed = False
        if self.playing:
            self.pulse_phase = (self.pulse_phase + 1) % 8
            self.scene_elapsed_ms += 120
            redraw_needed = True
            current_scene = self.model.scenes[self.scene_index]
            if self.scene_elapsed_ms >= current_scene.duration_ms:
                if self.scene_index < (len(self.model.scenes) - 1):
                    self.scene_index += 1
                    self.scene_elapsed_ms = 0
                    self._refresh_scene_cache()
                    self._render_sidebar()
                else:
                    self.scene_elapsed_ms = current_scene.duration_ms
                    self.playing = False
                    self._render_sidebar()
        if redraw_needed:
            self._redraw_board()
        self.root.after(120, self._tick)

    def _refresh_scene_cache(self) -> None:
        scene = self._scene()
        self._active_net_names = set(scene.active_nets)
        self._active_component_names = set(scene.active_components)

    def _register_item_hover_target(
        self,
        item_id: int,
        *,
        item_kind: str,
        layer: str,
        net_name: str | None = None,
        component: str | None = None,
        pad_number: str | None = None,
        overlay: bool = False,
    ) -> None:
        self._item_hover_targets[item_id] = HoverTarget(
            item_kind=item_kind,
            layer=layer,
            net_name=net_name,
            component=component,
            pad_number=pad_number,
        )
        if overlay:
            self._overlay_item_ids.add(item_id)

    def _clear_overlay_hover_targets(self) -> None:
        for item_id in self._overlay_item_ids:
            self._item_hover_targets.pop(item_id, None)
        self._overlay_item_ids.clear()

    def _handle_hover_motion(self, event: tk.Event) -> None:
        if self.last_drag_xy is not None:
            return
        self._hover_canvas_xy = (event.x, event.y)
        self._update_tooltip_at(event.x, event.y)

    def _hide_tooltip(self) -> None:
        self._hover_canvas_xy = None
        if self._tooltip_visible:
            self.tooltip_window.withdraw()
            self._tooltip_visible = False

    def _update_tooltip_at(self, canvas_x: int, canvas_y: int) -> None:
        hover_target = self._hover_target_at(canvas_x, canvas_y)
        if hover_target is None:
            self._hide_tooltip()
            return

        tooltip_lines: list[str] = []
        if hover_target.net_name:
            summary = describe_net_electrical(self._scene(), hover_target.net_name)
            tooltip_lines.append(f"Net: {hover_target.net_name}")
            tooltip_lines.append(f"Voltage: {summary.voltage_text}")
            tooltip_lines.append(f"Current: {summary.current_text}")
            if summary.note_text:
                tooltip_lines.append(summary.note_text)

        if hover_target.component:
            component_text = f"Component: {hover_target.component}"
            if hover_target.pad_number:
                component_text += f" pad {hover_target.pad_number}"
            tooltip_lines.append(component_text)

        if not tooltip_lines:
            tooltip_lines.append(f"{hover_target.item_kind} on {hover_target.layer}")

        self.tooltip_label.configure(text="\n".join(tooltip_lines))
        tooltip_x = self.canvas.winfo_rootx() + canvas_x + 16
        tooltip_y = self.canvas.winfo_rooty() + canvas_y + 16
        self.tooltip_window.geometry(f"+{tooltip_x}+{tooltip_y}")
        self.tooltip_window.deiconify()
        self._tooltip_visible = True

    def _hover_target_at(self, canvas_x: int, canvas_y: int) -> HoverTarget | None:
        item_ids = self.canvas.find_overlapping(canvas_x - 3, canvas_y - 3, canvas_x + 3, canvas_y + 3)
        for item_id in reversed(item_ids):
            target = self._item_hover_targets.get(item_id)
            if target is not None:
                return target
        return None

    def _run_complete(self) -> bool:
        if self.playing:
            return False
        if self.scene_index != (len(self.model.scenes) - 1):
            return False
        return self.scene_elapsed_ms >= self.model.scenes[self.scene_index].duration_ms

    def _canvas_point(self, point: Point) -> tuple[float, float]:
        return project_canvas_point(
            point,
            self.model.layout.bounds,
            width_px=self._view_width_px,
            height_px=self._view_height_px,
            zoom=self.zoom,
            pan_x=self.pan_x,
            pan_y=self.pan_y,
        )

    def _layer_visible(self, layer: str) -> bool:
        if layer == "Edge.Cuts":
            return self.layer_visibility["edge"].get()
        if layer.startswith("F.Cu"):
            return self.layer_visibility["front_copper"].get()
        if layer.startswith("B.Cu"):
            return self.layer_visibility["back_copper"].get()
        if "Silk" in layer or "Fab" in layer or "CrtYd" in layer:
            return self.layer_visibility["silk"].get()
        return True

    def _scene(self) -> GuiScene:
        return self.model.scenes[self.scene_index]

    def _is_net_active(self, net_name: str | None) -> bool:
        return bool(net_name) and net_name in self._active_net_names

    def _is_component_active(self, reference: str | None) -> bool:
        return bool(reference) and reference in self._active_component_names

    def _active_color(self, category: str) -> str:
        base = CATEGORY_COLORS.get(category, "#ffd166")
        if self.pulse_phase < 4:
            return base
        return "#ffffff"

    def _steady_active_color(self, category: str) -> str:
        return CATEGORY_COLORS.get(category, "#ffd166")

    def _line_color(self, primitive: LinePrimitive) -> str:
        if self._is_net_active(primitive.net_name) or self._is_component_active(primitive.owner):
            return self._active_color(self._scene().category)
        return LAYER_COLORS.get(primitive.layer, "#6e7b8a")

    def _circle_color(self, primitive: CirclePrimitive) -> str:
        if self._is_component_active(primitive.owner):
            return self._active_color(self._scene().category)
        return LAYER_COLORS.get(primitive.layer, "#6e7b8a")

    def _draw_line(
        self,
        primitive: LinePrimitive,
        width_scale: float = 1.0,
        *,
        highlight: bool = False,
        tags: tuple[str, ...] = (),
    ) -> None:
        if not self._layer_visible(primitive.layer):
            return
        start = self._canvas_point(primitive.start)
        end = self._canvas_point(primitive.end)
        width_px = max(1.0, primitive.width_mm * self._current_scale() * width_scale)
        if not highlight:
            item_id = self.canvas.create_line(
                start[0],
                start[1],
                end[0],
                end[1],
                fill=LAYER_COLORS.get(primitive.layer, "#6e7b8a"),
                width=width_px,
                capstyle=tk.ROUND,
                dash=None,
                tags=tags,
            )
            if primitive.net_name or primitive.owner:
                self._register_item_hover_target(
                    item_id,
                    item_kind="trace" if primitive.net_name else "graphic",
                    layer=primitive.layer,
                    net_name=primitive.net_name,
                    component=primitive.owner,
                    overlay="overlay" in tags,
                )
            return
        active = self._is_net_active(primitive.net_name) or self._is_component_active(primitive.owner)
        if not active:
            return
        flow_vector = self._flow_vector_for_net(primitive.net_name)
        line_color = self._active_color(self._scene().category)
        if active and primitive.net_name and flow_vector is not None:
            line_color = self._steady_active_color(self._scene().category)
        item_id = self.canvas.create_line(
            start[0],
            start[1],
            end[0],
            end[1],
            fill=line_color,
            width=width_px,
            capstyle=tk.ROUND,
            dash=None,
            tags=tags,
        )
        self._register_item_hover_target(
            item_id,
            item_kind="trace" if primitive.net_name else "graphic",
            layer=primitive.layer,
            net_name=primitive.net_name,
            component=primitive.owner,
            overlay="overlay" in tags,
        )
        if active and primitive.net_name and flow_vector is not None:
            self._draw_directional_pulse(primitive, start, end, width_px, flow_vector, tags=tags)
        elif active and primitive.net_name:
            item_id = self.canvas.create_line(
                start[0],
                start[1],
                end[0],
                end[1],
                fill=self._active_color(self._scene().category),
                width=max(1.0, width_px * 0.7),
                capstyle=tk.ROUND,
                dash=(10, 6),
                tags=tags,
            )
            self._register_item_hover_target(
                item_id,
                item_kind="trace",
                layer=primitive.layer,
                net_name=primitive.net_name,
                component=primitive.owner,
                overlay="overlay" in tags,
            )

    def _draw_circle(
        self,
        primitive: CirclePrimitive,
        *,
        highlight: bool = False,
        tags: tuple[str, ...] = (),
    ) -> None:
        if not self._layer_visible(primitive.layer):
            return
        if highlight and not self._is_component_active(primitive.owner):
            return
        center_x, center_y = self._canvas_point(primitive.center)
        radius_px = max(1.0, primitive.radius_mm * self._current_scale())
        item_id = self.canvas.create_oval(
            center_x - radius_px,
            center_y - radius_px,
            center_x + radius_px,
            center_y + radius_px,
            outline=self._circle_color(primitive) if highlight else LAYER_COLORS.get(primitive.layer, "#6e7b8a"),
            width=max(1.0, primitive.width_mm * self._current_scale()),
            tags=tags,
        )
        if primitive.owner:
            self._register_item_hover_target(
                item_id,
                item_kind="circle",
                layer=primitive.layer,
                component=primitive.owner,
                overlay="overlay" in tags,
            )

    def _current_scale(self) -> float:
        return self._view_scale

    def _flow_vector_for_net(self, net_name: str | None) -> tuple[float, float] | None:
        if not net_name:
            return None
        endpoints = self._scene().net_flows.get(net_name)
        if endpoints is None:
            return None
        source = self.component_positions.get(endpoints[0])
        sink = self.component_positions.get(endpoints[1])
        if source is None or sink is None:
            return None
        vector_x = sink.x_mm - source.x_mm
        vector_y = sink.y_mm - source.y_mm
        if math.isclose(vector_x, 0.0, abs_tol=1e-9) and math.isclose(vector_y, 0.0, abs_tol=1e-9):
            return None
        return (vector_x, vector_y)

    def _draw_directional_pulse(
        self,
        primitive: LinePrimitive,
        start_xy: tuple[float, float],
        end_xy: tuple[float, float],
        width_px: float,
        flow_vector: tuple[float, float],
        *,
        tags: tuple[str, ...] = (),
    ) -> None:
        line_vector_x = primitive.end.x_mm - primitive.start.x_mm
        line_vector_y = primitive.end.y_mm - primitive.start.y_mm
        dot = (line_vector_x * flow_vector[0]) + (line_vector_y * flow_vector[1])

        start_x, start_y = start_xy
        end_x, end_y = end_xy
        if dot < 0.0:
            start_x, end_x = end_x, start_x
            start_y, end_y = end_y, start_y

        delta_x = end_x - start_x
        delta_y = end_y - start_y
        line_length_px = math.hypot(delta_x, delta_y)
        if line_length_px < 6.0:
            return

        pulse_length_px = min(max(line_length_px * 0.35, 12.0), 32.0)
        phase = self.pulse_phase / 8.0
        pulse_start_px = (phase * (line_length_px + pulse_length_px)) - pulse_length_px
        pulse_end_px = pulse_start_px + pulse_length_px
        visible_start_px = max(0.0, pulse_start_px)
        visible_end_px = min(line_length_px, pulse_end_px)
        if visible_end_px <= visible_start_px:
            return

        ux = delta_x / line_length_px
        uy = delta_y / line_length_px
        overlay_start_x = start_x + (ux * visible_start_px)
        overlay_start_y = start_y + (uy * visible_start_px)
        overlay_end_x = start_x + (ux * visible_end_px)
        overlay_end_y = start_y + (uy * visible_end_px)

        item_id = self.canvas.create_line(
            overlay_start_x,
            overlay_start_y,
            overlay_end_x,
            overlay_end_y,
            fill="#ffffff",
            width=max(2.0, width_px * 1.25),
            capstyle=tk.ROUND,
            tags=tags,
        )
        self._register_item_hover_target(
            item_id,
            item_kind="pulse",
            layer=primitive.layer,
            net_name=primitive.net_name,
            component=primitive.owner,
            overlay="overlay" in tags,
        )

    def _draw_zone(self, zone: ZonePolygon, *, tags: tuple[str, ...] = ()) -> None:
        if not self.layer_visibility["zones"].get():
            return
        if not zone.points:
            return
        coords: list[float] = []
        for point in zone.points:
            x_px, y_px = self._canvas_point(point)
            coords.extend((x_px, y_px))
        outline = "#5d6c7f" if zone.keepout else "#47505e"
        fill = "#202734" if zone.keepout else "#171d26"
        item_id = self.canvas.create_polygon(
            coords,
            outline=outline,
            fill=fill,
            width=1.0,
            stipple="gray25",
            tags=tags,
        )
        self._register_item_hover_target(
            item_id,
            item_kind="zone",
            layer=zone.layer,
            overlay="overlay" in tags,
        )

    def _draw_pad(
        self,
        pad: PadGeometry,
        *,
        highlight: bool = False,
        tags: tuple[str, ...] = (),
    ) -> None:
        if not self.layer_visibility["pads"].get():
            return
        center_x, center_y = self._canvas_point(pad.position)
        width_px = max(2.0, pad.size_mm[0] * self._current_scale())
        height_px = max(2.0, pad.size_mm[1] * self._current_scale())
        active = self._is_net_active(pad.net_name) or self._is_component_active(pad.component)
        if highlight and not active:
            return
        fill = self._active_color(self._scene().category) if highlight else "#d0a650"
        outline = "#fff5d1" if highlight else "#6f5a2d"

        if pad.shape in {"circle", "oval"}:
            item_id = self.canvas.create_oval(
                center_x - (width_px / 2.0),
                center_y - (height_px / 2.0),
                center_x + (width_px / 2.0),
                center_y + (height_px / 2.0),
                fill=fill,
                outline=outline,
                width=1.0,
                tags=tags,
            )
        else:
            item_id = self.canvas.create_rectangle(
                center_x - (width_px / 2.0),
                center_y - (height_px / 2.0),
                center_x + (width_px / 2.0),
                center_y + (height_px / 2.0),
                fill=fill,
                outline=outline,
                width=1.0,
                tags=tags,
            )
        self._register_item_hover_target(
            item_id,
            item_kind="pad",
            layer=pad.display_layer or (pad.layers[0] if pad.layers else "F.Cu"),
            net_name=pad.net_name,
            component=pad.component,
            pad_number=pad.number,
            overlay="overlay" in tags,
        )

        if pad.drill_mm:
            drill_width_px = max(1.5, pad.drill_mm[0] * self._current_scale())
            drill_height_px = drill_width_px
            if len(pad.drill_mm) >= 2:
                drill_height_px = max(1.5, pad.drill_mm[1] * self._current_scale())
            item_id = self.canvas.create_oval(
                center_x - (drill_width_px / 2.0),
                center_y - (drill_height_px / 2.0),
                center_x + (drill_width_px / 2.0),
                center_y + (drill_height_px / 2.0),
                fill="#0f141b",
                outline="",
                tags=tags,
            )
            self._register_item_hover_target(
                item_id,
                item_kind="drill",
                layer=pad.display_layer or (pad.layers[0] if pad.layers else "F.Cu"),
                net_name=pad.net_name,
                component=pad.component,
                pad_number=pad.number,
                overlay="overlay" in tags,
            )

    def _draw_via(
        self,
        via: ViaGeometry,
        *,
        highlight: bool = False,
        tags: tuple[str, ...] = (),
    ) -> None:
        if not self.layer_visibility["pads"].get():
            return
        center_x, center_y = self._canvas_point(via.position)
        size_px = max(2.0, via.size_mm * self._current_scale())
        active = self._is_net_active(via.net_name)
        if highlight and not active:
            return
        fill = self._active_color(self._scene().category) if highlight else "#b78c45"
        item_id = self.canvas.create_oval(
            center_x - (size_px / 2.0),
            center_y - (size_px / 2.0),
            center_x + (size_px / 2.0),
            center_y + (size_px / 2.0),
            fill=fill,
            outline="#f6deb0" if highlight else "#6b5425",
            width=1.0,
            tags=tags,
        )
        self._register_item_hover_target(
            item_id,
            item_kind="via",
            layer="via",
            net_name=via.net_name,
            overlay="overlay" in tags,
        )
        if via.drill_mm:
            drill_px = max(1.5, via.drill_mm * self._current_scale())
            item_id = self.canvas.create_oval(
                center_x - (drill_px / 2.0),
                center_y - (drill_px / 2.0),
                center_x + (drill_px / 2.0),
                center_y + (drill_px / 2.0),
                fill="#0f141b",
                outline="",
                tags=tags,
            )
            self._register_item_hover_target(
                item_id,
                item_kind="via drill",
                layer="via",
                net_name=via.net_name,
                overlay="overlay" in tags,
            )

    def _draw_text(
        self,
        primitive: TextPrimitive,
        *,
        color: str | None = None,
        highlight: bool = False,
        tags: tuple[str, ...] = (),
    ) -> None:
        if not self.layer_visibility["labels"].get():
            return
        if not self._layer_visible(primitive.layer):
            return
        if highlight and not self._is_component_active(primitive.owner):
            return
        x_px, y_px = self._canvas_point(primitive.position)
        font_px = 9
        if primitive.size_mm:
            font_px = max(8, int(primitive.size_mm[1] * self._current_scale() * 0.7))
        item_id = self.canvas.create_text(
            x_px,
            y_px,
            text=primitive.text,
            fill=color or LAYER_COLORS.get(primitive.layer, "#d7dde5"),
            font=("TkDefaultFont", font_px, "bold"),
            tags=tags,
        )
        if primitive.owner:
            self._register_item_hover_target(
                item_id,
                item_kind="label",
                layer=primitive.layer,
                component=primitive.owner,
                overlay="overlay" in tags,
            )

    def _redraw_board(self) -> None:
        self._update_view_cache()
        signature = self._static_view_signature()
        if signature != self._static_signature:
            self._redraw_static_board()
            self._static_signature = signature
        self._redraw_overlay()

    def _update_view_cache(self) -> None:
        self._view_width_px = float(max(100, self.canvas.winfo_width()))
        self._view_height_px = float(max(100, self.canvas.winfo_height()))
        self._view_scale = _fit_scale(
            self.model.layout.bounds,
            self._view_width_px,
            self._view_height_px,
            self.zoom,
        )

    def _static_view_signature(self) -> tuple[object, ...]:
        return (
            int(self._view_width_px),
            int(self._view_height_px),
            round(self.zoom, 6),
            round(self.pan_x, 2),
            round(self.pan_y, 2),
            self.layer_visibility["front_copper"].get(),
            self.layer_visibility["back_copper"].get(),
            self.layer_visibility["pads"].get(),
            self.layer_visibility["silk"].get(),
            self.layer_visibility["edge"].get(),
            self.layer_visibility["zones"].get(),
            self.layer_visibility["labels"].get(),
        )

    def _redraw_static_board(self) -> None:
        self.canvas.delete("all")
        self._item_hover_targets.clear()
        self._overlay_item_ids.clear()
        self.canvas.create_rectangle(
            0,
            0,
            self._view_width_px,
            self._view_height_px,
            fill="#0f141b",
            outline="",
            tags=("static",),
        )

        layout = self.model.layout
        for zone in layout.zones:
            self._draw_zone(zone, tags=("static",))

        for primitive in layout.drawings:
            self._draw_line(primitive, tags=("static",))
        for primitive in layout.edge_cuts:
            self._draw_line(primitive, width_scale=1.2, tags=("static",))
        for primitive in layout.tracks:
            self._draw_line(primitive, tags=("static",))
        for circle in layout.circles:
            self._draw_circle(circle, tags=("static",))

        for footprint in layout.footprints:
            for primitive in footprint.graphics:
                self._draw_line(primitive, tags=("static",))

        for footprint in layout.footprints:
            for pad in footprint.pads:
                self._draw_pad(pad, tags=("static",))

        for via in layout.vias:
            self._draw_via(via, tags=("static",))

        for primitive in layout.texts:
            self._draw_text(primitive, tags=("static",))

        if self.layer_visibility["labels"].get():
            for footprint in layout.footprints:
                if footprint.label is None:
                    continue
                self._draw_text(footprint.label, color="#9fb3c8", tags=("static",))

    def _redraw_overlay(self) -> None:
        self.canvas.delete("overlay")
        self._clear_overlay_hover_targets()
        layout = self.model.layout

        for primitive in layout.tracks:
            self._draw_line(primitive, highlight=True, tags=("overlay",))
        for circle in layout.circles:
            self._draw_circle(circle, highlight=True, tags=("overlay",))

        for footprint in layout.footprints:
            for primitive in footprint.graphics:
                self._draw_line(primitive, highlight=True, tags=("overlay",))

        for footprint in layout.footprints:
            for pad in footprint.pads:
                self._draw_pad(pad, highlight=True, tags=("overlay",))

        for via in layout.vias:
            self._draw_via(via, highlight=True, tags=("overlay",))

        if self.layer_visibility["labels"].get():
            for footprint in layout.footprints:
                if footprint.label is None:
                    continue
                self._draw_text(
                    footprint.label,
                    color="#ffffff",
                    highlight=True,
                    tags=("overlay",),
                )

        if self._hover_canvas_xy is not None and self.last_drag_xy is None:
            self._update_tooltip_at(*self._hover_canvas_xy)
