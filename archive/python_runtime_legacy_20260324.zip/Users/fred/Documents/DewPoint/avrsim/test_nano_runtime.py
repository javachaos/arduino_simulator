"""ATmega328P Nano runtime tests."""

from __future__ import annotations

import io
import sys
import tempfile
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from avrsim.cli import main as cli_main
from avrsim.cpu import CPU, CPUConfig
from avrsim.cpu.CPU import FLAG_I
from avrsim.mcu import (
    Atmega328P,
    DDRB,
    PORTB,
    RXC0,
    RXEN0,
    SPCR,
    SPDR,
    SPE,
    TCNT0,
    TCCR0B,
    TIMSK0,
    TXEN0,
    UBRR0L,
    UCSR0A,
    UCSR0B,
    UDR0,
    UDRE0,
    TWEA,
    TWCR,
    TWDR,
    TWEN,
    TWINT,
    TWSTA,
    TWSTO,
    TWSR,
    TW_MT_DATA_ACK,
    TW_MT_SLA_ACK,
    TW_MR_DATA_ACK,
    TW_MR_DATA_NACK,
    TW_MR_SLA_ACK,
    TW_START,
    TOIE0,
)
from avrsim.nano import NanoAirNodeSim
from avrsim.nano_runtime import NanoAirNodeFirmwareSim
from avrsim.peripherals import COMMAND_RTS_TX0, COMMAND_WRITE, REGISTER_TXB0SIDH


def _ldi(d: int, k: int) -> int:
    if d < 16 or d > 31:
        raise ValueError("LDI targets registers 16..31")
    return 0xE000 | ((k & 0xF0) << 4) | ((d - 16) << 4) | (k & 0x0F)


def _out(a: int, r: int) -> int:
    return 0xB800 | ((a & 0x30) << 5) | ((r & 0x1F) << 4) | (a & 0x0F)


def _sts(r: int, address: int) -> tuple[int, int]:
    return 0x9200 | ((r & 0x1F) << 4), address & 0xFFFF


def _bset(bit_index: int) -> int:
    return 0x9408 | ((bit_index & 0x07) << 4)


def _inc(d: int) -> int:
    return 0x9403 | ((d & 0x1F) << 4)


def _reti() -> int:
    return 0x9518


def _break() -> int:
    return 0x9598


def _decode_sht31_measurement(payload: bytes) -> tuple[float, float]:
    raw_temp = (payload[0] << 8) | payload[1]
    raw_rh = (payload[3] << 8) | payload[4]
    temp_c = -45.0 + (175.0 * float(raw_temp) / 65535.0)
    rh_percent = 100.0 * float(raw_rh) / 65535.0
    return temp_c, rh_percent


def _hex_record(address: int, record_type: int, payload: bytes) -> str:
    body = bytes(((len(payload) & 0xFF), (address >> 8) & 0xFF, address & 0xFF, record_type & 0xFF)) + payload
    checksum = (-sum(body)) & 0xFF
    return ":" + (body + bytes((checksum,))).hex().upper()


def _write_program_hex(path: Path, words: list[int]) -> None:
    program_bytes = bytearray()
    for word in words:
        program_bytes.append(word & 0xFF)
        program_bytes.append((word >> 8) & 0xFF)

    records: list[str] = []
    for offset in range(0, len(program_bytes), 16):
        chunk = bytes(program_bytes[offset : offset + 16])
        records.append(_hex_record(offset, 0x00, chunk))
    records.append(_hex_record(0x0000, 0x01, b""))
    path.write_text("\n".join(records) + "\n", encoding="utf-8")


def test_port_registers_drive_board_gpio_levels() -> None:
    board = NanoAirNodeSim()
    mcu = Atmega328P(board=board)
    cpu = CPU(CPUConfig.atmega328p(), hooks=mcu)

    cpu.write_data(DDRB, 1 << 5)
    cpu.write_data(PORTB, 1 << 5)
    assert board.status_led_on

    cpu.write_data(PORTB, 0x00)
    assert not board.status_led_on


def test_spi_mmio_reaches_the_mcp2515_board_model() -> None:
    board = NanoAirNodeSim()
    mcu = Atmega328P(board=board)
    cpu = CPU(CPUConfig.atmega328p(), hooks=mcu)

    cpu.write_data(DDRB, (1 << 2) | (1 << 3) | (1 << 5))
    cpu.write_data(PORTB, 1 << 2)
    cpu.write_data(SPCR, SPE | (1 << 4))

    write_payload = bytes(
        (
            COMMAND_WRITE,
            REGISTER_TXB0SIDH,
            0x24,
            0x60,
            0x00,
            0x00,
            0x03,
            0x11,
            0x22,
            0x33,
            0x00,
            0x00,
            0x00,
            0x00,
            0x00,
        )
    )

    cpu.write_data(PORTB, 0x00)
    for byte in write_payload:
        cpu.write_data(SPDR, byte)
        cpu.read_data(SPDR)
    cpu.write_data(PORTB, 1 << 2)

    cpu.write_data(PORTB, 0x00)
    cpu.write_data(SPDR, COMMAND_RTS_TX0)
    cpu.read_data(SPDR)
    cpu.write_data(PORTB, 1 << 2)

    board.advance_time_ms(1.0)
    frame = board.receive_can_frame()
    assert frame is not None
    assert frame.frame_id == 0x123
    assert frame.length == 3
    assert frame.data[0:3] == (0x11, 0x22, 0x33)


def test_twi_mmio_reads_a_real_sht31_measurement() -> None:
    board = NanoAirNodeSim()
    board.set_sensor_environment(23.45, 56.78)
    mcu = Atmega328P(board=board)
    cpu = CPU(CPUConfig.atmega328p(), hooks=mcu)

    cpu.write_data(TWCR, TWEN | TWEA)

    cpu.write_data(TWCR, TWEN | TWEA | TWINT | TWSTA)
    assert (cpu.read_data(TWSR) & 0xF8) == TW_START

    cpu.write_data(TWDR, 0x44 << 1)
    cpu.write_data(TWCR, TWEN | TWEA | TWINT)
    assert (cpu.read_data(TWSR) & 0xF8) == TW_MT_SLA_ACK

    cpu.write_data(TWDR, 0x24)
    cpu.write_data(TWCR, TWEN | TWEA | TWINT)
    assert (cpu.read_data(TWSR) & 0xF8) == TW_MT_DATA_ACK

    cpu.write_data(TWDR, 0x00)
    cpu.write_data(TWCR, TWEN | TWEA | TWINT)
    assert (cpu.read_data(TWSR) & 0xF8) == TW_MT_DATA_ACK

    cpu.write_data(TWCR, TWEN | TWEA | TWINT | TWSTO)
    board.advance_time_ms(15.1)

    cpu.write_data(TWCR, TWEN | TWEA | TWINT | TWSTA)
    cpu.write_data(TWDR, (0x44 << 1) | 0x01)
    cpu.write_data(TWCR, TWEN | TWEA | TWINT)
    assert (cpu.read_data(TWSR) & 0xF8) == TW_MR_SLA_ACK

    payload = bytearray()
    for index in range(6):
        control = TWEN | TWINT
        if index < 5:
            control |= TWEA
        cpu.write_data(TWCR, control)
        expected_status = TW_MR_DATA_ACK if index < 5 else TW_MR_DATA_NACK
        assert (cpu.read_data(TWSR) & 0xF8) == expected_status
        payload.append(cpu.read_data(TWDR))

    temp_c, rh_percent = _decode_sht31_measurement(bytes(payload))
    assert abs(temp_c - 23.45) <= 0.03
    assert abs(rh_percent - 56.78) <= 0.03


def test_timer0_overflow_interrupt_vectors_into_the_isr() -> None:
    board = NanoAirNodeSim()
    mcu = Atmega328P(board=board)
    cpu = CPU(CPUConfig.atmega328p(), hooks=mcu)

    program = [
        _ldi(16, TOIE0),
        *_sts(16, TIMSK0),
        _ldi(16, 0xFF),
        _out(TCNT0 - 0x20, 16),
        _ldi(16, 0x01),
        _out(TCCR0B - 0x20, 16),
        _bset(FLAG_I),
        0x0000,
        0x0000,
        _break(),
    ]
    while len(program) < (16 * 2):
        program.append(0x0000)
    program.extend([_inc(17), _reti()])
    cpu.load_program_words(program)

    cpu.run(max_instructions=32)

    assert cpu.read_register(17) == 1
    assert cpu.break_hit


def test_usart0_tx_capture_collects_transmitted_bytes() -> None:
    board = NanoAirNodeSim()
    mcu = Atmega328P(board=board)
    cpu = CPU(CPUConfig.atmega328p(), hooks=mcu)

    cpu.write_data(UBRR0L, 0x00)
    cpu.write_data(UCSR0B, TXEN0)
    assert (cpu.read_data(UCSR0A) & UDRE0) != 0

    cpu.write_data(UDR0, ord("A"))
    assert mcu.serial_output_bytes == b""
    mcu.advance_cycles(cpu, 200)

    assert mcu.serial_output_bytes == b"A"
    assert mcu.serial_output_text() == "A"
    assert (cpu.read_data(UCSR0A) & UDRE0) != 0


def test_usart0_rx_injection_lands_in_the_data_register() -> None:
    board = NanoAirNodeSim()
    mcu = Atmega328P(board=board)
    cpu = CPU(CPUConfig.atmega328p(), hooks=mcu)

    cpu.write_data(UCSR0B, RXEN0)
    mcu.inject_usart0_rx(cpu, b"Z")

    assert (cpu.read_data(UCSR0A) & RXC0) != 0
    assert cpu.read_data(UDR0) == ord("Z")
    assert (cpu.read_data(UCSR0A) & RXC0) == 0


def test_runtime_loads_a_small_intel_hex_program() -> None:
    with tempfile.TemporaryDirectory() as temp_dir:
        hex_path = Path(temp_dir) / "tiny.hex"
        # Program: BREAK
        hex_path.write_text(
            "\n".join(
                (
                    _hex_record(0x0000, 0x00, bytes((0x98, 0x95))),
                    _hex_record(0x0000, 0x01, b""),
                )
            )
            + "\n",
            encoding="utf-8",
        )

        sim = NanoAirNodeFirmwareSim()
        sim.load_hex(hex_path)
        sim.run(max_instructions=1)
        assert sim.cpu.break_hit


def test_runtime_exposes_serial_capture_helpers() -> None:
    sim = NanoAirNodeFirmwareSim()
    sim.cpu.write_data(UBRR0L, 0x00)
    sim.cpu.write_data(UCSR0B, TXEN0)
    sim.cpu.write_data(UDR0, ord("O"))
    sim.mcu.advance_cycles(sim.cpu, 200)

    assert sim.serial_output_bytes == b"O"
    assert sim.serial_output_text() == "O"
    sim.clear_serial_output()
    assert sim.serial_output_bytes == b""

    sim.cpu.write_data(UCSR0B, RXEN0)
    sim.inject_serial_rx(b"K")
    assert sim.cpu.read_data(UDR0) == ord("K")


def test_runtime_can_enable_experimental_block_jit() -> None:
    sim = NanoAirNodeFirmwareSim(enable_block_jit=True)
    assert sim.cpu.enable_block_jit


def test_runtime_can_run_until_serial_output() -> None:
    sim = NanoAirNodeFirmwareSim()
    sim.cpu.load_program_words([0x0000] * 512)
    sim.cpu.write_data(UBRR0L, 0x00)
    sim.cpu.write_data(UCSR0B, TXEN0)
    sim.cpu.write_data(UDR0, ord("S"))

    executed = sim.run_until_serial_output(max_instructions=256, chunk_size=16)

    assert executed > 0
    assert sim.serial_output_text() == "S"


def test_run_nano_cli_prints_serial_output() -> None:
    with tempfile.TemporaryDirectory() as temp_dir:
        hex_path = Path(temp_dir) / "serial.hex"
        program = [
            _ldi(16, 0x00),
            *_sts(16, UBRR0L),
            _ldi(16, TXEN0),
            *_sts(16, UCSR0B),
            _ldi(16, ord("Q")),
            *_sts(16, UDR0),
        ]
        program.extend([0x0000] * 200)
        program.append(_break())
        _write_program_hex(hex_path, program)

        stdout_buffer = io.StringIO()
        with redirect_stdout(stdout_buffer):
            exit_code = cli_main(
                [
                    "run-nano",
                    str(hex_path),
                    "--jit",
                    "--until-serial",
                    "--chunk-size",
                    "16",
                ]
            )

        assert exit_code == 0
        assert stdout_buffer.getvalue() == "Q"


def test_run_nano_cli_reports_missing_serial_output() -> None:
    with tempfile.TemporaryDirectory() as temp_dir:
        hex_path = Path(temp_dir) / "silent.hex"
        _write_program_hex(hex_path, [0x0000] * 128)

        stdout_buffer = io.StringIO()
        stderr_buffer = io.StringIO()
        with redirect_stdout(stdout_buffer), redirect_stderr(stderr_buffer):
            exit_code = cli_main(
                [
                    "run-nano",
                    str(hex_path),
                    "--until-serial",
                    "--chunk-size",
                    "16",
                    "--max-instructions",
                    "64",
                ]
            )

        assert exit_code == 1
        assert stdout_buffer.getvalue() == ""
        assert "no serial output captured" in stderr_buffer.getvalue()


def test_run_nano_cli_writes_serial_output_to_file() -> None:
    with tempfile.TemporaryDirectory() as temp_dir:
        hex_path = Path(temp_dir) / "serial.hex"
        out_path = Path(temp_dir) / "serial.txt"
        program = [
            _ldi(16, 0x00),
            *_sts(16, UBRR0L),
            _ldi(16, TXEN0),
            *_sts(16, UCSR0B),
            _ldi(16, ord("R")),
            *_sts(16, UDR0),
        ]
        program.extend([0x0000] * 200)
        program.append(_break())
        _write_program_hex(hex_path, program)

        stdout_buffer = io.StringIO()
        with redirect_stdout(stdout_buffer):
            exit_code = cli_main(
                [
                    "run-nano",
                    str(hex_path),
                    "--out",
                    str(out_path),
                    "--max-instructions",
                    "256",
                ]
            )

        assert exit_code == 0
        assert stdout_buffer.getvalue() == ""
        assert out_path.read_text(encoding="utf-8") == "R"


def main() -> int:
    test_port_registers_drive_board_gpio_levels()
    test_spi_mmio_reaches_the_mcp2515_board_model()
    test_twi_mmio_reads_a_real_sht31_measurement()
    test_timer0_overflow_interrupt_vectors_into_the_isr()
    test_usart0_tx_capture_collects_transmitted_bytes()
    test_usart0_rx_injection_lands_in_the_data_register()
    test_runtime_loads_a_small_intel_hex_program()
    test_runtime_exposes_serial_capture_helpers()
    test_runtime_can_enable_experimental_block_jit()
    test_runtime_can_run_until_serial_output()
    test_run_nano_cli_prints_serial_output()
    test_run_nano_cli_reports_missing_serial_output()
    test_run_nano_cli_writes_serial_output_to_file()
    print("avrsim Nano runtime tests passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
